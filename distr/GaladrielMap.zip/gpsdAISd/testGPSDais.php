<?php
$run = 1800;
$aisJSONfileName = sys_get_temp_dir().'/aisJSONdata';

$strLen = 0;
$r = array(" | "," / "," - "," \ ");
$i = 0;
$startAllTime = time();
do {
	clearstatcache(TRUE,$aisJSONfileName);
	if((time()-$startAllTime)>$run) {
		while(file_exists($aisJSONfileName)) {
			unlink($aisJSONfileName);
			usleep(300000);
			unlink($aisJSONfileName);
			usleep(300000);
			unlink($aisJSONfileName);
			usleep(300000);
			unlink($aisJSONfileName);
			usleep(300000);
			unlink($aisJSONfileName);
			usleep(300000);
			unlink($aisJSONfileName);
			usleep(300000);
			unlink($aisJSONfileName);
		}
		break;
	}
	$startTime = microtime(TRUE);
	$fileAtime = fileatime($aisJSONfileName);	
	//echo "\nLast call ".(time()-$fileAtime)."sec ago\n";
	
	$aisData = file_get_contents($aisJSONfileName);
	$newStrLen = strlen($aisData);
	if($newStrLen<>$strLen) {
		echo "Было $strLen стало $newStrLen                       \n";
		$strLen = $newStrLen;
	}
	$aisData = json_decode($aisData,TRUE);
	if(!$aisData) echo "Данные не декодировались                    \n";
	echo "lon={$aisData['lon']};lat={$aisData['lat']};\n";
	$endTime = microtime(TRUE);
	echo($r[$i]);
	//echo " " . ($endTime-$startTime) . "                    \r";
	echo "Last call ".(time()-$fileAtime)."sec ago                    \r";
	$i++;
	if($i>=count($r)) $i = 0;
	usleep(500000);
} while(1);


?>
