<?php
//$array1 = array('blue' => 1, 'red' => 2, 'green' => 3, 'purple' => 4);
$array1 = array(10 => 'blue', 2 => 'red', 3 => 'green', 4 => 'purple');
$array2 = array(3 => 'green', 4 => 'yellow', 5 => 'cyan');

var_dump(array_diff_key($array1, $array2));
?>

