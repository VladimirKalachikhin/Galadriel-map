<?php
$run = 1800;
//$nmeaFileName = 'kzAISsample1.log';
$nmeaFileName = 'instruments.log';

$strLen = 0;
$r = array(" | "," / "," - "," \ ");
$i = 0;
$startAllTime = time();

//$socket = stream_socket_server("tcp://127.0.0.1:2222", $errno, $errstr);
$socket = stream_socket_server("tcp://192.168.10.10:2222", $errno, $errstr);
if (!$socket) {
  return "$errstr ($errno)\n";
} 
while ($conn = stream_socket_accept($socket)) {
	while(TRUE) {
	/*
		if((time()-$startAllTime)>$run) {
			break;
		}
	*/
		$handle = fopen($nmeaFileName, "r");
		if (FALSE === $handle) {
			exit("Failed to open stream ");
		}
		while (!feof($handle)) {
			$startTime = microtime(TRUE);
			
			$nmeaData = fread($handle, 8192);
			//echo "$nmeaData\n";
			fwrite($conn, $nmeaData . "\n");
			echo($r[$i]);
			echo " " . ($endTime-$startTime) . "                    \r";
			$i++;
			if($i>=count($r)) $i = 0;
			usleep(1000000);
		};
		fclose($handle);
	}
	fclose($conn);
};
fclose($socket);


?>
