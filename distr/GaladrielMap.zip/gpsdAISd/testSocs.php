<?php
error_reporting(E_ALL);

/* Allow the script to hang around waiting for connections. */
set_time_limit(0);

/* Turn on implicit output flushing so we see what we're getting
 * as it comes in. */
ob_implicit_flush();

$address = 'localhost';
$port = 10000;

if (($sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP)) === false) {
//if (($sock = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP)) === false) {
    echo "socket_create() failed: reason: " . socket_strerror(socket_last_error()) . "\n";
    exit;
}

if (socket_bind($sock, $address, $port) === false) {
    echo "socket_bind() failed: reason: " . socket_strerror(socket_last_error($sock)) . "\n";
    exit;
}


if (socket_listen($sock, 5) === false) {
    echo "socket_listen() failed: reason: " . socket_strerror(socket_last_error($sock)) . "\n";
    exit;
}

echo "Ready to connection\n";
do {
	
    if (($msgsock = socket_accept($sock)) === false) {
        echo "socket_accept() failed: reason: " . socket_strerror(socket_last_error($sock)) . "\n";
		break;
    }
    
    
    /* Send instructions. */
	//$msg = "\nПривет, русский PHP Test Server. \n" .
	$msg = "\nPHP Test Server. \n" .
        "To quit, type 'quit'. To shut down the server type 'shutdown'.\n";
    socket_write($msgsock, $msg, strlen($msg));

    do {
		    
		$read = NULL; $write = NULL; $error = NULL;
		$read[] = $msgsock;
		if (false === ($num_changed_sockets = socket_select($read, $write, $error, 0))) {
			echo "socket_select() failed, reason: " .
				socket_strerror(socket_last_error()) . "\n";
			break;
		}
		else if($num_changed_sockets > 0) {
				
			if (false === ($buf = socket_read($read[0], 2048, PHP_NORMAL_READ))) {
			//if (false === ($buf = socket_read($msgsock, 2048,  PHP_BINARY_READ))) {
				echo "socket_read() failed: reason: " . socket_strerror(socket_last_error($msgsock)) . "\n";
				break 2;
			}
			if (!$buf = trim($buf)) {
				continue;
			}
			if ($buf == 'quit') {
				break;
			}
			if ($buf == 'shutdown') {
				socket_close($msgsock);
				break 2;
			}
			$talkback = "PHP: You said '$buf'.\n";
			socket_write($msgsock, $talkback, strlen($talkback));
			echo "$buf\n";
		}
		
		//$data = "Московское время " . date("H:i:s")  . "\n";
		$data = "Time " . date("H:i:s")  . "\n";
		echo $data;
		if( false === socket_write($msgsock, $data, strlen($data))) {
			break;
		}
		sleep(1);
    } while (true);
    socket_close($msgsock);
} while (true);

socket_close($sock);
?>
