# GaladrielMap [![License: CC BY-SA 4.0](https://img.shields.io/badge/License-CC%20BY--SA%204.0-lightgrey.svg)](https://creativecommons.org/licenses/by-sa/4.0/)
Простой картплоттер (навигационно-картографическая система), ориентированный на любительское использование на маломерных судах.  

Технически это веб-приложение -- просмотрщик тайловых онлайн карт. При использовании с  [GaladrielCache](https://github.com/VladimirKalachikhin/Galadriel-cache) становится возможным предварительное скачивание и последующий просмотр без подключения к сети Интернет.  

Приложение может быть размещено на слабом сервере типа  RaspberryPi, NAS или сетевом маршрутизаторе и предполагает использование с достаточно производительных клиентских устройств, преимущественно мобильных. Желательно применять планшет с большим экраном, однако пользоваться с телефона тоже вполне возможно. На клиентском устройстве требуется только наличие браузера -- никаких приложений устанавливать не нужно.  

## v. 1.4
 ![screen](screenshots/s10.png)<br>
Предполагается, что приложение функционирует в  бортовой сети катера, яхты или кемпера, поэтому никакого разграничения доступа к функциям не предусмотрено.
Автор пользуется GaladrielMap на своей яхте Galadriel, где в качестве сервера применяется [wi-fi маршрутизатор под управлением OpenWRT](https://github.com/VladimirKalachikhin/MT7620_openwrt_firmware) .   

**Внимание! Автор не несёт никакой ответственности за последствия использования GaladrielMap для навигации! ** 

Приложение GaladrielMap создано на основе  замечательных проектов многих, без сомнения, выдающихся авторов, поэтому необходимо вручную установить большое количество [зависимостей](#dependences-and-thanks).  

## Возможности:
1. Поддержка растровых и векторных тайлов

2. Русский или английский интерфейс в зависимости от языковых настроек браузера

3. Показ одной OSM-like растровой онлайн карты, или

4. С [GaladrielCache](https://github.com/VladimirKalachikhin/Galadriel-cache) -- произвольного количества карт как по отдельности, так и наложенными друг на друга.  
 ![stacked maps](screenshots/s1.png)
В [GaladrielCache](https://github.com/VladimirKalachikhin/Galadriel-cache) сразу есть доступ к [Open Sea Map](http://www.openseamap.org/) и [Open Topo Map](https://opentopomap.org/about), а также возможность создавать собственные конфигурирации для доступа к другим онлайн картам.

5. Показ скорости, направления и координат по информации от [gpsd](https://gpsd.io/) и отрисовка текущего пути, если таковой пишется где-нибудь в формате gpx:  
 ![Positioning](screenshots/s2.png)<br>
 
6. Показ маршрутов и точек достопримечательностей из файлов в форматах gpx, kml и csv:  
 ![Display routes and POIs](screenshots/s5.png)<br>
 
7. Планирование маршрута на клиентском устройстве, с возможностью сохранить маршрут на сервере в формате gpx:  
 ![Creating a route](screenshots/s3.png)<br>
 
8. Обмен координатами через буфер обмена, переход по координатам, введённым с клавиатуры, получение координат точек достопримечательностей. 

9.  Прогноз погоды от [Thomas Krüger Weather Service](http://weather.openportguide.de/index.php/en/) (только с  [GaladrielCache](https://github.com/VladimirKalachikhin/Galadriel-cache) версии 1.3 или больше)  
 ![Weather forecast](screenshots/s8.png)<br>
 
10. Отображение информации AIS:  
 ![AIS info](screenshots/s9.png)<br>

11. Поддержка [netAIS](https://github.com/VladimirKalachikhin/netAIS):  
 ![netAIS](screenshots/s13.png)<br>
 Три участника одной группы видят положение друг-друга на своих картах.<br> 
 
12. Управление загрузчиком GaladrielCache:   
 ![Control Loader](screenshots/s4.png)<br>
 Можно указать регион для загрузки, запускать загрузчик и следить за прогрессом скачивания.
 
 13. Приборная панель.  
 _dashboard.php_ -- отдельное приложение, предназначенное для показа некоторых имеющихся приборов на очень слабых и/или медленных клиентских устройствах. Например, на читалке электронных книг с E-ink экраном:
 ![Dashboard velocity](screenshots/s6.jpg)<br>
 ![Dashboard heading](screenshots/s7.jpg)<br>
 ![Dashboard depth](screenshots/s11.jpg)<br>
Показывается истинная скорость, истинный или магнитный курс и глубина. Разумеется, соответствующие приборы должны быть подключены к [gpsd](https://gpsd.io/). Только с приёмником геопозиционирования доступны истинный курс и скорость.  
Можно выставить сигнализацию на глубину и скорость.  
![Dashboard alarm](screenshots/s12.jpg)<br>
 Необходимо указать в настройках браузера разрешение воспроизводить звук.  
Это приложение не использует никакого хитрого javascript и никаких замысловатых стилей.

## Совместимость
Требуется Linux на сервере и более-менее современный браузер на клиентском устройстве.

## Демонстрационная версия
Имеется настроенный и готовый к запуску [образ виртуальной машины](https://github.com/VladimirKalachikhin/GaladrielMap-Demo-image/blob/master/README.ru-RU.md) в общепринятом формате.

## Установка и конфигурирование:
Требуется веб-сервер под управлением Linux с поддержкой php. Скопируйте приложение и установите указанные ниже зависимости в желаемое место на веб-сервере.  
Укажите пути и другие параметры в _params.php_  
При необъодимости, в файле _askGPSD.php_  укажите адрес и порт, используемые gpsd. 

## Зависимости и благодарности
* [Leaflet](https://leafletjs.com/), установленная в каталог _leaflet/_ 
* [Leaflet.RotatedMarker](https://github.com/bbecquet/Leaflet.RotatedMarker) установленная как _Leaflet.RotatedMarker/leaflet.rotatedMarker.js_
* [L.TileLayer.Mercator](https://github.com/ScanEx/L.TileLayer.Mercator) установленная как _L.TileLayer.Mercator/src/L.TileLayer.Mercator.js_
* [leaflet-sidebar-v2](https://github.com/nickpeihl/leaflet-sidebar-v2) установленный в каталог _leaflet-sidebar-v2/_ 
* [Leaflet.Editable](https://github.com/Leaflet/Leaflet.Editable) установленная в каталог _Leaflet.Editable/_ 
* [Leaflet Measure Path](https://github.com/ProminentEdge/leaflet-measure-path) установленная в каталог _leaflet-measure-path/_ 
* [supercluster](https://github.com/mapbox/supercluster) установленный как _supercluster/supercluster.js_
* [Coordinate Parser](https://github.com/servant-of-god/coordinate-parser) установленный в каталог _coordinate-parser/_ 
* [gpsdAISd](https://github.com/VladimirKalachikhin/gpsdAISd) в каталоге _gpsdAISd/_ 
* [mapbox-gl-js](https://github.com/mapbox/mapbox-gl-js) установленная в каталог _mapbox-gl-js/dist/_ 
* [mapbox-gl-leaflet](https://github.com/mapbox/mapbox-gl-leaflet) установленная как _mapbox-gl-leaflet/leaflet-mapbox-gl.js_

Для установки зависимостей нужно сделать локальную копию каждого проекта в каталоге приложения так, как это описано на сайте проекта, а потом, при необходимости, откорректировать пути в _index.php_

## Аварийный набор
Однако, всё, что необходимо для установки приложения, включая зависимости, находится в архиве в каталоге  _emergencykit/_. Нужно просто распаковать.  
Можно скачать комплект без поддержки векторных тайлов (без шрифтов, значков и библиотек) -- его размер менее 1MB, или полный комплект -- размером более 4MB.

## Ещё благодарности
* [leaflet-omnivore](https://github.com/mapbox/leaflet-omnivore) за leaflet-omnivore. Этот продукт вдохновил на обширные усовершенствования.
* [Metrize Icons by Alessio Atzeni](https://icon-icons.com/pack/Metrize-Icons/1130) за использованные значки.
* [Typicons by Stephen Hutchings](https://icon-icons.com/pack/Typicons/1144) за использованные значки.
* [Map Icons Collection](https://mapicons.mapsmarker.com/) за использованные значки.
* [On/Off FlipSwitch](https://proto.io/freebies/onoff/)
* [leaflet-tracksymbol](https://github.com/lethexa/leaflet-tracksymbol) на основе которого сделано отображение данных AIS
* [openmaptiles](https://github.com/openmaptiles/fonts) за Open Font Glyphs for GL Styles
* [GitHub MAPBOX project](https://github.com/mapbox) за навигационные значки
* [OpenMapTiles](https://github.com/openmaptiles) за Mapbox GL basemap style
* [leaflet-ais-tracksymbol](https://github.com/PowerPan/leaflet-ais-tracksymbol) , откуда позаимствованы идеи и немножко кода

## gpsd
GaladrielMap получает положение, данные AIS и приборов от [gpsd](https://gpsd.io/) с помощью _askGPSD.php_  и _askAIS.php_. Если необходимо, укажите в файле _askGPSD.php_ адрес и порт, используемые gpsd. Исходно там  умолчальные для gpsd localhost и 2947 порт. _askAIS.php_ берёт эту информацию из _params.php_   
Для сбора данных AIS используется демон [gpsdAISd](https://github.com/VladimirKalachikhin/gpsdAISd), который запускается в _askAIS.php_.  Отображение информации AIS отключено по умолчанию. Его можно включить, раскомментировав строку с переменной $aisServerURI в файле _params.php_.

Установка и конфигурирование gpsd описаны в [документации к gpsd](https://gpsd.io/).

## Текущий путь
Для записи текущего пути на сервере можно использовать приложение `gpxlogger`  из комплекта gpsd-clients, имеющегося в дистрибутивах, но устанавливаемого отдельно. GaladrielMap может показывать текущий путь по мере его записи.  
Если запись текущего пути внезапно прервалась, и на диске остался некорректный файл gpx, его можно поправить, запустив
```
php chkGPXfiles.php
```

## CSV
Текстовый файл в формате Comma-Separated Values -- самый простой способ заранее подготовить список интересующих точек (POI) для предстоящего путешествия. Для создания такого файла нужен только текстовый редактор, хотя удобней будет любой табличный процессор.  
Первой строкой в csv файле должны быть наименования колонок. GaladrielMap понимает следующие наименования:  
`"number","name","description","type","link","latitude","longitude"`  
хотя минимально-полезный набор состоит из  
`"name","latitude","longitude"`  
В файле возможны и другие колонки, но они, скорее всего, на карте показаны не будут.  
Широту и долготу можно указывать почти в любом формате, как в градусах, минутах и секундах -- 61°04'50"N, например, так и в десятичных градусах.  
Примером реального использования файла csv для обмена информацией о маринах и природных стоянках на озере Сайма в Финляндии может быть начинание [SaimaaPOI](https://github.com/VladimirKalachikhin/Saimaa-POI). Там же имеется файл csv с точками фотографирования с ссылками на фотографии -- тоже хороший пример.

## Ввод и получение координат
Для получения текущего положения нажмите на цифры координат на панели <img src="img/speed1.svg" alt="Dashboard" width="24px"> . Координаты будут скопированы в буфер обмена. Можно вставить их в sms, мессенджер или письмо.  
Аналогично, координаты маркированной точки на карте могут быть получены нажатим на наименование точки в всплывающем окне этой точки.

Получить координаты произвольной точки на карте можно, открыв панель <img src="img/route.svg" alt="Handle route" width="24px">. Координаты перекрестия будут отображаться в текстовом поле. Если же, наоборот, ввести в это поле какие-либо координаты (широту и долготу, почти в любом формате), и нажать кнопку рядом -- карта переместиться так, что перекрестие будет указывать в эту точку. Кнопки над текстовым полем помогут ввести знаки градусов и минут.

## Создание и редактирование маршрута
Панель <img src="img/route.svg" alt="Handle route" width="24px"> содержит инструменты для планирования и редактирования маршрута. Маршрут создаётся на локальном устройстве, сохраняется на нём (нажатием на линию вне точек), а при необходимости -- может быть сохранён на сервере в формате gpx.  
Также этот инструмент может быть использован для редактирования существующего маршрута в формате gpx, загруженного с сервера через панель <img src="img/poi.svg" alt="Handle route" width="24px"> Например, штурман в тёплой рубке рисует маршрут на своём ноутбуке в GaladrielMap, и сохраняет его на сервере. Рулевой под ветром и дождём немедленно загружает этот маршрут на свой планшет, а штурман тем временем может его уточнить и продолжить. Сообщив рулевому об изменениях, конечно.

Однако, инструмент имеет только самую базовую поддержку gpx. Так, &lt;metadata&gt; не поддерживаются, любимые GARMIN &lt;extensions&gt; тоже не поддерживаются. Поэтому следует быть осторожным при редактировании сторонних файлов gpx.

### Векторные тайлы
GaladrielMap имеет некоторую поддержку векторных тайлов в Mapbox-style . Такие карты могут отображаться.  
Описывающий карту файл[Mapbox style](https://docs.mapbox.com/mapbox-gl-js/style-spec/) должен находиться в каталоге `$mapSourcesDir` GaladrielCache, и называться также, как файл источника карты, но с расширением **.json**. В файле Mapbox style можно использовать значки и шрифты (Sprites and glyphs) из каталога _styles/_ .


## Поддержка
За чашку кофе [через ЯндексДеньги](https://yasobe.ru/na/galadrielmap) или [PayPal](https://paypal.me/VladimirKalachikhin?locale.x=ru_RU) можно получить консультации по адресу [galadrielmap@gmail.com](mailto:galadrielmap@gmail.com)  
