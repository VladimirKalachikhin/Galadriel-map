<?php
/**/
$humanName = array('ru'=>'OSM + рельеф + батиметрия + OpenSea','en'=>'OSM + DEM + bathymethry + OpenSea');
$minZoom = 0;
$maxZoom = 24;

$mapTiles = array(
/*	array(	// так красивше, но надо делать прозрачным море в osmmapMapnik, а там и море и озёра - одного цвета. А в openwaters - озёр нет. Поэтому озёра совсем некрасиво.
		"mapName"=>"openwaters",
		"mapParm"=>array(
		)
	),
	array(
		"mapName"=>"openfreemap",
		"mapParm"=>array(
		)
	),
*/	array(
		"mapName"=>"osmmapMapnik",
		"mapParm"=>array(
			//"mapTiles"=>"$tileCacheServerPath/tiles.php?z={z}&x={x}&y={y}&r={map}&options={\"prepareTileImg\":true}"
			//"requestOptions"=>array("prepareTileImg"=>true)
		)
	),
/*	array(
		"mapName"=>"openwaters",
		"mapParm"=>array(
		)
	), 
*/	array(
		"mapName"=>"mapterhorn.DEM",
		"mapParm"=>array(
		)
	),
/*	array(
		"mapName"=>"waterkaartBathymetry",
		"mapParm"=>array(
		)
	),
*/	array(
		"mapName"=>"OpenSeaMap",
		"mapParm"=>array(
		)
	)
);
$getTile = null;	// no way to get tile for this map
?>
