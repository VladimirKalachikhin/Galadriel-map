<?php
/**/
$humanName = array('ru'=>'Шведская бумажная карта и OpenTopoMap поверх','en'=>'sjofartsverket nautical & OpenTopo maps');
$minZoom = 0;
$maxZoom = 24;

$mapTiles = array(
	array(
		"mapName"=>"sjofartsverket",
		"mapParm"=>array(
		)
	),
	array(
		"mapName"=>"OpenTopoMap",
		"mapParm"=>array(
			//"mapTiles"=>"$tileCacheServerPath/tiles.php?z={z}&x={x}&y={y}&r={map}&options={\"prepareTileImg\":true}"
			"requestOptions"=>array("prepareTileImg"=>true)
		)
	)
);
$getTile = null;	// no way to get tile for this map
?>
