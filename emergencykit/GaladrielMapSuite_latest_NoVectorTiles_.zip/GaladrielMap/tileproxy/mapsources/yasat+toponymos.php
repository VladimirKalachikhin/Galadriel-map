<?php
/**/
$humanName = array('ru'=>'Космоснимки Яндекс с географическими названиями','en'=>'Yandex satellite with toponymos');
$minZoom = 0;
$maxZoom = 24;

$mapTiles = array(
	array(
		"mapName"=>"yasat.EPSG3395",
		"mapParm"=>array(
		)
	),
	array(
		"mapName"=>"openfreemap",
		"mapParm"=>array(
			"vectorTileStyleURL"=>"$tileCacheServerPath/$mapSourcesDir/openfreemap/toponymos.json"
		)
	),
);
$getTile = null;	// no way to get tile for this map
?>
