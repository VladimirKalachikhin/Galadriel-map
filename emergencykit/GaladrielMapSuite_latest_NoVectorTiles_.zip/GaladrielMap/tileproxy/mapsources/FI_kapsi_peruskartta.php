<?php
/* https://kartat.kapsi.fi/
*/
$humanName = array('ru'=>'Финляндия, топографическая карта','en'=>'Finland topo map');
$mapDescription = array('ru'=>'<a href="https://kartat.kapsi.fi/leaflet.html">kartat.kapsi.fi</a>
Бумажная карта в ярких, но почти стандартных цветах, но очень старая: домики, которых давно нет, есть, а которые давно есть - нет. Детализация от обзорной и автомобильной до вполне топографической.
Присутствует много топонимов.
','en'=>'<a href=""https://kartat.kapsi.fi/leaflet.html">kartat.kapsi.fi</a>
');
//$ttl = 60*60*24*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
$ttl = 60*60*24*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
//$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать. OpenTopoMap банит скачивальщиков, поэтому короткое.
$ext = 'jpg'; 	// tile image type/extension
$minZoom = 1;
$maxZoom = 18;
$bounds = array('leftTop'=>array('lat'=>70.145,'lng'=>19.0606),'rightBottom'=>array('lat'=>59.4519,'lng'=>31.5953));
// crc32 хеши тайлов, которые не надо сохранять: логотипы, тайлы с дурацкими надписями. '1556c7bd' чистый голубой квадрат 'c7b10d34' чистый голубой квадрат - не мусор! Иначе такие тайлы будут скачиваться снова и снова, а их много.
$trash = array(
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
// array($zoom,$x,$y,$hash)
$trueTile=array(15,18974,9287,'08cec42d');	// to source check; tile number and CRC32b hash. Oslo

$getURLoptions['r'] = pathinfo(__FILE__, PATHINFO_FILENAME);	// $getURLoptions будет передан в $getURL
//$requestOptions['prepareTileImg'] = true;

$prepareTileImgBeforeReturn = function ($img){
// Заменяет в картинке цвет на прозрачный, требует sudo apt install php-gd 
// Если заменить цвет воды на прозрачный, можно наложить эту карту на непрозрачные морские
$img = setColorsTransparent($img,array(
	array(153,255,255),
	array(184,235,234),
	array(133,253,250),
	array(127,255,254)
));
return array('img'=>$img);
}; // end function prepareTileImg

$getURL = function ($z,$x,$y,$getURLoptions=array()) {
/* */
$url = 'https://tiles.kartat.kapsi.fi/peruskartta?FORMAT=image/jpeg&VERSION=1.1.1&SERVICE=WMS&REQUEST=GetMap&STYLES=&SRS=EPSG%3A3857';

//$userAgent = randomUserAgent();

//$RequestHead='Referer: https://kartat.kapsi.fi/';
//$RequestHead='';

// Один тайл
//$leftTop = tileNum2ord($z,$x,$y);	// fcommon.php
//$rightBottom = tileNum2ord($z,$x+1,$y+1);
//$url .= '&WIDTH=256&HEIGHT=256';
// 5х3 от середины
$leftTop = tileNum2ord($z,$x-2,$y-1);	// 5х3 fcommon.php
$rightBottom = tileNum2ord($z,$x+3,$y+2);
$url .= '&WIDTH=1280&HEIGHT=768';

$url .= "&BBOX={$leftTop['x']}%2C{$rightBottom['y']}%2C{$rightBottom['x']}%2C{$leftTop['y']}";

$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE,
		//'protocol_version'=>1.1
	)
);
//print_r($opts);
// set it if you hawe Tor as proxy, and want change exit node every $tilesPerNode try. https://stackoverflow.com/questions/1969958/how-to-change-the-tor-exit-node-programmatically-to-get-a-new-ip
// tor MUST have in torrc: ControlPort 9051 without authentication: CookieAuthentication 0 and #HashedControlPassword
// Alternative: set own port, config tor password by tor --hash-password my_password and stay password in `echo authenticate '\"\"'`
//changeTORnode($getURLoptions[$getURLoptions['r']]);

return array($url,$opts);
};	// end function getURL

//
$putTile = function ($mapName,$imgArray,$trueTile=array(),$options=array()){
/* Custom storage to file procedure.
We get a large picture, and we have to cut it into standard tiles before saving it.
Let's use the functions from fTilesStorage.php
*/
list($z,$x,$y,$ext,$originalImg) = requestedTileInfo($imgArray);	// просто первый элемент $imgArray
if($originalImg){	// received file may be a null if unsuccessful
	// Split image to tiles
	$imgs = splitToTiles($originalImg,$z,$x-2,$y-1,$ext);	// 5х3 от середины
	//$imgs = splitToTiles($originalImg,$z,$x,$y,$ext);	// один тайл
	// After split, the requested tile may not be the first in the array.
	$imgs = requestedTileFirst($z,$x,$y,$ext,$imgs);	// Stay the requested tile first in array
}
else {
	$imgs = $imgArray;
};
$res = putTileToFile($mapName,$imgs,$trueTile,$options);
return $res;
}; // end function putTile
?>
