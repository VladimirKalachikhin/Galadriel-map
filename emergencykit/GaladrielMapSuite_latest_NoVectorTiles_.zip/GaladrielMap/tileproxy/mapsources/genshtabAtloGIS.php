<?php
/*
*/
$humanName = array('ru'=>'Топографические карты Генерального штаба от AtloGIS','en'=>'Russian military maps from AtloGIS');
$mapDescription = array('ru'=>' Есть подозрение, что там только один масштаб - собственно километровка, которая отдаётся без proxy, остальные создаются динамически.
По крайней мере, до масштаба 6 это уменьшенная километровка, и без proxy не отдаётся. Масштаб мельче - обзорная карта,
и отдаётся и без proxy.
Километровка здорово пережата по сравнению с оригиналом.
','en'=>'
');
//$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, один год
$ttl = 0; 	// тайлы не протухают никогда
$ext = 'jpg'; 	// tile image type/extension
$ContentType = 'image/jpeg';
$minZoom = 1;
$maxZoom = 13;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(13,4949,2575,'54483de6');	// to source check; tile number and CRC32b hash


$getURL = function ($z,$x,$y,$options=array()) {
/* Способ получения тайла любезно заимствован из https://nakarte.me/ */
$url = 'https://extern.atlogis.com/rtm';
$url .= "/$z/$x/$y";

//$userAgent = randomUserAgent();
//$RequestHead='';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n$RequestHead",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 20,
		//'request_fulluri'=>TRUE
	),
//	'socket' => array(
//		'bindto' => '0:0', // Force IPv4
//	)
);

return array($url,$opts);
};
?>
