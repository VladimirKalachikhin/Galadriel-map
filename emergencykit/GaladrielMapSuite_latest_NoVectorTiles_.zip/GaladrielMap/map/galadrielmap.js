/* Функции
listPopulate(listObject,dirURI,chkCurrent=false,withExt=true,onComplete=undefined) Заполняет ul путей или маршрутов li с именами файлов
ulDiff(listObjectIn,listObjectFrom)	Удаляет из ul listObjectFrom li, присутствующие в listObjectIn
getCookie(name)		возвращает cookie с именем name, если есть, если нет, то undefined
doSavePosition() 	Сохранение положения, списка показываемых карт, маршрутов и используемых параметров

// Функции выбора - удаления карт
selectMap(node) 	Выбор карты из списка имеющихся
deSelectMap(node) 	Прекращение показа карты, и возврат её в список имеющихся.
displayMap(mapname) Создаёт leaflet lauer с именем, содержащемся в mapname, и заносит его на карту
isPointInBounds(point,bounds)	Находится ли точка в границах, а если нет - где ближайшая граница
autoMapUpdate(mapLayer,start)	Автоматическое обновление карт с маленьким временем свежести.
removeMap(mapname)
showMapsToggle()	переключает показ всех или выбранных карт в списке карт
displayMapBounds()	покажем границы карт
displayMapBoundsOFF()


// Функции выбора - удаления треков
selectTrack(node,trackList,trackDisplayed,displayTrack)		Выбор трека из списка имеющихся. 
deSelectTrack(node,trackList,trackDisplayed,displayTrack)		Прекращение показа трека, и возврат его в список имеющихся.
displayTrack(trackNameNode,changed=false)		рисует трек с именем в trackNameNode
displayRoute(routeNameNode,changed=false)	рисует маршрут или места с именем routeName 
updateCurrTrack()

// Загрузчик и подготовка задания
XYentryFields(element)	Генерация полей ввода списка тайлов для загрузки
loaderListPopulate(element)	Заполнение списка тайлов для загрузки путём клика по тайлу 
coloreSelectedTiles()
chkColoreSelectedTile(tileEvent)
createDwnldJob() 	создаёт файлы заданий и запускает загрузчик
chkLoaderStatus(restartLoader=false) 	запускает загрузчик

// Функции рисования маршрутов
routeControlsDeSelect()
pointsControlsButtonImgs()
pointsControlsDisable()
pointsControlsEnable()
getGPXicon(gpxtype)
delShapes(realy,inLayer=null)	Удаляет полилинии в состоянии редактирования, если realy = true
tooggleEditRoute(e,flavor=null)
createEditableMarker(Icon)
doSaveMeasuredPaths()
doRestoreMeasuredPaths()
bindPopUptoEditable(layer)
eraseEditable()
startEditing()
cancelEditing()
resetRouteButtons()

saveGPX(byLoadAction=undefined) 			Сохраняет на сервере маршрут из объекта currentRoute
DOsaveGPX(byLoadAction=undefined)
toGPX(geoJSON,createTrk) Create gpx route or track (createTrk==true) from geoJSON object

// Кластеризация точек
createSuperclaster(geoJSONpoints)
removeFromSuperclaster(superclasterLayer,point)
updateClasters()
updClaster(e)
realUpdClaster(layer)

nextColor(color,step)

// Показ координат центра и переход по введённым
centerMarkPosition() // Показ координат центра и переход по введённым
centerMarkUpdate()
centerMarkOn
centerMarkOff

flyByString(stringPos) Получает строку предположительно с координатами, и перемещает туда центр карты
updGeocodeList(nominatim)
doCopyToClipboard() Копирование в буфер обмена

doCurrentTrackName(liID)
doNotCurrentTrackName(liID)

loggingWait()		запускает/останавливает слежение за наличием пишущегося трека
loggingRun() 		запускает/останавливает запись трека
loggingCheck(logging='logging.php')	включает и выключает запись трека, а также проверяет, ведётся ли запись 

coverage()

// MOB
MOBalarm(latlng=null,MOBmarkerInfo={})
MOBtabHighLight(on=false)
setMOBpopup(layer)
createMOBpointMarker(mobMarkerJSON)
MOBclose()
realMOBclose()
delMOBmarker()
makeMOBmarkerCurrent(LMarker)
clearCurrentStatus()	удаляет признак "текущий маркер" у всех маркеров мультислоя mobMarker
is_currentMOBmarkerSelf(marker=null)
checkSelfMOBmarkerScount()	Считает, имеется ли больше одного своего маркеров MOB
mobMarkerDragendFunction(event)
mobMarkerClickFunction(event)
sendMOBtoServer(status=true)
MOBtoGeoJSON(MOBdata)
GeoJSONtoMOB(mobMarkerJSON,status)

// Круги дистанции
distCirclesUpdate(distCircles)	Устанавливает диаметр и подписи кругов дистанции
distCirclesToggler() включает/выключает показ окружностей дистанции по переключателю в интерфейсе

// Ветер
windSwitchToggler()
windSymbolUpdate(data)
realWindSymbolUpdate(direction=0,speed=0)

restoreDisplayedRoutes() Восстановим показываемые маршруты и заодно согласуем списки routeList и routeDisplayed

hideControlsControl(hideControlPosition)
hideControlEventListener(event)
hideControlsToggler(target)

// Функции маршрутной точки
nextWPT()
prevWPT()
cancelFollowing()
startFollowing()
WPTbuttonsON()
WPTbuttonsReady()
WPTbuttonsOFF()
WPTbuttonsNotReady()

// Управление панорамой
PANOslaveSelect(event)
clientNameUpdate()
sendPanoControlMarkerPosition()
disablePANOcontrols()
sendCameraCommand(command)

// Общие функции
loadScriptSync(scriptURL)	Синхронная загрузка javascript
// Отправка сообщений
sendWATCH()
sendMessage(message='')
sendCOMMAND(command,parametr)

bearing(latlng1, latlng2)
destinationPoint(latlng1,bearing,distance)
tileNum2degree(zoom,xtile,ytile) Tile numbers to lon./lat. left top corner
isValidTile(z, x, y) проверяет, номер тайла ли

atou(b64)		ASCII to Unicode (decode Base64 to original data)
utoa(data)		Unicode to ASCII (encode data to Base64)

realtime(dataUrl,fUpdate)

//Классы
String.prototype.encodeHTML = function ()

L.Control.CopyToClipboard
hasLayerRecursive(what)
getLayersRecursive(classOnly=undefined)	 рекурсивный getLayers
eachLayerRecursive()
getLayerRecursive(what)

storageHandler

///////// for collision test purpose /////////
displayCollisionAreas(selfArea=null)
///////// for collision test purpose /////////
*/
/*/
// определение имени файла этого скрипта, например, чтобы знать пути на сервере
const i = document.getElementsByTagName('script').length - 1; 	// это так, потому что эта часть сработает при загрузке скрипта, и он в этот момент - последний http://feather.elektrum.org/book/src.html
var galadrielmapScript = scripts[i];
console.log(i,galadrielmapScript);
alert(galadrielmapScript.src);
/*/

function listPopulate(listObject,dirURI,chkCurrent=false,withExt=true,onComplete=undefined){
/* Заполняет ul путей или маршрутов li с именами файлов
*/
fetch(`listPopulate.php?dirname=${dirURI}`)	// запросим список файлов 
.then((response) => {
    return response.json();
})
.then(data => {
	//console.log('[listPopulate] data:',data);
	if(data){
		if(chkCurrent) currentTrackName = data.currentTrackName.substring(0, data.currentTrackName.lastIndexOf('.')) || data.currentTrackName;	// глобальная переменная
		if(data.filelist.length){
			const templateLi = listObject.querySelector('li[class="template"]');	// почему-то 'li[hidden]' не работает.
			listObject.querySelectorAll('li').forEach(li => {	// удалим из списка что там есть. delete использовать нельзя, потому что delete не уничтожает объекты, вопреки своему названию.
				if(li!=templateLi) {
					//console.log(li);
					li.remove();
					li = null;
				}
			});
			data.filelist.forEach(fileName => {
				if(!withExt) fileName = fileName.substring(0, fileName.lastIndexOf('.')) || fileName;
				let newLI = templateLi.cloneNode(true);
				newLI.classList.remove("template");
				newLI.id = fileName;
				newLI.innerText = fileName;
				newLI.hidden=false;
				listObject.append(newLI);
				if(chkCurrent && fileName == currentTrackName) {
					// Сделаем текущим и запустим слежение
					doCurrentTrackName(fileName);	// обязательно после append, ибо вне дерева элементы не ищутся. JavaScript -- коллекция нелепиц.
				}
			});
		};
	};
	//console.log('[listPopulate] listObject:',listObject,'onComplete:',onComplete);
	if(onComplete) onComplete();	// здесь надо }).then(что?=>{if(onComplete) onComplete();}) ?
})
//.catch( (err) => {	// сюда придёт любая ошибка после fetch
//	console.log(`Error get ${dirURI} files list:`,err.message);
//});
}; // end function listPopulate


function ulDiff(listObjectIn,listObjectFrom){
/* Удаляет из ul listObjectFrom li, присутствующие в listObjectIn
Может быть использована в listPopulate в качестве функции onComplete для
удаления из созданного списка имеющихся списка показываемых. 
Например, из routeList (listObjectFrom) удалить routeDisplayed (listObjectIn)
*/
const listObjectFromLiS = listObjectFrom.querySelectorAll('li');	// список всех li в listObjectFrom
listObjectIn.querySelectorAll('li').forEach(function (displayedLi){	// для каждого элемента списка всех li из listObjectIn
	//console.log('displayedLi:',displayedLi.id);
	for(const li of listObjectFromLiS){	// прокрутим список всех li в listObjectFrom
		//console.log('\trouteList li',li.id);
		if(displayedLi.id==li.id){	// если элемент из списка listObjectFrom есть в списке элементов listObjectIn
			li.remove();	// method removes the element from the DOM. Объект остаётся в коллекции routeListLi? Похоже, да, хотя не должен?
			break;
		};
	};
});
}; // end function ulDiff


function getCookie(name) {
// возвращает cookie с именем name, если есть, если нет, то undefined
name=name.trim();
var matches = document.cookie.match(new RegExp(
	"(?:^|; )" + name.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
	)
);
return matches ? decodeURIComponent(matches[1]) : null;
};


function doSavePosition(){
/* Сохранение положения, списка показываемых карт, маршрутов и используемых параметров
global map, mapDisplayed, document, currTrackSwitch
*/
let toSave = {'startCenter':map.getCenter()};
toSave['startZoom'] = map.getZoom();
// Сохранение показываемых карт
let openedNames = [];
for (let i = 0; i < mapDisplayed.children.length; i++) { 	// для каждого потомка списка mapDisplayed
	//console.log('mapDisplayed li',mapDisplayed.children[i]);
	openedNames[i] = mapDisplayed.children[i].id; 	// 
}
toSave['layers'] = openedNames;
// Сохранение показываемых маршрутов
openedNames = [];
for (let i = 0; i < routeDisplayed.children.length; i++) { 	// для каждого потомка списка mapDisplayed
	openedNames[i] = routeDisplayed.children[i].innerHTML; 	// 
}
toSave['showRoutes'] = openedNames;
// Сохранение переключателей и параметров
toSave['currTrackSwitch'] = currTrackSwitch.checked;
if(typeof loggingSwitch !== 'undefined') toSave['loggingSwitch'] = loggingSwitch.checked;
toSave['SelectedRoutesSwitch'] = SelectedRoutesSwitch.checked;
toSave['DisplayPANOswitch'] = DisplayPANOswitch.checked;
toSave['minWATCHinterval'] = minWATCHinterval;
toSave['showMapsList'] = showMapsList;
storageHandler.save(toSave);
//console.log('Position, layers and options saved');
}; // end function doSavePosition




// Функции выбора - удаления карт
function selectMap(node) { 	// async нельзя, потому что при старте приложения карты должны загружаться в определённом порядке
// Выбор карты из списка имеющихся. Получим объект
//console.log('[selectMap] node:',node);
mapDisplayed.insertBefore(node,mapDisplayed.firstChild); 	// из списка доступных в список показываемых (объект, на котором событие, добавим в конец потомков mapDisplayed)
node.classList.remove("showedMapName");
node.hidden = false;
node.onclick = function(event){deSelectMap(event.currentTarget);};
displayMap(node.id);
}; // end function selectMap


async function deSelectMap(node) {
/* Прекращение показа карты, и возврат её в список имеющихся. Получим объект
*/
//console.log('[deSelectMap] node:',node);

let li = null;
for (let i = 0; i < mapList.children.length; i++) { 	// для каждого потомка списка mapList
	li = mapList.children[i]; 	// взять этого потомка
	let childTitle = li.innerHTML;
	//console.log('[deSelectMap] childTitle=',childTitle);
	if (childTitle > node.innerHTML) { 	// если наименование потомка дальше по алфавиту, чем наименование того, на что кликнули
		break;
	}
	li = null;
}
mapList.insertBefore(node,li); 	// перенесём перед тем, на котором обломался цикл, или перед концом
node.onclick = function(event){selectMap(event.currentTarget);};
if(showMapsToggler.innerHTML == showMapsTogglerTXT[0]){	// текущий режим - "только избранные"
	if(!showMapsList.includes(node.id)) node.hidden = true;
}
else {	// текущий режим - "все карты"
	if(showMapsList.includes(node.id)) node.classList.add("showedMapName");
}
// Теперь собственно уберём карту с экрана
removeMap(node.id);	// просто уберём карту с этим именем
//console.log('[deSelectMap] savedLayers:',savedLayers);
if(map.hasLayer(tileGrid)) displayMapBounds();	// перерисуем границы карт, если показываем сетку
}; // end function deSelectMap


async function displayMap(mapname,mapParm={}) {
//console.log('[displayMap] mapname=',mapname,'mapParm:',JSON.stringify(mapParm));
if(savedLayers[mapname] == null) {
	// вот тут надо await, а надо?
	const layer = realDisplayMap(mapname,mapParm);	
	if(layer == null) return;
	if(typeof layer.options.javascriptOpen === 'function') {
		layer.options.javascriptOpen(layer);
	};
	if(savedLayers[mapname]) savedLayers[mapname].remove();
	savedLayers[mapname] = layer;
	//console.log('[displayMap] mapname=',mapname,'savedLayers[mapname]:',savedLayers[mapname]);
	savedLayers[mapname].addTo(map);
}
else {	// такая карта уже есть, просто покажем
	savedLayers[mapname].eachLayer((layer)=>{	// оно всегда LayerGroup?
		if(typeof layer.options.javascriptOpen === 'function') {
			layer.options.javascriptOpen(layer);
		};
	});
	if(typeof savedLayers[mapname].options.javascriptOpen === 'function') {
		savedLayers[mapname].options.javascriptOpen(savedLayers[mapname]);
	};
	savedLayers[mapname].addTo(map);
};
//console.log('[displayMap] mapname=',mapname,'mapParm:',savedLayers[mapname].options.mapParm);
autoMapUpdate(savedLayers[mapname],true) // Включить автоматическое обновление
//
if(map.hasLayer(tileGrid)) displayMapBounds();	// перерисуем границы карт, если показываем сетку
}; // end function displayMap


function contourLines(mapname,mapParm={}){
/**/
//console.log('[contourLines] mapname=',mapname,'mapParm:',mapParm);
let realContourLinesCounter = 1;
const realContourLinesCounterLimit = 100;

if(!mapParm.clientData) mapParm.clientData = {};
if(!mapParm.clientData.DEMthresholds) mapParm.clientData.DEMthresholds = {
	// zoom: [minor, major]
	11: [100, 500],
	12: [50, 500],
	13: [10, 200],
	14: [5, 100],
	15: [2, 50]
};

function realContourLines(maplibreMap){
//console.log('[realContourLines] maplibreMap:',maplibreMap,'mapParm:',mapParm);
if(maplibreMap.isStyleLoaded()){	// однако, эта функция по непонятным причинам может никогда не вернуть true
	//console.log('[realContourLines] isStyleLoaded() сработала на realContourLinesCounter=',realContourLinesCounter);
	//console.log('[realContourLines] maplibreMap style:',maplibreMap.getStyle());
	const style = maplibreMap.getStyle();
	let layer;
	for(layer of style.layers){
		// Только в слое с ContourLines в имени будем рисовать горизонтали!
		// А вот должен ли он быть обязательно типа hillshade?
		//if((layer.type == 'hillshade') && (layer.id.includes('ContourLines'))){
		if(layer.id.includes('ContourLines')){
			//console.log('[realContourLines] слой',layer.id,'является тонировкой рельефа');
			//console.log('[realContourLines] слой найден в maplibreMap:',maplibreMap);
			break;	// там только один слой hillshade? Ну, по логике вещей... Хотя у них европейская логика.
		};
	};
	//if((layer.type != 'hillshade') || (!layer.id.includes('ContourLines'))) return;	// слоя hillshade с нужным именем в карте maplibre нет.
	if(!layer.id.includes('ContourLines')) return;	// слоя hillshade с нужным именем в карте maplibre нет.
	//console.log('[realContourLines] Загружена ли maplibre-contour?:',mapboxCountourscript);
	if(!mapboxCountourscript){	// библиотека maplibre-contour ещё не загружена
		if(mapboxCountourscript=loadScriptSync("maplibre-contour/dist/index.js")) console.log("[realDisplayMap] maplibre-contour is loaded");
		else return;	// не удалось загрузить библиотеку maplibre-contour
	};

	// У этих придурков "The URL must be absolute, containing the scheme, authority and path components." https://maplibre.org/maplibre-style-spec/glyphs/
	//console.log(window.location.origin,window.location.pathname);
	// Ещё у этих придурков не работают функции getGlyphs() и setGlyphs().
	// Однако, версия @5.19.0 (последняя на...), имеет встроенный шрифт, и может обходиться без glyphs.
	// Но она на 300K больше.
	// Но @5.19.0 не падает на .getStyle() после замены glyphs в setStyle
	if(!style.glyphs) {
		console.log('[realContourLines] no glyphs, adding and waiting further');
		//maplibreMap.setGlyphs(`${window.location.origin}${window.location.pathname}styles/fonts/{fontstack}/{range}.pbf`);
		style.glyphs = `${window.location.origin}${window.location.pathname}styles/fonts/{fontstack}/{range}.pbf`;
		maplibreMap.setStyle(style);	// стиль будет полностью заменён?, потому что изменён glyphs
		setTimeout(realContourLines,10,maplibreMap);	// запустим ожидание обновления стиля. Строго говоря, даже повторная проверка на наличие слоя hillshade будет уместна - вдруг его кто-то удалит?
		return;	// и на этом всё, ибо считаем, что без glyphs упс.
	};

	//console.log('[realContourLines] Стиль есть, можно рисовать карту',maplibreMap.getStyle())
	// Итак, glyphs есть. Пора рисовать горизонтали.
	//console.log('[realContourLines] Объект sources для найденного слоя типа hillshade:',style.sources[layer.source]);
	//console.log('[realContourLines] Объект sources:',style.sources);
	// Авотхрен. В версии 2.2.1 в этот момент уже загружены json по url, и там есть как "tiles" {}, так и "url" с json.
	// В версии 5.19.0 "tiles" {} ещё нет.
	// Зато функция getSource работает и там и там, если асилить доку, и понять, как её спрашивать.
	let DEMsourceName;
	for(const sourceID in style.sources){
		if(style.sources[sourceID].type == "raster-dem"){
			DEMsourceName = sourceID;
			break;
		};
	}
	if(DEMsourceName === undefined) return;	// несмотря на то, что это слой типа hillshade, в нём нет источника данных типа raster-dem. А так бывает?
	//console.log('[realContourLines] Объект sources для найденного слоя типа hillshade с DEMsourceName:',DEMsourceName,maplibreMap.getSource(DEMsourceName));	// Параметром должен быть не layer.id, как можно было бы подумать, а идентификатор источника, которых у layer может быть много.
	const url = maplibreMap.getSource(DEMsourceName).tiles[0];
	const maxzoom = style.sources[layer.source].maxzoom || 17;
	//console.log('[realContourLines] url=',url,'maxzoom=',maxzoom);
	let DEMencoding;
	DEMencoding = mapParm.clientData.DEMencoding;
	if(DEMencoding != 'mapbox') DEMencoding = 'terrarium';
	let demSource = new mlcontour.DemSource({
		"url" : url,
		// А какого хрена кодировка DEM не указывается в стиле, если там есть "type": "hillshade"?
		// а потому что для hillshade не нужна абсолютная высота, а относительные одинаковые в обоих кодировках.
		// "mapbox" or "terrarium" default="terrarium"
		"encoding" : DEMencoding, 
		"maxzoom" : maxzoom,
		"worker" : true, // offload isoline computation to a web worker to reduce jank
		cacheSize: 100, // number of most-recent tiles to cache
		timeoutMs: 10_000, // timeout on fetch requests
	});
	demSource.setupMaplibre(maplibregl);
	// Then configure a new contour source and add it to your map:
	/*/
	The demSource.contourProtocolUrl thresholds parameter in MapLibre/maplibre-contour defines elevation intervals for minor and major contour lines, mapped by zoom level (zoom: [minor, major]). It controls which contour lines are displayed (e.g., every 50m/200m or 20m/100m) to reduce clutter at different map scales. 
	Common Threshold Configurations (Zoom: [Minor, Major]):
		Detailed (Zoom 14+): 14: [50, 200] or 14: [20, 100] for high-resolution terrain.
		Mid-range (Zoom 11-13): 11: [200, 1000], 12: [100, 500].
		Example Usage: thresholds: { 11: [200, 1000], 12: [100, 500], 14: [50, 200], 15: [20, 100] }. 
	Key Details:
		Units: Values are generally in meters unless a multiplier is applied (e.g., 3.28084 for feet).
		Structure: Defines when to show lighter, thin lines (minor) and darker, thick lines (major).
		Alternative Inline Format: In URLs, these can be specified as 11*250*1000 (Zoom * Minor * Major).
	/*/    
	maplibreMap.addSource("contourSource", {
		"type": "vector",
		"tiles": [
			demSource.contourProtocolUrl({
				// convert meters to feet, default=1 for meters
				//"multiplier": 3.28084,
				"thresholds": mapParm.clientData.DEMthresholds,
				// optional, override vector tile parameters:
				"contourLayer": "contours",
				"elevationKey": "ele",	// имя свойства mlcontour в maplibre style
				"levelKey": "level",	// "major" contours have level=1, "minor" have level=0
				"overzoom": 1,
				//"extent": 4096,
				//"buffer": 1,
			})
		],
		"maxzoom": maxzoom
	});
	// Then add contour line and label layers:
	maplibreMap.addLayer({
		"id": "contourLines",	// Подразумевается, что там высот < 0 нет, хотя никто не запрещает.
		"type": "line",
		"source": "contourSource",
		"source-layer": "contours",
		"filter": ["!=", ["get", "ele"], 0],
		"paint": {
			//"line-color": "rgba(0,0,0, 30%)",
			"line-color": "rgba(230,135,30, 75%)",
			//"line-color": "red",
			// level = highest index in thresholds array the elevation is a multiple of
			"line-width": ["match", ["get", "level"], 1, 1, 0.5],
		},
	});
	maplibreMap.addLayer({
		"id": "contourLabels",
		"type": "symbol",
		"source": "contourSource",
		"source-layer": "contours",
		"filter": ["all",
			["!=", ["get", "ele"], 0],
			[">", ["get", "level"], 0]
		],
		"layout": {
			"symbol-placement": "line",
			"text-size": 10,
			//"text-field": ["concat", ["number-format", ["get", "ele"], {}], "'"],
			"text-field": ["number-format", ["get", "ele"], {}],
			"text-font": ["Noto Sans Bold"],
		},
		"paint": {
			"text-color": "rgba(230,135,30, 75%)",
			"text-halo-color": "white",
			"text-halo-width": 1,
		},
	});
	//console.log('[realContourLines] Созданы горизонтали на карте',maplibreMap);
}
else {
	//console.log('[realContourLines] Стилей ещё нет, ждём','realContourLinesCounter=',realContourLinesCounter,'realContourLinesCounterLimit=',realContourLinesCounterLimit);
	if(realContourLinesCounter < realContourLinesCounterLimit){	// Это, б..., замыкание, ё... Ненавижу.
		realContourLinesCounter ++;
		setTimeout(realContourLines,100,maplibreMap);
	}
	else {
		console.log(`[realContourLines] ERROR: isStyleLoaded() returned false ${realContourLinesCounterLimit} times, no contours is drawn.`);
	};
};
}; // end function realContourLines

async function  waitMapLibreMap(Llayer){
// У этих придурков объект _glMap появляется в объекте l.maplibreGL только после .addTo(map)? Не, когда всё загрузится. Или на следующий оборот?
if(typeof Llayer.getMaplibreMap === 'function'){
	//console.log('[waitMapLibreMap] Это Leaflet слой maplibre',Llayer);
	const Mmap = Llayer.getMaplibreMap();
	if(Mmap === undefined) {
		//console.log('[waitMapLibreMap] но карты maplibre там нет','mapParm:',mapParm);
		setTimeout(waitMapLibreMap,100,Llayer);	// но карты maplibre там нет
	}
	else {
		//console.log('[waitMapLibreMap] и там есть карта maplibre','mapParm:',mapParm);
		realContourLines(Mmap);
	};
};
}; // end function  waitMapLibreMap

let mapObj;
if(typeof mapname === 'string') mapObj = savedLayers[mapname];
else mapObj = mapname;
if(mapObj instanceof L.LayerGroup) { 	// это layerGroup
	for(let layer of mapObj.getLayers()){
		//console.log('[contourLines] переданная карта maplibre многослойная, layer:',layer);
		waitMapLibreMap(layer);
	};
}
else waitMapLibreMap(mapObj);
//
}; // end function contourLines


function realDisplayMap(mapname,mapParm={}) {
/* Если всё это добро расписать в старом добром структурном стиле, а не как принято в javascript - всё хорошо ложится.
*/
// сделаем новый мультислой. Карта - всегда мультислой.
const multilayer = L.layerGroup();	// требуемая карта или составная часть карты 
multilayer.options.mapname = mapname;
// Получим параметры карты
const xhr = new XMLHttpRequest();
xhr.open('GET', tileCacheControlURI+'?getMapInfo='+encodeURIComponent(mapname), false); 	// Подготовим синхронный запрос
xhr.send();
if (xhr.status == 200) { 	// Успешно
	try {
		//console.log('[realDisplayMap] xhr.responseText:',xhr.responseText,'mapParm:',mapParm);
		mapParm = {...JSON.parse(xhr.responseText),...mapParm}; 	// объединяем параметры карты с переданными параметрами, так, что addParm переписывает соответствующие параметры карты
	}
	catch(err) { 	// 
		console.log('[realDisplayMap] xhr ERROR:',err);
		return;
	};
}
else {
	console.log('[realDisplayMap] xhr request ERROR:',xhr.status);
	return;
};
// используются ли векторные тайлы
const isVector = (mapParm.ContentType=='application/x-protobuf')
				 || (mapParm.ext=='pbf')
				 || (mapParm.ext=='mvt')
				 || (mapParm.vectorTileStyleFile!=null)
				 || (mapParm.vectorTileStyleURL!=null);

if(!mapParm.mapTiles && !isVector){	// не указано, как получать тайлы. Однако, если mvt - то там это указано в стиле?
	return;
};
multilayer.options.mapParm = mapParm;
//console.log('[realDisplayMap] mapname=',mapname,'isVector=',isVector,'mapParm:',mapParm);

if(!Array.isArray(mapParm.mapTiles)) {	// список способов получения тайлов - всегда массив
	mapParm.mapTiles = [mapParm.mapTiles];
};
for(let i=0; i<mapParm.mapTiles.length; i++){
	//console.log('[realDisplayMap] mapParm[',i,']:',mapParm.mapTiles[i]);
	if(typeof mapParm.mapTiles[i] !== "string") {	// тогда объект, ссылка на другую карту
		// Здесь мы создаём multilayer с начала, и в нем заведомо нет объектов.
		// Поэтому можно добавлять, не проверяя наличие
		const layer = realDisplayMap(mapParm.mapTiles[i].mapName,mapParm.mapTiles[i].mapParm);
		if(layer != null) {
			multilayer.addLayer(layer);
			if(typeof layer.options.javascriptOpen === "function") {
				layer.options.javascriptOpen(layer);
			};
		};
	}
	else {	// способ получения тайла этой карты, т.е., один слой мультислоя
		let minNativeZoom,maxNativeZoom;
		
		if(!mapParm.clientData || !mapParm.clientData.noAutoScaled){
			if(mapParm.minZoom>9){
				minNativeZoom = mapParm.minZoom;
				mapParm.minZoom = 9;
			};
			if(mapParm.maxZoom<16){
				maxNativeZoom = mapParm.maxZoom;
				mapParm.maxZoom += 2;
			};
		};
		let layerParm;
		if(isVector){ 
			layerParm = {	// здесь всё в стиле, и, например, указание minzoom даёт весёлые визуальные эффекты
				"style": mapParm.vectorTileStyleURL,
			};
		}
		else {
			layerParm = {
				"minZoom":mapParm.minZoom,
				"maxZoom":mapParm.maxZoom,
			};
			if(!mapParm.clientData || !mapParm.clientData.noAutoScaled){
				layerParm["minNativeZoom"] = minNativeZoom;
				layerParm["maxNativeZoom"] = maxNativeZoom;
			}
			// bounds в параметрах - только в растровой карте, потому что в векторной границы указываются
			// в стиле. К тому же имеется баг в векторных библиотеках - оно падает с сообщением
			// о неверном формате границ, хотя формат верный.
			// В Leaflet древний баг: антимередиан. Всё, что его пересекает, показывается криво
			// В частности, если bounds пересекает антимередиан, то вся карта будет за пределами границ,
			// и не будет запрашиваться.
			// К счастью, у нас GaladrielCache не станет получать тайлы за пределами границ, так что
			// Leaflet может запрашивать.
			// Однако, 
			// Caution: if the area crosses the antimeridian (often confused with the International Date Line),
			// you must specify corners outside the [-180, 180] degrees longitude range.
			if(mapParm.bounds && (JSON.stringify(mapParm.bounds)!='[]')) {
				//console.log('[realDisplayMap] mapParm.bounds:',JSON.stringify(mapParm.bounds));
				let leftTop = {};
				leftTop.lng = mapParm.bounds.leftTop.lng;	// а иначе оно ссылка, б...!
				leftTop.lat = mapParm.bounds.leftTop.lat;
				let rightBottom = {};
				rightBottom.lng = mapParm.bounds.rightBottom.lng;
				rightBottom.lat = mapParm.bounds.rightBottom.lat;
				if(mapParm.bounds.leftTop.lng>0 && mapParm.bounds.rightBottom.lng<=0){	// граница переходит антимередиан
					// Не вполне понятна глубинная суть этого деяния, но факт в том, что если не вычитать/прибавлять,
					// то не видны либо левые, либо правые части. А если ничего не делать - то не видно ничего.
					leftTop.lng -= 360;
					rightBottom.lng += 360;
				};
				layerParm.bounds = L.latLngBounds(leftTop,rightBottom);
			};
		};
		//layerParm.pane = 'tilePane';	// "By default the layer will be added to the map's overlay pane." Но на самом деле - карта и так добавляется в tilePane. Как-то оно там разбирается...
		////////////////////////////////
		//if(mapname=='waterkaartBatymetry') layerParm.pane = 'overlayPane';
		////////////////////////////////
		//console.log('[realDisplayMap] layerParm:',layerParm);

		let mapTilesURIthis;
		if(mapParm.r) mapTilesURIthis = mapParm.mapTiles[i].replace('{map}',mapParm.r.trim());	// нужно, как минимум, для COVER.
		else mapTilesURIthis = mapParm.mapTiles[i].replace('{map}',mapname);
		if(mapParm.requestOptions) mapTilesURIthis = mapTilesURIthis.replace('{options}',JSON.stringify(mapParm.requestOptions));
		else mapTilesURIthis = mapTilesURIthis.replace('{options}','');
		if(mapParm.ext)	mapTilesURIthis = mapTilesURIthis.replace('{ext}',mapParm.ext);
		//console.log('[realDisplayMap] mapTilesURIthis:',mapTilesURIthis);

		let layer;
		if((mapParm.epsg && String(mapParm.epsg).indexOf('3395')!=-1)||(mapname.indexOf('EPSG3395')!=-1)) {
			layer = L.tileLayer.Mercator(mapTilesURIthis, layerParm);
		}
		else if(isVector) { 	// векторные тайлы
			if(typeof L.maplibreGL === 'undefined'){	// если ещё не загружено
			//if(typeof L.mapboxGL === 'undefined'){	// если ещё не загружено
				let link = document.createElement('link');
				link.type = 'text/css';
				link.href = 'style.css';
				link.rel = 'maplibre-gl/dist/mapbox-gl.css';
				//link.rel = 'mapbox-gl-js/dist/mapbox-gl.css';
				document.head.appendChild(link);
				if(!(mapboxGLscript=loadScriptSync("maplibre-gl/dist/maplibre-gl.js"))) return;	// Нахрена присваивать глобальной переменной, которая нигде не используется -- неясно, но без этого возникает ошибка при закрытии карты.
				if(!(mapboxLeafletscript=loadScriptSync("maplibre-gl-leaflet/leaflet-maplibre-gl.js"))) return;
				//if(!(mapboxGLscript=loadScriptSync("mapbox-gl-js/dist/mapbox-gl.js"))) return;
				//if(!(mapboxLeafletscript=loadScriptSync("mapbox-gl-leaflet/leaflet-mapbox-gl.js"))) return;
				console.log("[realDisplayMap] gl & gl-leaflet is loaded");
			};
			layer = L.maplibreGL(layerParm);
			//layer = L.mapboxGL(layerParm);
			//console.log('[realDisplayMap] mapParm:',mapParm);
			contourLines(layer,mapParm);
		}
		else {
			layer = L.tileLayer(mapTilesURIthis, layerParm);
		};
		//console.log('[realDisplayMap] layer:',layer);
		multilayer.addLayer(layer);
	};
};
//console.log('[realDisplayMap] mapParm:',mapParm);

// установим текущий масштаб в пределах возможного для указанной карты
// Это всё должно быть в displayMap, а не здесь?
if(! multilayer.options.zoom) {	// т.е., не устанавливали уже масштаб по какому-то слою
	let currZoom = map.getZoom();
	//console.log('[realDisplayMap] currZoom=',currZoom,'mapParm.maxZoom=',mapParm.maxZoom);
	if(mapParm.maxZoom < currZoom) {
		map.setZoom(mapParm.maxZoom);	// установим масштаб в видимость этого слоя
		multilayer.options.zoom = currZoom;	// запомним, какой был, чтобы потом восстановить
	}
	else if(mapParm.minZoom > currZoom) { 
		map.setZoom(mapParm.minZoom);
		multilayer.options.zoom = currZoom;
	}
	else multilayer.options.zoom = false;
};

//console.log('[realDisplayMap] multilayer:',multilayer);
if(multilayer.options.mapParm.bounds) {	// карте указаны рамки в описании. LayerGroup не имеет свойства bounds
	// Если карта составная, то в каждой составляющей - свои границы. Но к этому моменту те границы
	// уже сработали?, и здесь будет позиционировано в пределах границ объемлющей карты.
	const bondsPoint = isPointInBounds(map.getCenter(),multilayer.options.mapParm.bounds);
	if(bondsPoint !== true) map.setView(bondsPoint);
};
//
// javascript в загружаемом источнике на закрытие карты
// window.eval выполняет eval в глобальном контексте, в результате можно в eval объявить
// глобальные функции и переменные
if(mapParm.clientData && (typeof mapParm.clientData.javascriptClose  === "string")) {
	multilayer.options.javascriptClose = window.eval(mapParm.clientData.javascriptClose);	// eval должен возвращать функцию
};
// javascript в загружаемом источнике на открытие карты
if(mapParm.clientData && (typeof mapParm.clientData.javascriptOpen  === "string")) {
	multilayer.options.javascriptOpen = window.eval(mapParm.clientData.javascriptOpen);	// eval должен возвращать функцию
};
//console.log('[realDisplayMap] multilayer:',multilayer);
return multilayer;
}; // end function realDisplayMap


function isPointInBounds(point,bounds){
/* Находится ли точка в границах, а если нет - где ближайшая граница */
const nearestPoint = {"lat":null,"lng":null};
//console.log('[isPointInBounds] bounds:',bounds);
if(bounds instanceof L.LatLngBounds){	// это leaflet .getBounds()
	bounds.leftTop = {};
	bounds.leftTop.lat = bounds._northEast.lat;
	bounds.leftTop.lng = bounds._southWest.lng;
	bounds.rightBottom = {};
	bounds.rightBottom.lat = bounds._southWest.lat;
	bounds.rightBottom.lng = bounds._northEast.lng;
};
// Широта
if(point.lat > bounds.leftTop.lat){
	// Точка севернее рамки, т.е., не в границах.
	// Очевидно, ближайшая широтная граница рамки - северная
 	nearestPoint.lat = bounds.leftTop.lat;
}
else if(point.lat < bounds.rightBottom.lat){
	// Точка южнее рамки, т.е., не в границах.
	// Очевидно, ближайшая широтная граница рамки - южная
 	nearestPoint.lat = bounds.rightBottom.lat;
}
// иначе - точка по широте в пределах рамки

// Долгота
const dLon = Math.abs(bounds.leftTop.lng - bounds.rightBottom.lng);
if(dLon < 180) {	//console.log("рамка не пересекает антимеридиан");
	if(point.lng < bounds.leftTop.lng){
		//console.log("Точка западнее левой рамки и восточнее антимередиана, т.е., не в границах");
		const dL = bounds.leftTop.lng-point.lng;	// градусов между долготой точки и долготой левой границы рамки
		const dR = 360-bounds.rightBottom.lng-point.lng;	// оставшаяся часть круга, градусов между долготой точки и долготой правой границы рамки
		if(dL<dR){	// до западной границы рамки ближе, чем до восточной
		 	nearestPoint.lng = bounds.leftTop.lng;
		}
		else{
		 	nearestPoint.lng = bounds.rightBottom.lng;
		};
	}
	else if(point.lng > bounds.rightBottom.lng){
		//console.log("Точка восточнее правой рамки и западнее антимередиана, т.е., не в границах");
		const dR = point.lng - bounds.rightBottom.lng;	// градусов между долготой точки и долготой правой границы рамки
		const dL = 360-point.lng-bounds.leftTop.lng;	// оставшаяся часть круга, градусов между долготой точки и долготой левой границы рамки
		if(dL<dR){	// до западной границы рамки ближе, чем до восточной
		 	nearestPoint.lng = bounds.leftTop.lng;
		}
		else{
		 	nearestPoint.lng = bounds.rightBottom.lng;
		};
	};
}
else {	//console.log("рамка пересекает антимередиан");
	if((point.lng < bounds.leftTop.lng) && (point.lng > bounds.rightBottom.lng)){
		//console.log("Точка западнее левой рамки и восточнее правой, т.е., не в границах");
		const dL = Math.abs(bounds.leftTop.lng-point.lng);	// градусов между долготой точки и долготой левой границы рамки
		let dR = Math.abs(bounds.rightBottom.lng-point.lng);	// оставшаяся часть круга, градусов между долготой точки и долготой правой границы рамки
		//console.log('от левой рамки до точки:',dL,'от правой рамки до точки:',dR);
		if(dL<dR){	// до левой границы рамки ближе, чем до правой
		 	nearestPoint.lng = bounds.leftTop.lng;
		}
		else{
		 	nearestPoint.lng = bounds.rightBottom.lng;
		};
	};
};

if((nearestPoint.lat===null)&&(nearestPoint.lng===null)) return true;	// точка внутри рамки
else if(nearestPoint.lat===null){	//console.log(" точка в пределах широты, но не попадает по долготе");
	nearestPoint.lat = point.lat;
}
else if(nearestPoint.lng===null){	//console.log("точка в пределах долготы, но не попадает по широте");
	nearestPoint.lng = point.lng;
}
// иначе - точка вне рамки
return nearestPoint;
}; // end function isPointInBounds


function autoMapUpdate(mapLayer,start){
/* Автоматическое обновление карт с маленьким временем свежести.
mapLauer - LayerGroup карта
*/
if(!autoUpdateMap) return;
let mapLayers = mapLayer.getLayersRecursive(L.LayerGroup);	// вдруг карта составная? LayerGroup - это составляющая карта
mapLayers.push(mapLayer);
//console.log('[autoMapUpdate] mapLayers:',mapLayers);
for(layer of mapLayers){
	if( !layer.options.mapParm || !layer.options.mapParm.ttl || (layer.options.mapParm.ttl>autoUpdateMap)) continue;
	if(start){	// надо запустить обновление
		layer.options.autoUpdateMap = setInterval(() => {
			const mapLayer = layer;
			//console.log('Обновляется карта',mapLayer.options.mapname);
			mapLayer.eachLayer((layer)=>{
				if(layer instanceof L.TileLayer) layer.redraw();
			});
		}, layer.options.mapParm.ttl*1000);
	}
	else {	// надо остановить обновление
		if(layer.options.autoUpdateMap) clearInterval(layer.options.autoUpdateMap);
	};
};
}; // end function autoMapUpdate


function removeMap(mapname) {
/**/
mapname=mapname.trim();
if(!savedLayers[mapname]) return;	// например, в списке есть трек, но gpx был кривой, и слой не был создан
savedLayers[mapname].eachLayer((layer)=>{	// оно всегда LayerGroup?
	if(typeof layer.options.javascriptClose === 'function') {
		layer.options.javascriptClose(layer);
	};
});
if(typeof savedLayers[mapname].options.javascriptClose === 'function') {
	savedLayers[mapname].options.javascriptClose(savedLayers[mapname]);
};
savedLayers[mapname].remove(); 	// удалим слой с карты
if(savedLayers[mapname].options.zoom) { 
	map.setZoom(savedLayers[mapname].options.zoom); 	// вернём масштаб как было
	savedLayers[mapname].options.zoom = false;
}
autoMapUpdate(savedLayers[mapname],false) // Выключить автоматическое обновление
}; // end function removeMap


function showMapsToggle(all=false){
/*	переключает показ всех или выбранных карт в списке карт */
//console.log('[showMapsToggle] showMapsList:',showMapsList,showMapsTogglerTXT[0],showMapsToggler.innerHTML);
if(all || showMapsToggler.innerHTML == showMapsTogglerTXT[0]){	// текущий режим - "избранные карты" (на кнопке надпись: "все карты")
	for(let mapLi of mapList.children){
		//console.log('покажем все карты',mapLi.id);
		mapLi.hidden = false;	// покажем все карты
		if(showMapsList.includes(mapLi.id)){	// избранная карта
			mapLi.classList.add("showedMapName");
		}
	}
	showMapsToggler.innerHTML = showMapsTogglerTXT[1];	// сменим режим на "все карты"
}
else {	// текущий режим - "все карты" - покажем только избранные
	for(let mapLi of mapList.children){
		//console.log('покажем только избранные',mapLi.id,showMapsList.includes(mapLi.id));
		mapLi.hidden = false;	// при старте они все скрытые
		if(!showMapsList.includes(mapLi.id)){	// карта не в списке избранных
			mapLi.hidden = true;	// не покажем карту
		}
		mapLi.classList.remove("showedMapName");
	}
	showMapsToggler.innerHTML = showMapsTogglerTXT[0];	// сменим режим на "избранные карты"
}
}; // end function showMapsToggle


function displayMapBounds(){
/* Рисует границы показываемых карт
*/
mapBoundsLayer.remove().clearLayers();
map.eachLayer((layer)=>{
	//console.log('[displayMapBounds] layer:',layer);
	if(layer.options.mapParm && layer.options.mapParm.bounds){	// гы, там нет continue
		//console.log('[displayMapBounds] layer:',layer);
		
		let latlngs = [];
/*/		// Ниасилил, как правильно. Указание границ работает с вычитанием 360?
		// Так или иначе, но с вычитанием и границами карты выглядит сносно.
		// leftTop
		latlngs.push({"lat":layer.options.mapParm.bounds.leftTop.lat,"lng":layer.options.mapParm.bounds.leftTop.lng});
		// rightTop
		if(layer.options.mapParm.bounds.rightBottom.lng<layer.options.mapParm.bounds.leftTop.lng){
			latlngs.push({"lat":layer.options.mapParm.bounds.leftTop.lat,"lng":layer.options.mapParm.bounds.rightBottom.lng+360});
		}
		else {
			latlngs.push({"lat":layer.options.mapParm.bounds.leftTop.lat,"lng":layer.options.mapParm.bounds.rightBottom.lng});
		};
		// rightBottom
		if(layer.options.mapParm.bounds.rightBottom.lng<layer.options.mapParm.bounds.leftTop.lng){
			latlngs.push({"lat":layer.options.mapParm.bounds.rightBottom.lat,"lng":layer.options.mapParm.bounds.rightBottom.lng+360});
		}
		else {
			latlngs.push({"lat":layer.options.mapParm.bounds.rightBottom.lat,"lng":layer.options.mapParm.bounds.rightBottom.lng});
		};
		// leftBottom
		latlngs.push({"lat":layer.options.mapParm.bounds.rightBottom.lat,"lng":layer.options.mapParm.bounds.leftTop.lng});
/*/		
		// leftTop
		if(layer.options.mapParm.bounds.leftTop.lng>0 && layer.options.mapParm.bounds.rightBottom.lng<=0){	// граница переходит антимередиан
			latlngs.push({"lat":layer.options.mapParm.bounds.leftTop.lat,"lng":layer.options.mapParm.bounds.leftTop.lng-360});
		}
		else{
			latlngs.push({"lat":layer.options.mapParm.bounds.leftTop.lat,"lng":layer.options.mapParm.bounds.leftTop.lng});
		};
		// rightTop
		latlngs.push({"lat":layer.options.mapParm.bounds.leftTop.lat,"lng":layer.options.mapParm.bounds.rightBottom.lng});
		// rightBottom
		latlngs.push({"lat":layer.options.mapParm.bounds.rightBottom.lat,"lng":layer.options.mapParm.bounds.rightBottom.lng});
		// leftBottom
		if(layer.options.mapParm.bounds.leftTop.lng>0 && layer.options.mapParm.bounds.rightBottom.lng<=0){	// граница переходит антимередиан
			latlngs.push({"lat":layer.options.mapParm.bounds.rightBottom.lat,"lng":layer.options.mapParm.bounds.leftTop.lng-360});
		}
		else{
			latlngs.push({"lat":layer.options.mapParm.bounds.rightBottom.lat,"lng":layer.options.mapParm.bounds.leftTop.lng});
		};
//		
		const leftTopPixel = map.latLngToLayerPoint(layer.options.mapParm.bounds.leftTop);
		const rightTopPixel = map.latLngToLayerPoint({"lat":layer.options.mapParm.bounds.leftTop.lat,"lng":layer.options.mapParm.bounds.rightBottom.lng});
		const leftBottomPixel = map.latLngToLayerPoint({"lat":layer.options.mapParm.bounds.rightBottom.lat,"lng":layer.options.mapParm.bounds.leftTop.lng});
		//console.log('[displayMapBounds] leftTopPixel:',leftTopPixel,'rightTopPixel:',rightTopPixel,'leftBottomPixel:',leftBottomPixel);

		L.polygon(latlngs, {"color": "fuchsia", "weight":12, "fill":false, "opacity":0.2})
		.bindTooltip( layer.options.mapParm.humanName[appLocale] || layer.options.mapParm.humanName.en,
			{"permanent":true,
			"direction":'center',
			"className":'mapBoundsTooltip',
			//"offset":[((leftTopPixel.x-rightTopPixel.x)/2)+50,((leftTopPixel.y-leftBottomPixel.y)/2)+20]
			"offset":[0,((leftTopPixel.y-leftBottomPixel.y)/2)]
		}).addTo(mapBoundsLayer);
	};
});
//console.log('[displayMapBounds] mapBoundsLayer:',mapBoundsLayer.getLayers().length,mapBoundsLayer);
if(mapBoundsLayer.getLayers().length) mapBoundsLayer.addTo(map);
}; // end function displayMapBounds


function displayMapBoundsOFF(){
mapBoundsLayer.remove().clearLayers();
}; // end function displayMapBoundsOFF()


function mapInfoOpen(event){
/* Global appLocale
*/
event.stopPropagation();
//console.log('[mapInfoOpen] кликнули на ',event);
if(mapInfo.style.display != 'none') mapInfoClose();
mapInfo.style.display = '';
document.body.addEventListener('click',(event)=>{
	mapInfoClose();
},{'once':true});	// закрывать меню по клику в любом месте
//console.log('[mapInfoOpen] mapInfo:',mapInfo);
fetch(tileCacheControlURI+'?getMapDescription='+encodeURIComponent(event.target.parentElement.attributes.id.value))
.then(response => {
	if (!response.ok) {
		throw new Error(`getMapDescription http error! Status: ${response.status}`);
	};
	return response.json();
})
.then(mapInfoData => {
	//console.log('[mapInfoOpen] mapInfoData:',mapInfoData);
	let innerHTML = '';
	if(Object.keys(mapInfoData).length>1) {
		innerHTML += `<div style="float:right;font-size:75%;margin:1rem;">${mapInfoSourceTXT}: ${event.target.parentElement.attributes.id.value}</div>`;
		innerHTML += `<h2>${mapInfoComplexTXT}:</h2>`;
	};
	for(let mapname in mapInfoData){
		if(typeof mapInfoData[mapname].humanName[appLocale] === "undefined"){
			innerHTML += `<h3>${mapInfoData[mapname].humanName['en']}</h3>`;
		}
		else {
			innerHTML += `<h3>${mapInfoData[mapname].humanName[appLocale]}</h3>`;
		};
		if(typeof mapInfoData[mapname].mapDescription[appLocale] === "undefined"){
			innerHTML += mapInfoData[mapname].mapDescription['en'].replace(/(?:\r\n|\r|\n)/g, '<br>')+'<br>';
		}
		else {
			innerHTML += mapInfoData[mapname].mapDescription[appLocale].replace(/(?:\r\n|\r|\n)/g, '<br>')+'<br>';
		};
		if(typeof mapInfoData[mapname].epsg !== "undefined") innerHTML += `${mapInfoProjectionTXT} ${mapInfoData[mapname].epsg}<br>`;
		if(typeof mapInfoData[mapname].minZoom !== "undefined") innerHTML += `${mapInfoMinZoomTXT}: ${mapInfoData[mapname].minZoom}<br>`;
		if(typeof mapInfoData[mapname].maxZoom !== "undefined") innerHTML += `${mapInfoMaxZoomTXT}: ${mapInfoData[mapname].maxZoom}<br><br>`;
		if(typeof mapInfoData[mapname].bounds !== "undefined") innerHTML += `${mapInfoBordersTXT}, ${latTXT}, ${longTXT}: ${mapInfoData[mapname].bounds.leftTop.lat}, ${mapInfoData[mapname].bounds.leftTop.lng} &mdash; ${mapInfoData[mapname].bounds.rightBottom.lat}, ${mapInfoData[mapname].bounds.rightBottom.lng}`;
		innerHTML += '<div style="font-size:75%;text-align:right;margin:1rem;">';
		if(typeof mapInfoData[mapname].vectorTileStyleURL !== "undefined") {
			innerHTML += `${mapInfoVectorTXT}<br>${mapInfoStyleFileTXT}: `;
			if(URL.canParse(mapInfoData[mapname].vectorTileStyleURL)){
				innerHTML += mapInfoData[mapname].vectorTileStyleURL;
			}
			else{
				innerHTML += (window.location.origin+mapInfoData[mapname].vectorTileStyleURL);
			}
			innerHTML += '<br>';
		}
		else innerHTML += `${mapInfoRasterTXT}<br>`;
		if(mapInfoData[mapname].online) {
			innerHTML += `${mapInfoLoadableTXT}<br>`;
			if(typeof mapInfoData[mapname].proxy !== "undefined") innerHTML += `${mapInfoUseProxyTXT} ${mapInfoData[mapname].proxy}<br>`;
		};
		innerHTML += `${mapInfoSourceTXT}: ${mapInfoData[mapname].mapDescriptionFile}<br>`;
		innerHTML += `${mapInfoDataTXT}: ${mapInfoData[mapname].mapDataFile}<br>`;
		innerHTML += '</div>'
	};
	
	//console.log('[mapInfoOpen] innerHTML=',innerHTML);
	mapInfo.innerHTML = innerHTML;
})
.catch(error => {
	console.error('getMapDescription fetch data Error:', error);
});
}; // end function mapInfoOpen

function mapInfoClose(){
//console.log('[mapInfoClose]');
mapInfo.style.display = 'none';
mapInfo.innerHTML = '';
}; // end function mapInfoClose


// Функции выбора - удаления треков
async function selectTrack(node,trackList,trackDisplayed,displayTrack) { 	
/* Выбор трека из списка имеющихся. 
node - объект li, элемент списка имеющихся, который выбрали
trackList - объект ul, список имеющихся
trackDisplayed - объект ul, список выбранных
displayTrack - функция показывания того, что соответствует выбранному элементу
global deSelectTrack() currentTrackShowedFlag
*/
//console.log('[selectTrack] trackDisplayed.firstChild:',trackDisplayed.firstChild);
trackDisplayed.insertBefore(node,trackDisplayed.firstChild); 	// из списка доступных в список показываемых (объект, на котором событие, добавим в конец потомков mapDisplayed)
node.onclick = function(event){deSelectTrack(event.currentTarget,trackList,trackDisplayed,displayTrack);};
if(node.title.toLowerCase().indexOf("current")!= -1) {	// текущий трек
	currentTrackShowedFlag = 'loading'; 	// укажем, что трек сейчас загружается
	startCurrentTrackUpdateProcess();	// запустим обновление трека
}
//console.log('[selectTrack] node.title=',node.title,currentTrackShowedFlag);
displayTrack(node); 	// создадим трек
}; // end function selectTrack


async function deSelectTrack(node,trackList,trackDisplayed,displayTrack) {
/* Прекращение показа трека, и возврат его в список имеющихся. Получим объект
node - объект li, элемент списка показываемых, который выбрали для непоказывания
trackList - объект ul, список имеющихся, куда надо вернуть node
global selectTrack()
*/
if(node.title.toLowerCase().indexOf("current")!= -1) {	// текущий трек
	if(!currTrackSwitch.checked){	// Текущий трек не всегда показывается
		if(currentTrackUpdateProcess) {
			clearInterval(currentTrackUpdateProcess);	
			currentTrackUpdateProcess = null;
		};
		if(currentWaitTrackUpdateProcess) {	// хотя его и не должно быть
			clearInterval(currentWaitTrackUpdateProcess);	// 
			currentWaitTrackUpdateProcess = null;
		};
	};
};

var li = null;
for (var i = 0; i < trackList.children.length; i++) { 	// для каждого потомка списка trackList
	li = trackList.children[i]; 	// взять этого потомка
	var childTitle = li.innerHTML;
	if (childTitle > node.innerHTML) { 	// если наименование потомка дальше по алфавиту, чем наименование того, на что кликнули
		break;
	}
	li = null;
}
trackList.insertBefore(node,li); 	// перенесём перед тем, на котором обломался цикл, или перед концом
//console.log(node);
node.onclick = function(event){selectTrack(event.currentTarget,trackList,trackDisplayed,displayTrack);};
removeMap(node.innerHTML);
// Однако, удаляемое могло быть сейчас редактируемым маршрутом
//console.log('Сейчас удалили слой ',node.innerHTML,savedLayers[node.innerHTML]);
//console.log('однако, имеется currentRoute',currentRoute);
//if(currentRoute && (currentRoute._leaflet_id == savedLayers[node.innerHTML]._leaflet_id)){
//if(currentRoute && (currentRoute == savedLayers[node.innerHTML])){	// оно ссылается на одно?
	cancelEditing();	// там удаляется currentRoute и очищается имя сохраняемого файла. Так делать всегда?
//};
}; // end function deSelectTrack


function displayTrack(trackNameNode,changed=false) {
/* рисует трек с именем в trackNameNode
global trackDirURI, window, currentTrackName
*/
var trackName = trackNameNode.innerText.trim();
//console.log('[displayTrack] trackName=',trackName,'currentTrackName=',currentTrackName,'savedLayers[trackName]',savedLayers[trackName]);
if(!changed && savedLayers[trackName]) {
	//console.log('[displayTrack] Рисуем на карте из кеша trackName=',trackName);
	// нарисуем его на карте. Текущий трек всегда перезагружаем в updateCurrTrack
	if(map.hasLayer(savedLayers[trackName])) savedLayers[trackName].redraw();
	else savedLayers[trackName].addTo(map);
}
else {
	// просто спрашиваем у сервера файл, там не ответчик
	var options = {featureNameNode : trackNameNode};
	var xhr = new XMLHttpRequest();
	//console.log('[displayTrack] Загружаем новый файл trackName=',trackDirURI+'/'+trackName+'.gpx');
	xhr.open('GET', trackDirURI+'/'+encodeURIComponent(trackName+'.gpx'), true); 	// В этом грёбаном языке специальная грёбаная функция для получения правильного url портит [], которые являются частью ipv6
	xhr.overrideMimeType( "application/gpx+xml; charset=UTF-8" ); 	// тупые уроды из Mozilla считают, что если не указан mime type ответа -- то он text/xml. Файлы они, очевидно, не скачивают.
	xhr.send();
	xhr.onreadystatechange = function() { // trackName - внешняя
		if (this.readyState != 4) return; 	// запрос ещё не завершился, покинем функцию
		if (this.status != 200) { 	// запрос завершлся, но неудачно
			console.log('[displayTrack] To request file '+trackDirURI+'/'+trackName+' server return '+this.status);
			if(trackNameNode.title.toLowerCase().indexOf("current")!= -1) {	// текущий трек
				currentTrackShowedFlag = 'error'; 	// укажем, что с треком что-то не то
			}
			return; 	// что-то не то с сервером
		}
		// В злопаршивом Javascript символ /00 пробельным не является
		//console.log('|'+this.responseText.slice(-10)+'|');
		let str = this.responseText.replace(/\0+|\0+/g, '').trim().slice(-12);
		//console.log('[displayTrack] |'+str+'|');
		if(!str) return;
		
		if(savedLayers[trackName]) savedLayers[trackName].remove();	
		if(str.indexOf('</gpx>') == -1) {	// может получиться кривой gpx -- по разным причинам
			//console.log('кривой gpx',str);
			// незавершённый gpx - дополним до конца. Поэтому скачиваем сами, а не omnivore
			let responseText = this.responseText.replace(/\0+|\0+/g, '').trim();	// потому что this.responseText не строка, а getter-only property, хрен его знает, что это значит и зачем.
			if(str.endsWith('</trkpt>')) responseText += '\n  </trkseg>\n </trk>\n</gpx>';	// точку оно всегда? успевает записать
			else if(str.endsWith('</trkseg>')) responseText += '\n </trk>\n</gpx>';
			else responseText += '\n</gpx>';	// на самом деле, здесь </metadata>, т.е., gpxlogger запустился, но ничего не пишет: нет gpsd, нет спутников, нет связи...
			savedLayers[trackName] = omnivore.gpx.parse(responseText,options);
		}
		else {
			savedLayers[trackName] = omnivore.gpx.parse(this.responseText,options); 	// responseXML иногда почему-то кривой
		};
		//console.log(savedLayers[trackName]);
		savedLayers[trackName].addTo(map); 	// нарисуем его на карте
	}; // end function xhr.onreadystatechange
};
}; // end function displayTrack


async function displayRoute(routeNameNode,changed=false) {
/* рисует маршрут или места с именем routeName 
global routeDirURI map window
*/
let routeName = routeNameNode.innerText.trim();
let options = {featureNameNode : routeNameNode};
if(!changed && savedLayers[routeName]) {
	// нарисуем его на карте. 
	if(map.hasLayer(savedLayers[routeName])) savedLayers[routeName].redraw();
	else savedLayers[routeName].addTo(map);
}
else {
	// удалим с карты объект с этим именем, потому что дальше с этим именем
	// будет другой объект
	if(savedLayers[routeName]) savedLayers[routeName].remove();	
	var routeType =  routeName.slice((routeName.lastIndexOf(".") - 1 >>> 0) + 2).toLowerCase(); 	// https://www.jstips.co/en/javascript/get-file-extension/ потому что там нет естественного пути
	//console.log('[displayRoute] routeName=',routeName,'routeType=',routeType);
	switch(routeType) {
	case 'gpx':
		savedLayers[routeName] = omnivore.gpx(routeDirURI+'/'+routeName,options);
		if(! updateRoutesInterval) {
			// Запуск динамического обновления показываемых маршрутов,
			// если ещё не запущен и есть адрес обновлялки
			if(updateRouteServerURI) updateRoutesInterval = setInterval(realtime,3000,updateRouteServerURI,routeUpdate);
		};
		break;
	case 'kml':
		savedLayers[routeName] = omnivore.kml(routeDirURI+'/'+routeName,options);
		break;
	case 'csv':
		savedLayers[routeName] = omnivore.csv(routeDirURI+'/'+routeName,options);
		break;
	};
	// В любом случае будет возвращён мультислой, хотя, возможно, и пустой.
	// Но файл загружается асинхронно, и может быть очень большим. Поэтому нельзя
	// узнать, успешно загрузился файл, или нет.
	//console.log('[displayRoute] Загружается routeName=',routeName,'savedLayers[routeName]:',savedLayers[routeName]);
	if(!('properties' in savedLayers[routeName])) savedLayers[routeName].properties = {};
	savedLayers[routeName].properties.fileName = routeName;	// имя файла. А нафига? А чтобы потом понять, что объект загружен из файла. А вот и нет - затем, чтобы понять, что загружаем уже загруженное, и его надо поменять.
	// в любом случае придётся показать мультислой: здесь мы ещё не знаем, есть там слои, или нет.
	savedLayers[routeName].addTo(map);
};
}; // end function displayRoute


async function updateCurrTrack() {
// Получим GeoJSON - ломаную из скольких-то последних путевых точек, или false, если с последнего
// обращения нет новых точек
// в формате GeoJSON
//console.log('[updateCurrTrack]',currentTrackServerURI,currentTrackName);
var xhr = new XMLHttpRequest();
xhr.open('GET', currentTrackServerURI+'?currTrackName='+encodeURIComponent(currentTrackName), true); 	// Подготовим асинхронный запрос
xhr.send();
xhr.onreadystatechange = function() { // 
	if (this.readyState != 4) return; 	// запрос ещё не завершился, покинем функцию
	if (this.status != 200) { 	// запрос завершлся, но неудачно
		//console.log('Server return '+this.status+'\ncurrentTrackServerURI='+currentTrackServerURI+'\ncurrTrackName='+currentTrackName+'\n\n');
		console.log('To [updateCurrTrack] server return '+this.status+' instead '+currentTrackName+' last segment.');
		if(typeof loggingIndicator != 'undefined'){ 	// лампочка в интерфейсе
			loggingIndicator.style.color='red';
			loggingIndicator.innerText='\u2B24';
		}
		return; 	// что-то не то с сервером
	}
	//console.log(this.responseText);
	let resp = {};
	try {
		resp = JSON.parse(this.responseText);
	}
	catch(err) {
		if(this.responseText.trim()) console.log('Bad data to update current track:'+this.responseText+';',err.message)
	}
	//console.log('[updateCurrTrack]',resp);
	if(resp.logging){ 	// лог пишется
		if(typeof loggingIndicator != 'undefined'){ 	// лампочка в интерфейсе
			loggingIndicator.style.color='green';
			loggingIndicator.innerText='\u2B24';
		}
		if(resp.pt) { 	// есть данные
			if(savedLayers[currentTrackName]) {	// может не быть, если, например, показ треков выключили, но выполнение currentTrackUpdate уже запланировано. Вообще-то, так быть не может, но сообщение об отсутствии иногда наблюдается. А иногда -- нет.
				if(savedLayers[currentTrackName] instanceof L.LayerGroup) { 	// это layerGroup
					savedLayers[currentTrackName].getLayers()[0].addData(resp.pt); 	// добавим полученное к слою с текущим треком
					//console.log(savedLayers[currentTrackName].getLayers()[0]);
				}
				else savedLayers[currentTrackName].addData(resp.pt); 	// добавим полученное к слою с текущим треком
			}
		}
	}
	else { 	// лог не пишется
		if(typeof loggingIndicator != 'undefined'){
			// лампочка и переключатель в интерфейсе
			if((typeof loggingSwitch !== 'undefined') && loggingSwitch.checked){ 	// этот клиент сказал писать трек, состояние loggingSwitch восстанавливается из куки в index.php
				loggingIndicator.style.color='red';
				loggingIndicator.innerText='\u2B24';
				loggingRun();	// попытаемся запустить запись трека
			}
			else {
				loggingIndicator.style.color='';
				loggingIndicator.innerText='';
				loggingIndicator.style.color=null;
				if(currentWaitTrackUpdateProcess){
					clearInterval(currentWaitTrackUpdateProcess);	
					console.log('[updateCurrTrack] Не должно быть currentWaitTrackUpdateProcess, но он был. Убили, запускаем.');
				};
				if(currTrackSwitch.checked) startCurrentWaitTrackUpdateProcess();	// Текущий трек всегда показывается
			};
		};
	};
};
}; // end function updateCurrTrack




// Загрузчик и подготовка задания
function XYentryFields(element){
/* Генерация полей ввода списка тайлов для загрузки
element - второе поле input номера тайла
*/
//console.log(element.parentNode);
const xElement = element.parentNode.previousElementSibling.getElementsByTagName('input')[0];
const x = xElement.value;
const y = element.value;
if(x && y){
	const tileId = 'gridTile_'+parseInt(dwnldJobZoom.innerText)+'_'+x+'_'+y;
	const tile = document.getElementById(tileId);
	if(tile) tile.classList.add('selectedTile');	// выделим тайл, что он указан

	let newXinput = element.parentNode.previousElementSibling.cloneNode(true); 	// клонируем div с x
	newXinput.getElementsByTagName('input')[0].value = ''; 	// очистим поле ввода
	let newYinput = element.parentNode.cloneNode(true); 	// клонируем div с y
	newYinput.getElementsByTagName('input')[0].value = ''; 	// очистим поле ввода
	element.parentNode.parentNode.insertBefore(newXinput,element.parentNode.nextElementSibling); 	// вставляем после последнего. Да, вот так через задницу, потому что это javascript
	element.parentNode.parentNode.insertBefore(newYinput,newXinput.nextElementSibling);
	newXinput.getElementsByTagName('input')[0].focus(); 	// установим курсор ввода
}
else {
	xElement.value = '';
	element.value = '';
	xElement.focus();
	tileGrid.redraw();
}
// Узнаем, есть ли так или иначе указанные тайлы
const tileXs = dwnldJob.getElementsByClassName("tileX");
const tileYs = dwnldJob.getElementsByClassName("tileY");
downJob = false;
for (var k = 0; k < tileXs.length; k++) {
	if(tileXs[k].value && tileYs[k].value){
		downJob = true; 	// выставим флаг, что идёт подготовка задания на скачивание
		break;
	}
}
if( !downJob) dwnldJobZoom.innerHTML = map.getZoom(); 	// текущий масштаб отобразим на панели скачивания
}; // end function XYentryFields


function loaderListPopulate(element){
/* Заполнение списка тайлов для загрузки путём клика по тайлу 
element - это div с подписью номера тайла, по нему кликают
*/
//console.log(element);
if(parseInt(dwnldJobZoom.innerText) != map.getZoom()) return;	// текущий масштаб -- не тот, для которого начали создавать задание
let e,x,y,z;
//[x,y] = element.innerText.split("\n")[1].split('/').map(item=>parseInt(item));
[e,z,x,y] = element.parentElement.id.split("_");	// gridTile_12_2474_1288, квадрат сетки
//console.log('z=',z,'x=',x,'y=',y);
const tileXs = dwnldJob.getElementsByClassName("tileX");
const tileYs = dwnldJob.getElementsByClassName("tileY");
if(element.parentElement.classList.contains('selectedTile')){	// квадрат сетки выделен, кликнутый тайл должен быть в списке
	element.parentElement.classList.remove('selectedTile');	// снимем выделение
	for (var k = 0; k < tileXs.length; k++) {	// проверим весь список, ибо номер мог быть внесён несколько раз руками
		if((tileXs[k].value==x) && (tileYs[k].value==y)){	// найдём номер тайла в списке тайлов
			tileXs[k].value = '';	// удалим этот номер из списка
			tileYs[k].value = '';
		}
	}
}
else {	// кликнутого тайла, вероятно, нет в списке
	const lastX = tileXs[tileXs.length-1];	// заполним последние поля списка номером кликнутого тайла
	const lastY = tileYs[tileYs.length-1];
	lastX.value = x;
	lastY.value = y;
	XYentryFields(lastY);
};
}; // end function loaderListPopulate


function coloreSelectedTiles(){
const zoom = parseInt(dwnldJobZoom.innerText);
if(zoom != map.getZoom()) return;	// текущий масштаб -- не тот, для которого создано задание
const tileXs = dwnldJob.getElementsByClassName("tileX");
const tileYs = dwnldJob.getElementsByClassName("tileY");
for (var k = 0; k < tileXs.length; k++) {
	if(tileXs[k].value && tileYs[k].value){
		const tileId = 'gridTile_'+zoom+'_'+tileXs[k].value+'_'+tileYs[k].value;
		const tile = document.getElementById(tileId);
		if(tile) tile.classList.add('selectedTile');
	}
}
}; // end function coloreSelectedTiles


function chkColoreSelectedTile(tileEvent){
const zoom = parseInt(dwnldJobZoom.innerText);
//console.log('zoom=',zoom,'z=',tileEvent.coords.z);
if(zoom != tileEvent.coords.z) return;	// текущий масштаб -- не тот, для которого создано задание
//console.log('zoom=',zoom,'z=',tileEvent.coords.z,tileEvent.tile, tileEvent.coords);
const tileXs = dwnldJob.getElementsByClassName("tileX");
const tileYs = dwnldJob.getElementsByClassName("tileY");
downJob = false;
for (var k = 0; k < tileXs.length; k++) {
	if(tileXs[k].value && tileYs[k].value){
		const tileId = 'gridTile_'+zoom+'_'+tileXs[k].value+'_'+tileYs[k].value;
		const tile = document.getElementById(tileId);
		if(tile) tile.classList.add('selectedTile');
		downJob = true; 	// выставим флаг, что идёт подготовка задания на скачивание
	}
}
if( !downJob) dwnldJobZoom.innerHTML = map.getZoom(); 	// текущий масштаб отобразим на панели скачивания
}; // end function chkColoreSelectedTile


function createDwnldJob() {
/* Собирает задания на загрузку: для каждой карты кладёт на сервер csv с номерами тайлов текущего масштаба.
Считается, что номера тайлов указываются на сфере */
//alert('submit '+mapDisplayed.children.length+' maps');
let tileXs = dwnldJob.getElementsByClassName("tileX");
let tileYs = dwnldJob.getElementsByClassName("tileY");
let zoom = dwnldJobZoom.innerText;
let XYs = '', XYsE = '', xhr = [];

// Создадим задание для каждой найденной карты
for (let i = 0; i < mapDisplayed.children.length; i++) { 	// для каждого потомка списка mapDisplayed
	const mapname = mapDisplayed.children[i].id; 	// 
	// Получим параметры карты, вдруг там что
	// Однако, наличие функций $getURL и $getTile нас не должно волновать - мало ли для чего
	// нам нужно задание для загрузчика
	fetch(tileCacheControlURI+'?getMapInfo='+encodeURIComponent(mapname))
	.then(response => {
		if (!response.ok) {
			throw new Error(`getMapInfo http error! Status: ${response.status}`);
		};
		return response.json();
	})
	.then(mapParm => {
		//console.log('[createDwnldJob] mapParm:',mapParm);
		let uri;
		if((mapname.indexOf('EPSG3395')!=-1) || ((mapParm!=null)&&(mapParm.EPSG==3395))) {	// карта - на эллипсоиде, пишем тайлы на один ниже
			if(!XYsE.length) {
				var minY = 524288;	// max Y on zoom 19
				for (var k = 0; k < tileXs.length; k++) {
					if(+tileXs[k].value && +tileYs[k].value) {		
						XYsE += tileXs[k].value+','+String(+tileYs[k].value+1)+'\n'; 	// тайлы на 1 ниже,
						if(tileYs[k].value < minY) minY = tileYs[k].value;
					};
				};
				// а потом добавим верхний ряд
				for (var k = 0; k < tileXs.length; k++) {
					if(+tileXs[k].value && +tileYs[k].value) {		
						if(tileYs[k].value == minY) XYsE += tileXs[k].value+','+tileYs[k].value+'\n';
					}
				}
			}
			//console.log(XYsE);
			uri = '?loaderJob='+mapname+'.'+zoom+'&xys='+XYsE+'&infinitely';
		}
		else {	// карта - неизвестно на чём, считаем, что на сфере, пишем тайлы как есть
			if(!XYs.length) {
				for (var k = 0; k < tileXs.length; k++) {
					if(tileXs[k].value && tileYs[k].value) 	XYs += tileXs[k].value+','+tileYs[k].value+'\n';
				};
			};
			//console.log(XYs);
			uri = '?loaderJob='+encodeURIComponent(mapname+'.'+zoom)+'&xys='+encodeURIComponent(XYs)+'&infinitely';
		}
		//console.log('[createDwnldJob] uri=',uri);
		
		fetch(tileCacheControlURI+uri)
		.then(response => {
			if (!response.ok) {
				throw new Error(`Create loager job http error! Status: ${response.status}`);
			};
			return response.json();
		})
		.then(response => {
			if(response && response['status'] == '0') { 	// первым должен идти код возврата eval запуска загрузчика
				loaderIndicator.style.color='green';
				loaderIndicator.style.cursor='pointer';
				//loaderIndicator.innerText='\u263A';
				loaderIndicator.title=downloadLoaderIndicatorOnTXT;
				loaderIndicator.onclick=function (){chkLoaderStatus('stop');};
			}
			else {
				loaderIndicator.style.color='red';
				loaderIndicator.style.cursor='pointer';
				//loaderIndicator.innerText='\u2639';
				loaderIndicator.title=downloadLoaderIndicatorOffTXT;
				loaderIndicator.onclick=function (){chkLoaderStatus('start');};
			}
			if(response && response['jobName']) dwnldJobList.innerHTML += '<li>' + response['jobName'] + '</li>\n';
		})
		.catch(error => {
			console.error('Create loager job Error:', error);
		});
	})
	.catch(error => {
		console.error('getMapInfo fetch data Error:', error);
	});
};
}; 	// end function createDwnldJob


function chkLoaderStatus(restartLoader=false) {
/*  */
let xhr = new XMLHttpRequest();
let url = '?loaderStatus';
dwnldJobList.innerHTML = '';
if(restartLoader=='start') {
	url += '&restartLoader&infinitely';
	dwnldJobList.innerHTML = 'Send (re)start loader<br>';
}
else if(restartLoader=='stop') {
	url += '&stopLoader';
	dwnldJobList.innerHTML = 'Send stop loader<br>';
};
xhr.open('GET', tileCacheControlURI+url, true); 	// Подготовим асинхронный запрос
xhr.send();
xhr.onreadystatechange = function() { // 
	if (this.readyState != 4) return; 	// запрос ещё не завершился
	if (this.status != 200) return; 	// что-то не то с сервером
	//console.log('[chkLoaderStatus] this.response=',this.response);
	let {loaderRun,jobsInfo} = JSON.parse(this.response);
	//console.log('[chkLoaderStatus]',loaderRun,jobsInfo,JSON.stringify(jobsInfo));
	
	//loaderIndicator.innerText='\u2B24 ';
	if((JSON.stringify(jobsInfo)!=='[]') && !loaderRun){	// есть задания, но загрузчик не запущен. Менее через жопу выяснить, не пуст ли объект в этом кривом языке нельзя. При том, что в PHP оно всегда array.
	//if(jobsInfo.length && !loaderRun){	// есть задания, но загрузчик не запущен
		loaderIndicator.style.color='red';
		loaderIndicator.style.cursor='pointer';
		//loaderIndicator.innerText='\u2639';
		loaderIndicator.title=downloadLoaderIndicatorOffTXT;
		loaderIndicator.onclick=function (){chkLoaderStatus('start');};
		let liS = '';
		for(let jobName in jobsInfo){
			liS += `<li  ><span>${jobName} </span><span style='font-size:75%;'>${jobsInfo[jobName]}%</span></li>`;
		}
		dwnldJobList.innerHTML += liS;
	}
	else if(loaderRun){	// загрузчик запущен
		loaderIndicator.style.color='green';
		loaderIndicator.style.cursor='pointer';
		//loaderIndicator.innerText='\u263A';
		loaderIndicator.title=downloadLoaderIndicatorOnTXT;
		loaderIndicator.onclick=function (){chkLoaderStatus('stop');};

		let liS = '';
		for(let jobName in jobsInfo){
			liS += `<li  ><span>${jobName} </span><span style='font-size:75%;'>${jobsInfo[jobName]}%</span></li>`;
		}
		dwnldJobList.innerHTML += liS;
	}
	else {	// загрузчик не запущен и нет заданий - загрузчик не должен быть запущен
		loaderIndicator.style.color='gray';
		loaderIndicator.style.cursor='default';
		loaderIndicator.onclick=null;
		loaderIndicator.title='';
		//loaderIndicator.innerText=' ';
	}
}; // end function onreadystatechange
}; // end function chkLoaderStatus





// Функции рисования маршрутов
function routeControlsDeSelect() {
// сделаем невыбранными кнопки управления рисованием маршрута. Они должны быть и так не выбраны, но почему-то...
for(let element of document.getElementsByName('routeControl')){
	element.checked=false;
	element.disabled=true;
}   
}; // end function routeControlsDeSelect


function pointsControlsButtonImgs(){
/* Назначает картинку на кнопки в соответствии со значением button.value 
Картинки - из leaflet-omnivore/symbols, получаются от сервера иконок в leaflet-omnivore.js
*/
for(let button of pointsButtons.querySelectorAll('button')){	// кнопки установки маркеров
	const gpxtype = button.value;
	getGPXicon(gpxtype).then((icon)=>{	// leaflet-omnivore.js
		let imgURL;
		if(icon instanceof L.Icon.Default) imgURL = 'leaflet/images/marker-icon.png';	// iconUrl от L.Icon.Default ...., от leaflet/images/, а не от текущего каталога.
		else imgURL = icon.options.iconUrl;	// картинка для этого типа есть
		button.firstElementChild.src = imgURL;
	});
};
}; // end function pointsControlsButtonImgs

function pointsControlsDisable(){
for(let button of pointsButtons.querySelectorAll('button')){	// кнопки установки маркеров
	button.disabled = true;
};
}; // end function pointsControlsDisable

function pointsControlsEnable(){
for(let button of pointsButtons.querySelectorAll('button')){	// кнопки установки маркеров
	const gpxtype = button.value;	//
	//console.log('[pointsControlsEnable] button',gpxtype,button);
	button.onclick = async (event)=>{createEditableMarker(await getGPXicon(gpxtype));};	// здесь нужно именно await, который ждёт. Т.е., в этой конструкции функция onclick, конечно, завершится мгновенно, но createEditableMarker останется работать, т.е., ждать значка от getGPXicon, и потом всё.
	button.disabled = false;
};
}; // end function pointsControlsEnable


async function getGPXicon(gpxtype){
/* 
*/
//console.log('[getGPXicon] начали ждать icon типа',gpxtype);
const icon = await iconServer.customIcon([gpxtype]);	// ждём иконки
//console.log('[getGPXicon] icon:',icon);
return icon || new L.Icon.Default;
}; // end function getGPXicon


function delShapes(realy,inLayer=null) {
/* Удаляет полилинии в состоянии редактирования, если realy = true
возвращает число таких объектов.
Полилинии находятся в L.LayerGroup currentRoute. Мы не знаем, что такое currentRoute, и это
может быть как dravingLines (L.LayerGroup с нарисованными локально объектами), так и 
ранее загруженный gpx. При этом, как минимум в случае gpx, эта L.LayerGroup сама состоит 
(только) из L.LayerGroup, в которых, в свою очередь, находится искомое.
*/
if(!inLayer) inLayer = currentRoute;
if(!inLayer) return;
//console.log('[delShapes] inLayer:',inLayer);
let edEnShapesCntr=0;
let needUpdateSuperclaster = false;
for(let layer of inLayer.getLayers()){
	if(layer instanceof L.LayerGroup) { 	// это layerGroup
		edEnShapesCntr += delShapes(realy,layer);
		//if(realy && !Object.keys(layer).length) inLayer.removeLayer(layer);	// удалим слой из LayerGroup
		if(realy && !layer.getLayers().length) inLayer.removeLayer(layer);	// удалим слой из LayerGroup
	}
	else {	// это что-то ещё
		if(typeof layer.editEnabled === 'function' && layer.editEnabled()){	// оно редактируется сейчас
			edEnShapesCntr++;
			//console.log('[delShapes] editabled layer',layer);
			if(!realy) continue
			if(layer instanceof L.Path) {
				layer.editor.deleteShapeAt(layer.getLatLngs()[0]);	// Мутный способ убрать слой с экрана, но я не вижу, как иначе.
			}
			else {
				needUpdateSuperclaster = needUpdateSuperclaster || removeFromSuperclaster(inLayer,layer);	// могут быть кластеризованные точки, а так -- достаточно removeLayer
			};
			inLayer.removeLayer(layer);	// удалим слой из LayerGroup
			//console.log('[delShapes] из inLayer ',inLayer._leaflet_id,inLayer,'удалён объект',layer._leaflet_id,layer);
			layer = null;	// это приведёт к быстрому удалению объекта сборщиком мусора? Обычно оно не успевает...
		};
	};
};
//console.log('[delShapes] needUpdateSuperclaster:',needUpdateSuperclaster);
if(needUpdateSuperclaster) updClaster(inLayer);	// обновим один раз за все удаления
return edEnShapesCntr;
};	// end function delShapes


function tooggleEditRoute(e,flavor=null) {
/* Переключает режим редактирования
Обычно обработчик клика по линии
flavor == true - включить редактирование
flavor == false - выключить редактирование
flavor == null - переключить редактирование

*/
//console.log('tooggleEditRoute start by anymore',e);
// Щёлкнуть могли либо по нарисованному локально объекту (в том числе -- и по восстановленному из куки)
// либо по загруженному gpx
if(editorEnabled===false) {
	//console.log('[tooggleEditRoute] Редактирование запрещено');
	return;
}
let target;
if(e.target) target = e.target;	// вызвали как обработчик события. В этом языке this почему-то currentTarget. currentTarget - это то, где зарегистрирован обработчик, когда как событие могло произойти во вложенном объекте и всплывать через этот. Когда как target - это объект, где произошло событие.
else target = e;	// вызвали просто как функцию
// Это нужно делать до переноса target в другой слой, иначе у Leaflet.Editable съезжает крыша.
switch(flavor){
case true:
	target.enableEdit();
	break;
case false:
	target.disableEdit();
	break;
default:
	target.toggleEdit();	// оно Leaflet.Editable. Собственно, это и есть переключение состояния.
};
let layerName = '';
//console.log('[tooggleEditRoute] target',target);
//console.log('[tooggleEditRoute] target.feature:',JSON.stringify(target.feature));
//console.log('[tooggleEditRoute] savedLayers:',savedLayers);
//console.log('[tooggleEditRoute] currentRoute:',currentRoute._leaflet_id,currentRoute);
//console.log('[tooggleEditRoute] dravingLines:',dravingLines._leaflet_id,dravingLines);
if(dravingLines && dravingLines.hasLayerRecursive(target)){	// Щёлкнули по одному из нарисованных объектов. hasLayerRecursive потому что omnivore импортирует gpx как L.LayerGroup с двумя слоями: точки и всё остальное
	//console.log('[tooggleEditRoute] Щёлкнули на нарисованном объекте',target._leaflet_id,target,'в dravingLines',dravingLines._leaflet_id,dravingLines);
	if(currentRoute && (currentRoute !== dravingLines)){
		//console.log('[tooggleEditRoute] currentRoute есть, добавляем dravingLines в currentRoute')
		//if(!currentRoute.hasLayerRecursive(dravingLines)) currentRoute.addLayer(dravingLines);	// if не обязательно - addLayer проверяет. Но не рекурсивно!
		//currentRoute.addLayer(dravingLines);	// if не обязательно - addLayer проверяет. Но не рекурсивно!
		//console.log('[tooggleEditRoute] currentRoute есть, переносим объект, по которому щёлкнули, в currentRoute');
		currentRoute.addLayer(target);	// if не обязательно - addLayer проверяет. Но не рекурсивно!
		dravingLines.removeLayer(target);
	}
	else {
		//console.log('[tooggleEditRoute] currentRoute нет, или currentRoute===dravingLines, объектом currentRoute становится объект dravingLines')
		currentRoute = dravingLines;
		layerName = new Date().toJSON(); 	// 
	};
}
else {
	for (layerName in savedLayers) {	// нет способа определить, в какой layerGroup находится layer, но у нас все показываемые слои хранятся в массиве savedLayers
		if(!(savedLayers[layerName] instanceof L.LayerGroup) || !savedLayers[layerName].hasLayerRecursive(target)) continue;
		//console.log('[tooggleEditRoute] Щёлкнули на загруженном объекте',target._leaflet_id,target,'в',savedLayers[layerName]._leaflet_id,layerName,savedLayers[layerName]);
		//if(currentRoute && (currentRoute !== savedLayers[layerName])){
		if(currentRoute && (currentRoute._leaflet_id != savedLayers[layerName]._leaflet_id)){
			//console.log('[tooggleEditRoute] currentRoute есть, добавляем savedLayers[',layerName,'] в currentRoute')
			//if(!currentRoute.hasLayerRecursive(savedLayers[layerName])) currentRoute.addLayer(savedLayers[layerName]);
			//currentRoute.addLayer(savedLayers[layerName]);
			//console.log('[tooggleEditRoute] currentRoute есть, и это не тот же слой, в котором объект, по токорому щёлкнули. Копируем объект, по которому щёлкнули, в currentRoute')
			currentRoute.addLayer(target);
		}
		else {
			//console.log('[tooggleEditRoute] currentRoute нет, или currentRoute===savedLayers[',layerName,'], объектом currentRoute становится объект savedLayers[',layerName,']')
			currentRoute = savedLayers[layerName];
		};
		routeSaveName.value = layerName; 	// запишем в поле ввода имени имя загруженного файла
		break;
	};
};

//console.log('[tooggleEditRoute] currentRoute:',currentRoute._leaflet_id,currentRoute,'dravingLines:',dravingLines._leaflet_id,dravingLines)
if(target.editEnabled()) { 	//  если включено редактирование
	//console.log('[tooggleEditRoute] Редактирование включили');
	routeEraseButton.disabled=false; 	// - сделать доступной кнопку Удалить
	if(!routeSaveName.value) routeSaveName.value = layerName;	// имя файла для сохранения
	// здесь устанавливается выключение режима редактирования по изменению и покиданию
	// поля "описание объекта" в редакторе маршрутов
	// Не знаю, хорошая ли это идея, но я со временем забыл, что для сохранения названия и описания объекта
	/*/ нужно завершить редактирование этого объекта.
	editableObjectDescr.onchange = function (){
		tooggleEditRoute(target);
		//console.log("Выключено редактирование объекта",target)
	};*/
	if((!routeSaveDescr.value) && currentRoute.properties && currentRoute.properties.desc) routeSaveDescr.value = currentRoute.properties.desc;
	if(target.feature && target.feature.properties && target.feature.properties.name) editableObjectName.value = target.feature.properties.name;
	if(target.feature && target.feature.properties && target.feature.properties.desc) editableObjectDescr.value = target.feature.properties.desc;
	editableObjectLeafletID.value = currentRoute.getLayerId(target);	// в общем-то, оно просто возвращает target._leaflet_id, но так сложно - зачем-то нужно. Например, чтобы оно было только для LayerGroup, тогда getLayer - это просто return this._layers[id]; 
	if(target instanceof L.Marker){
		//console.log('[tooggleEditRoute] target is instanceof L.Marker',target);
		routeCreateButton.disabled=true; 	// - сделать недоступной кнопку Начать
		pointsControlsEnable();	// включим кнопки точек
		target.setOpacity(0.4);
		target.options.draggable = true;	// сделаем маркер перемещаемым
		const gpxtype = target.feature.properties.type;
		//console.log('[tooggleEditRoute] gpxtype=',gpxtype,pointsButtons.querySelectorAll('button'));
		for(let button of pointsButtons.querySelectorAll('button')){
			if(button.value != gpxtype) {
				button.disabled = true;
			}
			else {
				button.onclick = function (event) {
					tooggleEditRoute(target);
					button.onclick = function (event) {createEditableMarker(target.getIcon());};
				};
			};
		};
	}
	else {
		//pointsControlsDisable();	// отключить кнопки точек
		routeContinueButton.disabled=false; 	// - сделать доступной кнопку Продолжить
	};
	WPTbuttonsReady();	// Включает кнопку следования по маршруту
}
else {
	//console.log('[tooggleEditRoute] Редактирование выключили');
	if(currentRoute==dravingLines)	doSaveMeasuredPaths();	// Сохраним локально, если оно рисовано от руки
	editableObjectDescr.onchange = null;
	if(delShapes(false))  routeEraseButton.disabled=false; 	// если есть редактируемые слои в currentRoute
	else {	// 
		//console.log('[tooggleEditRoute] нет редактируемых слоёв: как бы завершаем редактирование currentRoute с именем',layerName,currentRoute);
		if(!target.feature) target.feature = {};
		if(!target.feature.properties) target.feature.properties = {};
		target.feature.properties.name = editableObjectName.value;
		target.feature.properties.desc = editableObjectDescr.value;
		bindPopUptoEditable(target);
		resetRouteButtons();	// вернём кнопки в исходное состояние
		if(editorEnabled==='maybe') editorEnabled=false;	// панель закрыли во время редактирования, потом редактирование завершили
	};
	if(target instanceof L.Marker){
		//console.log('[tooggleEditRoute] target is instanceof L.Marker');
		target.setOpacity(0.7);
		target.options.draggable = false;	// сделаем маркер не перемещаемым
		const gpxtype = target.feature.properties.type;
		for(let button of pointsButtons.querySelectorAll('button')){	// кнопки установки маркеров
			button.disabled = false;
			if(button.value == gpxtype) {	// кнопка, по которой был создан этот маркер
				button.onclick = function (event) {createEditableMarker(target.getIcon());};	// вернём стандартное действие -- создание маркера
			}
		};
	}
	else pointsControlsEnable();
	//console.log('Завершили редактирование, в currentRoute имеется',delShapes(false),'редактирующихся слоёв.');
	//console.log('[tooggleEditRoute] Завершили редактирование, currentRoute:',currentRoute._leaflet_id,currentRoute,'dravingLines:',dravingLines._leaflet_id,dravingLines)
	//
	if(!delShapes(false)) {
		currentRoute = undefined;	// если нет редактирумых слоёв в currentRoute - нет currentRoute.
		routeSaveName.value = '';	// очистим имя файла, всё равно currentRoute нет, и сохранить отредактированное не получится.
		routeSaveDescr.value = '';
	};
	//
};
}; // end function tooggleEditRoute


function createEditableMarker(Icon){
console.log('[createEditableMarker] Icon:',Icon);
if(!currentRoute) currentRoute = dravingLines; 	
let gpxtype = Icon.options.symbolType;	// добавляется в leaflet-omnivore.js iconServer.customIcon
let layer = map.editTools.startMarker(centerMarkMarker.getLatLng(),{
	icon: Icon,
	opacity: 0.5
}).addTo(currentRoute);	// dravingLines всегда currentRoute, но currentRoute не всегда dravingLines
layer.feature = {type: 'Feature',
	properties: { 	// типа, оно будет JSONLayer
		type: gpxtype,
	},
};

layer.on('click',tooggleEditRoute);
//layer.on('editable:drawing:end',	function(event) {
//	console.log('layer.on [editable:drawing:end] event.layer:',event.layer);
//});
//layer.on('editable:enable',function(event){
//});
//layer.on('editable:disable',function(event){
//})
// прикалывает маркер в указанных координатах. Если не прикалывать -- в мобильных браузерах
// значёк сдвигается вместе со шторкой инструментальной панели и прикалывается там.
// с другой стороны, в старых браузерах он в этот момент не двигается по тапу, т.е., фактически
// приколот, хотя действия не было.
layer.editor.tools.stopDrawing();	
//console.log('[createEditableMarker] layer:',layer);

for(let button of pointsButtons.querySelectorAll('button')){
	if(button.value != gpxtype) {
		button.disabled = true;
	}
	else {
		button.onclick = function (event) {
			//console.log('[button on click] layer:',layer);
			tooggleEditRoute(layer);
			button.onclick = function (event) {createEditableMarker(Icon);};
		};
	}
}
routeControlsDeSelect();	// отключим все кнопки рисования линии
routeEraseButton.disabled=false;	// включим кнопку Стереть
if(!routeSaveName.value) routeSaveName.value = new Date().toJSON(); 	// запишем в поле ввода имени дату, если там ничего не было
}; // end function createEditableMarker


function doSaveMeasuredPaths() {
/* сохранение в cookie отображаемых на карте маршрутов
Сохраняются только маршруты, не находящиеся в состоянии редактирования.
Предполагается, что это для сохранения маршрутов/замеров расстояний на конкретном устройстве
*/
let expires =  new Date();
let toSave = L.geoJSON();
function findEditDisabled(layer){
	//console.log('[doSaveMeasuredPaths][findEditDisabled] layer:',layer,layer instanceof L.LayerGroup,'eachLayer' in layer);
	if(layer instanceof L.LayerGroup){
		layer.eachLayer(findEditDisabled);
	}
	else {
		if(('editEnabled' in layer) && !layer.editEnabled()){	// режим редактирования этого слоя выключен или отсутствует
			//console.log('[doSaveMeasuredPaths][findEditDisabled] layer:',layer,layer.toGeoJSON());
			let gj = layer.toGeoJSON();
			if(!gj.type){
				//console.log('[doSaveMeasuredPaths][findEditDisabled] метод toGeoJSON() не добавляет в создаваемый GeoJSON свойство type = "Feature", если преобразуется объект типа L.Marker',gj);
				gj.type = 'Feature';
			}
			toSave.addData(gj);
		}
	}
}; // end function findEditDisabled

//console.log('[doSaveMeasuredPaths] toSave original:',toSave);
dravingLines.eachLayer(findEditDisabled);
toSave = toSave.toGeoJSON();	// здесь я реально не понял. А оно не geoJSON? Оно не GeoJSON. Оно LayerGroup
toSave.properties = dravingLines.properties;	// на самом деле -- чисто чтобы там было properties, оно нигде не используется
//console.log('[doSaveMeasuredPaths] toSave:',toSave);
// Покажем в панораме
if(DisplayPANOswitch.checked){
	// Если мы хотим отправлять сообщения панораме, то надо сказать - подтключиться? А юзер
	// поймёт? А типа если сначала открыл панель панорамы - значит, точно хочет?
	// Если какая-то панорама есть, то к ней обязательно есть подключение. Поэтому
	// сообщение будет послано.
	//if(panoControl.isOpen){	// панель управления панорамой (была) открыта
		for (const option of PANOslavesList.selectedOptions) {
			//console.log('[doSaveMeasuredPaths] пошлём сообщение к',option.value);
			sendCOMMAND('PANO',  {"clientToName":option.value, "object": toSave});
		};
	//};
};
// Сохраним локально
if(toSave.features.length){
	toSave = toGPX(toSave); 	// сделаем gpx 
	//console.log('[doSaveMeasuredPaths] Save to cookie GaladrielMapMeasuredPaths',toSave);
	toSave = utoa(toSave);	// кодируем в Base64, потому что xml нельза сохранить в куке
}
else toSave = null;	// не нужно сохранять пустой gpx, а главное - не надо его потом показывать
storageHandler.save('RestoreMeasuredPaths',toSave);
}; 	// end function doSaveMeasuredPaths


function doRestoreMeasuredPaths() {
/* Восстанавливает локально сохранённые слои как dravingLines
Global drivedPolyLineOptions
*/
let RestoreMeasuredPaths = storageHandler.restore('RestoreMeasuredPaths'); 	// storageHandler from galadrielmap.js
//console.log('[doRestoreMeasuredPaths] RestoreMeasuredPaths=',RestoreMeasuredPaths);
if(!RestoreMeasuredPaths) return;

try {	// в принципе, там может быть фигня, но главное -- та же кука от старой версии приведёт к облому
	RestoreMeasuredPaths = atou(RestoreMeasuredPaths);	// восстановим из base64
}
catch {
	return;
}
//console.log('[doRestoreMeasuredPaths] Restore from cookie',RestoreMeasuredPaths);

dravingLines.clearLayers();
dravingLines = omnivore.gpx.parse(RestoreMeasuredPaths);	// leaflet-omnivore.js
//console.log('[doRestoreMeasuredPaths] dravingLines',dravingLines);
dravingLines.eachLayerRecursive(function (layer){
	//console.log('[doRestoreMeasuredPaths] layer',layer);
	if(layer.feature && (layer.feature.geometry.type == 'LineString' || layer.feature.geometry.type == 'Line')){
		//layer.options.color = '#FDFF00';
	}
});
dravingLines.addTo(map);
};	// end function doRestoreMeasuredPaths


function bindPopUptoEditable(layer){
// Подпись - Tooltip
let tooltip = layer.getTooltip();
if(tooltip){
	if(layer.feature.properties.name) {
		//console.log('[bindPopUptoEditable] изменение tooltip',tooltip);
		layer.setTooltipContent(layer.feature.properties.name);
	}
	else layer.unbindTooltip();
}
else {
	if(layer.feature.properties.name) {
		layer.unbindTooltip();
		layer.bindTooltip(layer.feature.properties.name,{ 	
			permanent: true,  	// всегда показывать
			direction: 'auto', 
			//direction: 'left', 
			//offset: [-16,-25],
			//offset: [-32,0],
			className: 'wpTooltip', 	// css class
			opacity: 0.75
		});
	};
};

// popUp
let popUpHTML = '';
if(layer.feature.properties.number) popUpHTML = " <span style='font-size:120%;'>"+layer.feature.properties.number+"</span> "+popUpHTML;
if(layer.feature.properties.name) popUpHTML = "<b>"+layer.feature.properties.name+"</b> "+popUpHTML;
if(layer instanceof L.Marker) {
	let lat = Math.round(layer.getLatLng().lat*10000)/10000; 	 	// широта
	let lng = Math.round(layer.getLatLng().lng*10000)/10000; 	 	// долгота
	if(!popUpHTML) popUpHTML = lat+" "+lng;
	popUpHTML = "<span style='font-size:120%'; onClick='doCopyToClipboard(\""+lat+" "+lng+"\");'>" +popUpHTML+ "</span><br>";
};
if(layer.feature.properties.cmt) popUpHTML += "<p>"+layer.feature.properties.cmt+"</p>";
if(layer.feature.properties.desc) popUpHTML += "<p>"+layer.feature.properties.desc.replace(/\n/g, '<br>')+"</p>"; 	// gpx description
if(layer.feature.properties.ele) popUpHTML += "<p>Alt: "+layer.feature.properties.ele+"</p>"; 	// gpx elevation
//popUpHTML += getLinksHTML(feature); 	// приклеим ссылки Пока не реализовано
layer.unbindPopup();	// если, допустим, описание было, а потом не стало
if(popUpHTML) {
	//console.log('[bindPopUptoEditable] binding popup',popUpHTML);
	layer.bindPopup(popUpHTML+'<br>');
};
}; // end function bindPopUptoEditable


function eraseEditable(){
/* Удаляет все редактируемые слои в currentRoute, и возвращает кнопки в начальное состояние
dravingLines - L.layerGroup, слои, в которых, собственно, рисуются маршруты и путевые точки

В отличии от cancelEditing, где редактируемые объекты становятся? не редактируемыми, здесь они удаляются.
*/
let cnt=delShapes(true);	// удалим все редактируемые объекты
//console.log('[eraseEditable] Удалено ',cnt,'редактируемых слоёв.');
resetRouteButtons();	// выставим кнопки в начальное состояние
if(currentRoute==dravingLines)	{
	doSaveMeasuredPaths();	// Сохраним локально, если оно рисовано от руки
	if(!dravingLines.getLayers().length){	// если больше ничего не рисуем, dravingLines пуст
		currentRoute = undefined;	// раз не осталось редактируемых объектов, редактирование завершено.
		routeSaveName.value = '';	// очистим имя файла
		routeSaveDescr.value = '';
	};
};
//console.log('[eraseEditable] currentRoute:',currentRoute._leaflet_id,currentRoute);
//console.log('[eraseEditable] dravingLines:',dravingLines._leaflet_id,dravingLines);
}; // end function eraseEditable()


function startEditing(){
/* Начинаем рисовать новую линию */
// Если currentRoute уже есть - мы, вероятно, пририсовываем что-то к существующему.
// При этом, сужествующее может быть как dravingLines - т.е., рисуемое от руки, так и
// какой-нибудь savedLayers[layerName] в состоянии редактирования, т.е., слой, загруженный из файла.
// Если уже есть currentRoute, рисуемое добавляется к нему.
if(currentRoute && (currentRoute !== dravingLines)) {
	//console.log('[Кнопка Начать] currentRoute есть и currentRoute не является dravingLines - добавим создаваемый слой в currentRoute');
	currentRoute.addLayer(dravingLines);	// addLayer не добавляет, если уже есть
}
else {
	//console.log('[Кнопка Начать] currentRoute нет или currentRoute==dravingLines - сделаем слой dravingLines объектом currentRoute');
	currentRoute = dravingLines;
};
pointsControlsDisable();	// отключить кнопки точек
//console.log('[Кнопка Начать] currentRoute:',currentRoute._leaflet_id,'dravingLines:',dravingLines._leaflet_id);
// Поскольку в этом говёном Javascript объекты передаются по ссылке на их значение,
// map.editTools.startPolyline(null,drivedPolyLineOptions.options) приведёт к тому, что
// объект, обозначенный как drivedPolyLineOptions, будет один на все layer.
// Поэтому для каждого создаваемого layer будем делать новый объект drivedPolyLineOptions
let drivedPolyLineOptionsNEW = JSON.parse(JSON.stringify(drivedPolyLineOptions));	
let layer = map.editTools.startPolyline(null,drivedPolyLineOptionsNEW.options);
layer.options.color = '#FDFF00';
layer.feature = drivedPolyLineOptionsNEW.feature;
layer.on('editable:editing', function (event){event.target.updateMeasurements();});	// обновлять расстояния при редактировании
//layer.on('click', L.DomEvent.stop).on('click', tooggleEditRoute);
layer.on('click',tooggleEditRoute);
layer.addTo(dravingLines);
editableObjectLeafletID.value = dravingLines.getLayerId(layer);	// в общем-то, оно просто возвращает target._leaflet_id, но так сложно - зачем-то нужно. Например, чтобы оно было только для LayerGroup, тогда getLayer - это просто return this._layers[id]; 
//console.log('[Кнопка Начать] editableObjectLeafletID.value=',editableObjectLeafletID.value);
routeEraseButton.disabled=false;
//if(!routeSaveName.value || Date.parse(routeSaveName.value)) routeSaveName.value = new Date().toJSON(); 	// запишем в поле ввода имени дату, если там ничего не было или была дата
if(!routeSaveName.value) routeSaveName.value = new Date().toJSON(); 	// запишем в поле ввода имени дату, если там ничего не было
//console.log('[Кнопка Начать] currentRoute:',currentRoute._leaflet_id,currentRoute);
//console.log('[Кнопка Начать] dravingLines:',dravingLines._leaflet_id,dravingLines);
}; // end function startEditing


function cancelEditing(){
/* Прекратим редактирование слоя ?
*/
dravingLines.eachLayerRecursive(function(layer){tooggleEditRoute(layer,false);})	// переключим все слои в состоянии редактирования в состояние не редактирования
if(currentRoute) currentRoute.eachLayerRecursive(function(layer){tooggleEditRoute(layer,false);})	// currentRoute может быть savedLayers[layerName], который остаётся
currentRoute = undefined;
routeSaveName.value = '';	// очистим имя файла
routeSaveDescr.value = '';
resetRouteButtons();	// вернём кнопки в исходное состояние
}; // end function cancelEditing


function resetRouteButtons(){
/* Устанавливает кнопки и поля редактора маршрутов в начальное состояние, кроме 
полей имени и описания сохраняемого файла routeSaveName.value и routeSaveDescr.value
*/
editableObjectName.value = '';	// уберём название и описание объекта
editableObjectDescr.value = '';
editableObjectLeafletID.value = '';
routeControlsDeSelect();	// сделаем невыбранными кнопки управления рисованием маршрута
routeCreateButton.disabled=false; 	// - сделать доступной кнопку Начать
pointsControlsEnable();	// включим кнопки точек
routeEraseButton.disabled=true;
routeContinueButton.disabled=true;
WPTbuttonsNotReady();	// Выключает кнопку следования по маршруту
}; // end function resetRouteButtons


function saveGPX(byLoadAction=undefined) {
/* Сохраняет на сервере маршрут из объекта currentRoute. currentRoute -- это или нарисованный
локально объект, или отредактированный gpx
*/
if(!currentRoute) { 	// глобальная переменная, присваивается в tooggleEditRoute, типа - по щелчку на маршруте
	routeSaveMessage.innerHTML = 'Error - no route selected.'
	return;
}
//console.log('[saveGPX] currentRoute:',currentRoute);
//console.log('[saveGPX] Сохраняется файл',currentRoute.properties.fileName);
	function collectSuperclasterPoints(layerGroup){
	//console.log('[collectSuperclasterPoints] layerGroup:',layerGroup);
	let pointsFeatureCollection = []; 	// 
	for(const layer of layerGroup.getLayers()){
		if('supercluster' in layer) { 	// это superclaster'изованный слой, с точками, надо полагать, ранее положенными в свойство layer.supercluster
			//console.log('[collectSuperclasterPoints] layer.supercluster.points:',layer.supercluster.points);
			pointsFeatureCollection = pointsFeatureCollection.concat(layer.supercluster.points);
		}
		if(layer instanceof L.LayerGroup) {	// это LayerGroup
			pointsFeatureCollection = pointsFeatureCollection.concat(collectSuperclasterPoints(layer));
		}
	}
	//console.log('[collectSuperclasterPoints] pointsFeatureCollection:',pointsFeatureCollection);
	return pointsFeatureCollection;
	} // end function collectSuperclasterPoints


let fileName = routeSaveName.value.trim(); 	// имя файла для сохранения, поле в интерфейсе

if(!fileName.endsWith('.gpx')) fileName += '.gpx';
if(! fileName) { 	// внезапно имени нет, хотя в index поле заполняется
	fileName = new Date().toJSON()+'.gpx';
	routeSaveName.value = fileName;
}

if(!(currentRoute  instanceof L.LayerGroup)) currentRoute = new L.LayerGroup([currentRoute]); 	// попробуем сменть тип на layerGroup, но это обычно боком выходит, потому что всё же layergroup не layer. Да, впрочем, нормально?

// Теперь делаем JSON, из которого сделаем gpx
// Сначала соберём в pointsFeatureCollection реальные точки из данных superclaster
// поскольку мы хотим toGeoJSON() все имеющиеся точки, а слой может быть superclaster, то будем доставать точки из supercluster'а
let pointsFeatureCollection = collectSuperclasterPoints(currentRoute); 	// 
//console.log('[saveGPX] pointsFeatureCollection:',pointsFeatureCollection);

let route = currentRoute.toGeoJSON(); 	// сделаем объект geoJSON. Очевидно, это новый объект?
//console.log('[saveGPX] route:',route);
if(route.features.length){	// какие-то объекты есть
	if(!('properties' in route)) route.properties = {};
	//route.properties.fileName = fileName;	// имя файла. А нафига?
	if(routeSaveDescr.value.trim()) route.properties.desc = routeSaveDescr.value;	// общий комментарий
	route.properties.time = new Date().toISOString();
	route.properties.xmlns = "http://www.topografix.com/GPX/1/1";
	route.properties['xmlns:gpxx'] = "http://www8.garmin.com/xmlschemas/GpxExtensions/v3";
	route.properties['xmlns:xsi'] = "http://www.w3.org/2001/XMLSchema-instance";
	route.properties['xsi:schemaLocation'] = "http://www.topografix.com/GPX/1/1 http://www.topografix.com/GPX/1/1/gpx.xsd https://www8.garmin.com/xmlschemas/GpxExtensions/v3 https://www8.garmin.com/xmlschemas/GpxExtensions/v3/GpxExtensionsv3.xsd";
	for(let key in currentRoute.properties) {	//
		if(typeof route.properties[key] === 'undefined') route.properties[key] = currentRoute.properties[key];
	};
	//console.log('[saveGPX] currentRoute:',currentRoute);
	//console.log('[saveGPX] route as geoJSON:',route);

	// теперь выкинем точки, которые есть в supercluster, а потом добавим все точки из supercluster
	// потому что при текущем масштабе некоторые точки из supercluster могли отображаться как точки,
	// а не как значки supercluster
	if(pointsFeatureCollection.length) { 	// это был supercluster, поэтому в geoJSON неизвестно, сколько оригинальных точек, а не все. Но у нас с собой было...
		// выкинем все точки, присутствующие в pointsFeatureCollection
		let pointsFeatureCollectionStrings = pointsFeatureCollection.map(function (point){
																			// а вот тут убъём все сохранённые маркеры
																			// из-за того, что JSON.stringify нельзя
																			// заставить что-то сделать с циклической структурой
																			point.properties.marker = undefined;
																			return JSON.stringify(point);
																		});
		route.features = route.features.filter(function(feature){	
			// не сами кластеры, не точки, и точки, не входящие в pointsFeatureCollection
			return (!feature.properties.cluster) && ((feature.geometry.type !== 'Point') || (! pointsFeatureCollectionStrings.includes(JSON.stringify(feature))));
		});
		//console.log('[saveGPX] JSON.stringify(route.features)',JSON.stringify(route.features));
		// нифига не понятно, почему layer.supercluster.points -- это geoJSON? Видимо, потому, что
		// в supercluster исходно загружаются не объекты leaflet, а GeoJSON Feature objects. 
		route.features = route.features.concat(pointsFeatureCollection); 	// теперь положим туда точки, ранее взятые в superclaster'е
	};
	//console.log('[saveGPX] route as geoJSON after:',route);

	route = toGPX(route); 	// сделаем gpx 
	//console.log('[saveGPX] route as gpx:',route);
}
else {	// никаких объектов нет
	route = '';
};

var xhr = new XMLHttpRequest();
xhr.open('POST', 'saveGPX.php', true); 	// Подготовим асинхронный запрос
xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
xhr.send('name=' + encodeURIComponent(fileName) + '&gpx=' + encodeURIComponent(route));
xhr.onreadystatechange = function() { // 
	if (this.readyState != 4) return; 	// запрос ещё не завершился
	if (this.status != 200) return; 	// что-то не то с сервером
	routeSaveMessage.innerHTML = this.responseText;
	// Теперь надо выполнить функцию по окончанию загрузки.
	//console.log('[saveGPX] Сохранён файл',fileName);
	if(byLoadAction) byLoadAction(fileName);
};

}; // end function saveGPX()


function DOsaveGPX(byLoadAction=undefined){
/**/
saveGPX(function (fileName){
	//console.log('[DOsaveGPX] Сохранён файл',fileName);
	// Покажем сохранённый объект на карте естественным путём - т.е., так, как если бы
	// он был открыт по щелчку в списке route
	const routeDisplayedLi = [... routeDisplayed.querySelectorAll('li')].filter(el => el.textContent == fileName)[0];
	if(routeDisplayedLi){	// слой с этим именем уже есть в списке routeDisplayed, т.е., маршрут показывается
		//console.log('[DOsaveGPX] Файл',fileName,'имеется в routeDisplayed');
		// currentRoute в этом случае не меняется. Потому что есть мнение, что должно остаться,
		// чтобы можно было добавлять рисуемое.
		// Но после сохранения объект будет перезагружен следилкой, в результате
		// currentRoute и сохранённый объект станут разными объектами, и добавить рисуемое
		// к сохранённому объекту не получится.
		// Поэтому просто cancelEditing()
		if(currentRoute.hasLayer(dravingLines)){
			// очистим вообще слой рисования, фактически - это удаление рисуемого с карты.
			// Делать dravingLines.remove() не следует: слои добавляются на карту в Leaflet.Editable,
			// и в результате .remove() dravingLines просто просто теряет связь с этими слоями,
			// а на карте они всё равно остаются.
			// Кроме того, dravingLines добавляется на карту вообще только при старте страницы
			// (и при локальном восстановлении, что дублирование.) Поэтому если здесь сделать .remove()
			// и потом нигде не сделать addTo - будет забавно. Слой, созданный Leaflet.Editable будет
			// видим, потому что там есть addTo(map), но dravingLines видим на будет, хотя будет
			// этот слой содержать. В результате .clearLayers() очистит dravingLines, но слой
			// на карте останется.
			//console.log('[DOsaveGPX] dravingLines нет в currentRoute',dravingLines);
			dravingLines.clearLayers();	
		};
	}
	else {	// слоя нет, т.е., мы сохранили новый файл (иначе он был бы в routeDisplayed)
		//console.log('[DOsaveGPX] Файла',fileName,'нет в routeDisplayed');
		// Сперва удалим рисуемое - вместо него будет сохранённое
		dravingLines.clearLayers();	// очистим вообще слой рисования
		// обновим список routeList. Оно асинхронно.
		listPopulate(routeList,routeDirURI,false,true,function(){	// заполним список routeList
			ulDiff(routeDisplayed,routeList);	// удалим из routeList то, что есть в routeDisplayed
			// найдёи в routeList li с именем fileName
			const routeListLi = [... routeList.querySelectorAll('li')].filter(el => el.textContent == fileName)[0];
			// покажем этот li
			//console.log('[DOsaveGPX] Показываем',routeListLi);
			if(routeListLi){	// ну мало ли...
				selectTrack(routeListLi,routeList,routeDisplayed,displayRoute);
			};
		}); // end function
	};
	// В это время ещё выполняется listPopulate
	doSaveMeasuredPaths();	// Очистим локальное хранилище
	cancelEditing();
	if(byLoadAction) byLoadAction(fileName);
}); // end function
}; // end function DOsaveGPX


function toGPX(geoJSON) {
/* Create gpx route or track (createTrk==true) from geoJSON object вместо этого LineString
должна иметь свойство properties.isRoute == true, тогда рисуется маршрут, иначе -- путь (track)
geoJSON must have a needle gpx attributes
bounds - потому что geoJSON.getBounds() не работает
*/
//console.log('[toGPX] geoJSON:',geoJSON);
var gpxtrack = `<?xml version="1.0" encoding="UTF-8" standalone="no" ?>
<gpx creator="GaladrielMap" version="1.1"
`;
for(let key in geoJSON.properties) {	//
	if(!key.startsWith('xml') && !key.startsWith('xsi')) continue;
	gpxtrack += `\t${key}="${geoJSON.properties[key]}"\n`;
};
gpxtrack += '>\n';
gpxtrack += '<metadata>\n';
var date = geoJSON.properties.date;
if(!date) date = new Date().toISOString();
gpxtrack += '	<time>'+ date +'</time>\n';
// Хитрый способ получить границы всех объектов в geoJSON
const geojsongroup = L.geoJSON(geoJSON);
let bounds = geojsongroup.getBounds();
//console.log('[toGPX] bounds:',bounds);
if(Object.entries(bounds).length) gpxtrack += '	<bounds minlat="'+bounds.getSouth().toFixed(4)+'" minlon="'+bounds.getWest().toFixed(4)+'" maxlat="'+bounds.getNorth().toFixed(4)+'" maxlon="'+bounds.getEast().toFixed(4)+'"  />\n';
if(geoJSON.properties) doDescriptions(geoJSON.properties) 	// запишем разные описательные поля
gpxtrack += '</metadata>\n';

for(let i=0; i<geoJSON.features.length;i++) {
	//console.log('[toGPX] geoJSON.features[i]:',geoJSON.features[i]);
	switch(geoJSON.features[i].geometry.type) {
	case 'MultiLineString': 	// это обязательно путь
		gpxtrack += '	<trk>\n'; 	// рисуем трек
		doDescriptions(geoJSON.features[i].properties) 	// запишем разные описательные поля
		for(let k = 0; k < geoJSON.features[i].geometry.coordinates.length; k++) {
			gpxtrack += '		<trkseg>\n'; 	// рисуем трек
			for (let j = 0; j < geoJSON.features[i].geometry.coordinates[k].length; j++) {
				gpxtrack += '			<trkpt '; 	// рисуем трек
				gpxtrack += 'lat="' + geoJSON.features[i].geometry.coordinates[k][j][1] + '" lon="' + geoJSON.features[i].geometry.coordinates[k][j][0] + '">';
				gpxtrack += '</trkpt>\n'; 	// рисуем трек
			}
			gpxtrack += '		</trkseg>\n'; 	// рисуем трек
		}
		gpxtrack += '	</trk>\n'; 	// рисуем трек
		break;
	case 'LineString': 	// это может быть как маршрут, так и путь
		if(geoJSON.features[i].properties.isRoute) gpxtrack += '	<rte>\n'; 	// рисуем маршрут
		else gpxtrack += '	<trk>\n'; 	// рисуем трек
		doDescriptions(geoJSON.features[i].properties) 	// запишем разные описательные поля
		if(!geoJSON.features[i].properties.isRoute) gpxtrack += '		<trkseg>\n'; 	// рисуем трек
		for (let j = 0; j < geoJSON.features[i].geometry.coordinates.length; j++) {
			if(!geoJSON.features[i].properties.isRoute) gpxtrack += '			<trkpt '; 	// рисуем трек
			else gpxtrack += '		<rtept '; 	// рисуем маршрут
			gpxtrack += 'lat="' + geoJSON.features[i].geometry.coordinates[j][1] + '" lon="' + geoJSON.features[i].geometry.coordinates[j][0] + '">';
			if(!geoJSON.features[i].properties.isRoute) gpxtrack += '</trkpt>\n'; 	// рисуем трек
			else gpxtrack += '</rtept>\n'; 	// рисуем маршрут
		}
		if(!geoJSON.features[i].properties.isRoute) gpxtrack += '		</trkseg>\n'; 	// рисуем трек
		if(!geoJSON.features[i].properties.isRoute) gpxtrack += '	</trk>\n'; 	// рисуем трек
		else gpxtrack += '	</rte>\n'; 	// рисуем маршрут
		break;
	case 'Point':
		gpxtrack += '	<wpt '; 	// рисуем точку
		gpxtrack += 'lat="' + geoJSON.features[i].geometry.coordinates[1] + '" lon="' + geoJSON.features[i].geometry.coordinates[0] + '">\n';
		doDescriptions(geoJSON.features[i].properties) 	// запишем разные описательные поля
		gpxtrack += '	</wpt>\n'; 	// 
	}
}
gpxtrack += '</gpx>';
//console.log('[toGPX] resulting gpxtrack',gpxtrack);
return gpxtrack;

	function doDescriptions(properties) {
		//console.log('[toGPX][doDescriptions] properties:',properties,properties.desc);
		if(properties.name) gpxtrack += '		<name>' + properties.name.encodeHTML() + '</name>\n';
		if(properties.cmt) gpxtrack += '		<cmt>' + properties.cmt.encodeHTML() + '</cmt>\n';
		if(properties.desc) gpxtrack += '		<desc>' + properties.desc.encodeHTML() + '</desc>\n';
		if(properties.src) gpxtrack += '		<src>' + properties.src + '</src>\n';
		if(properties.link) {
			for ( let ii = 0; ii < properties.link.length; ii++) { 	// ссылок может быть много
				//console.log(properties.link[ii]);
				gpxtrack += properties.link[ii];
			}
			//console.log(gpxtrack);
		}
		if(properties.number) gpxtrack += '		<number>' + properties.number + '</number>\n';
		if(properties.type) gpxtrack += '		<type>' + properties.type + '</type>\n';
		if(properties.extensions) { 	// там просто уж оформленная строка
			for ( let ii = 0; ii < properties.extensions.length; ii++) {
				gpxtrack += properties.extensions[ii];
			};
		};
	}; // end function doDescriptions
}; // end function toGPX




// Кластеризация точек
function createSuperclaster(geoJSONpoints){
/* geoJSONpoints - array of GeoJSON points, as it described in Superclaster doc */
const index = new Supercluster({
	"log": false, 	// вывод лога в консоль
	"radius": superclusterRadius,
	"extent": 256,
	"maxZoom": 14,
	"minPoints": 3	// при умолчальных 2 невозможно разделить дублирующиеся точки
}).load(geoJSONpoints); 
return index;
} // end function createSuperclaster


function removeFromSuperclaster(superclasterLayer,point){
let ret = false;
if(!superclasterLayer.supercluster) return ret;
if(!(point instanceof L.Marker)) return ret;
let pointStr = point.toGeoJSON();
// Убъём сохранённый маркер, потому что там хранится тот же GeoJSON, и в результате
// JSON.stringify обламывается, что структура циклическая.
// Пляски вокруг параметров JSON.stringify не помогли: ничего не работает, или я ниасилил доку.
// Потом supercluster создаст новый маркер, ничего страшного.
if(pointStr.properties.marker) pointStr.properties.marker = undefined;	
//console.log('[removeFromSuperclaster] point:',pointStr,JSON.stringify(pointStr));
pointStr = JSON.stringify(pointStr);
for(let i = 0; i < superclasterLayer.supercluster.points.length; i++){
	// а вот здесь не будем просто убивать маркер, ибо убъются все
	// переприсвоим, потом убъём, потом присвоим обратно.
	// В конце-концов, это просто пляски со ссылками. Или убить?
	let savedMarker;
	if(superclasterLayer.supercluster.points[i].properties.marker) {
		savedMarker = superclasterLayer.supercluster.points[i].properties.marker;
		superclasterLayer.supercluster.points[i].properties.marker = undefined;
	}
	let superStr = JSON.stringify(superclasterLayer.supercluster.points[i]); 
	if(savedMarker) superclasterLayer.supercluster.points[i].properties.marker = savedMarker;
	if(pointStr===superStr){
		superclasterLayer.supercluster.points.splice(i,1);
		superclasterLayer.supercluster = createSuperclaster(superclasterLayer.supercluster.points); 	// создание нового и загрузка в суперкластер точек 		
		ret = true;
		//console.log('[removeFromSuperclaster] точка найлена ret=',ret);
		break;
	}
}
return ret;
} // end function removeFromSuperclaster


function updateClasters() {
/* Обновляет показываемые кластеры точек
В savedLayers вообще все показываемые слои: карты, сетки, файлы. Но не окружности дистанции.
Чтобы не разбираться - будем выбирать оттуда заведомо только файлы.
*/
//console.log('galadrielmap.js: updateClasters start by anymore');
for (var i = 0; i < routeDisplayed.children.length; i++) { 	// для каждого потомка списка routeDisplayed
	const trackName = routeDisplayed.children[i].innerHTML; 	// наименование показывающегося слоя, возможн, с точками
	updClaster(savedLayers[trackName]);
}
for (var i = 0; i < trackDisplayed.children.length; i++) { 	// для каждого потомка списка trackDisplayed
	const trackName = trackDisplayed.children[i].innerHTML; 	// наименование показывающегося слоя, возможн, с точками
	updClaster(savedLayers[trackName]);
}
} // end function updateClasters


async function updClaster(e) {
// обновляет кластер
if(!e) return;
let layer;
if(e.target) layer = e.target; 	// e - event
else layer = e;	// e - layer
//console.log('[updClaster] layer:',layer._leaflet_id,layer,layer instanceof L.LayerGroup);
realUpdClaster(layer);
layer.eachLayer(realUpdClaster);


function realUpdClaster(layer) {
	if(!layer.supercluster) return;
	//console.log('[realUpdClaster] Обновляется кластер',layer._leaflet_id,layer);
	const bounds = map.getBounds();
	const mapBox = {
		bbox: [bounds.getWest(), bounds.getSouth(), bounds.getEast(), bounds.getNorth()],
		zoom: map.getZoom()
	}
	// Оно может быть вызвано во время изменения масштаба, и тогда map.getZoom() вернёт дробный масштаб
	// от этого у supercluster съезжает крыша, и оно падает с весёлыми глюками.
	// При этом бесполезно снова спрашивать здесь map.getZoom() -- возвращаемое значение не меняется
	// хотя изменение масштаба давно закончилось.
	// Поэтому просто не будем обновлять кластер, если масштаб дробный.
	// Авотхрен: значение map.getZoom() не меняется (и остаётся дробным) до следующего изменения масштаба.
	// Опять автохрен: оказывается, дробные значения масштаба -- нормально. Видимо, оно не не меняется, а правда такое -- дробное.
	// Получается, авторы supercluster этого не знали, и заложились на целое?
	// Таким образом, нужно изменить масштаб карты с дробного к ближайшему целому, и вызывать supercluster
	// А можно забить, и вызывать supercluster с округлённым до целого масштабом -- это не концептуально,
	// но на практике -- без разницы.
	/*
	if(!Number.isInteger(mapBox.zoom)){
		console.log('[realUpdClaster] mapBox.zoom=',mapBox.zoom);
		//return;
	}
	*/
	// Точки и кластеры показываются на слое layer только в пределах bbox.
	//все другие точки тихо лежат в кеше
	mapBox.zoom = Math.round(mapBox.zoom);
	//console.log('[realUpdClaster] mapBox.bbox:',mapBox.bbox,'mapBox.zoom=',mapBox.zoom);
	//console.log('[realUpdClaster] layer.supercluster.getClusters:',layer.supercluster.getClusters(mapBox.bbox, mapBox.zoom));
	let newGeoJSONpoints=[], pointsExistsIDs=[];
	for(const point of layer.supercluster.getClusters(mapBox.bbox, mapBox.zoom)){
		// возвращает новые точки: у которых нет сохранённого маркера, или этот маркер не показывается сейчас
		if(!point.properties.marker) newGeoJSONpoints.push(point);
		else {
			if(!(point.properties.marker._leaflet_id in layer._layers)) newGeoJSONpoints.push(point);
			else pointsExistsIDs.push(point.properties.marker._leaflet_id);	// это id тех, кто есть, и кто должно быть в слое
		}
	};
	//console.log('[realUpdClaster] newGeoJSONpoints:',newGeoJSONpoints,'pointsExistsIDs:',pointsExistsIDs);
	for(let id in layer._layers){	// удаляем точки, которых быть не должно
		id = parseInt(id);
		//console.log('[realUpdClaster] id=',id,pointsExistsIDs.includes(id));
		if(!pointsExistsIDs.includes(id)) {
			// Собственно, вся эта лабуда с новыми и старыми точками выше сделана исключительно
			// ради того, чтобы определить точки, уходящие из поля зрения, но не в результате зуммирования
			// и удаления из их GeoJSON сохранённого маркера -- в целях сбережения памяти.
			// Т.е., память никогда не кончится при любом количестве точек, как оно и задумано в supercluster.
			// За исключением случая, когда сначала зум (тогда маркер не удаляется, даже если точка уходит
			// из поля зрения), а потом сдвиг, и точка уходит. Тогда маркер остаётся, но это не страшно?
			//console.log('[realUpdClaster] lastSuperClusterUpdatePosition:',lastSuperClusterUpdatePosition,map.getZoom());
			if(lastSuperClusterUpdatePosition[1]==map.getZoom()) {
				//console.log('[realUpdClaster] Удаляется сохранённый маркер из',layer._layers[id]);
				// сохранённый маркер есть, раз эта точка показывалась, но эта точка может быть кластером
				// Чёта фигня какая-то. У кластера есть сохранённый маркер? А кто?
				// Ха! Оказывается, сохранять маркер -- это не я придумал, такая фича есть в supercluster
				if(layer._layers[id].feature.properties.marker) layer._layers[id].feature.properties.marker = undefined;
			}
			layer.removeLayer(id);
		}
	}
	//layer.clearLayers();
	layer.addData(newGeoJSONpoints); 	// добавляем новые точки
} // end function realUpdClaster
} // end function updClaster





function nextColor(color,step) {
/* step - by color chanel 
step не может быть константой, если color - число, если мы хотим получать чистые цвета

Тривиальный код даёт тот же результат?:
function random(number) {
  return Math.floor(Math.random() * (number+1));
}
const rndCol = 'rgb(' + random(255) + ',' + random(255) + ',' + random(255) + ')';
*/
if(!step) step = 0x80;
const colorStr = ('000000' + color.toString(16)).slice(-6);
var r = parseInt(colorStr.slice(0,2),16);
var g = parseInt(colorStr.slice(2,4),16);
var b = parseInt(colorStr.slice(4),16);
b-=step;
if(b<0) {
	b=0xFF+b;
	g-=step;
	if(g<0) {
		g=0xFF+g;
		r-=step;
		if(r<0) {
			r=0xFF+r;
			g=0xFF-g;
			b=0xFF-b;
		}
	}
}
return parseInt(('00'+r.toString(16)).slice(-2)+('00'+g.toString(16)).slice(-2)+('00'+b.toString(16)).slice(-2),16);
} // end function nextColor


// Показ координат центра и переход по введённым
function centerMarkPosition() {
/* global goToPositionField */
centerMark.invoke('setLatLng',map.getCenter()); // установим координаты всех маркеров
if(goToPositionManualFlag === false) { 	// если поле не юзают руками
	const lat = Math.round(centerMarkMarker.getLatLng().lat*10000)/10000; 	 	// широта с четыремя знаками после запятой - 10см
	const lng = Math.round(((centerMarkMarker.getLatLng().lng%360+540)%360-180)*10000)/10000; 	 	// долгота
	goToPositionField.value = lat + ' ' + lng;
} 	// а когда руками, т.е., фокус в поле -- координаты перестают изменяться. Карта же может двигаться за курсором
}; // end function centerMarkPosition


function centerMarkUpdate(){
//let markSize = Math.round(distCirclesUpdate(centerMarkCircles))*2; 	// нарисуем круги и заодно получим размер крестика
distCirclesUpdate(centerMarkCircles);
let markSize = Math.round((window.innerWidth+window.innerHeight)/10);
//console.log("[centerMarkOn] markSize=",markSize);
let centerMark_markerImg = `<svg width="${markSize}" height="${markSize}" viewBox="0 0 100% 100%" xmlns="http://www.w3.org/2000/svg">
	<line x1="50%" y1="0" x2="50%" y2="100%" stroke="rgb(253,0,219)" />
	<line x1="0" y1="50%" x2="100%" y2="50%" stroke="rgb(253,0,219)" />
	<line x1="0" y1="50%" x2="25%" y2="50%" stroke="rgba(253,0,219,0.3)" stroke-width="3px" />
	<line x1="75%" y1="50%" x2="100%" y2="50%" stroke="rgba(253,0,219,0.3)" stroke-width="3px" />
	<line x1="50%" y1="0%" x2="50%" y2="25%" stroke="rgba(253,0,219,0.3)" stroke-width="3px" />
	<line x1="50%" y1="75%" x2="50%" y2="100%" stroke="rgba(253,0,219,0.3)" stroke-width="3px" />
</svg>`;
centerMarkIcon.options.html = centerMark_markerImg;
centerMarkIcon.options.iconAnchor = [markSize/2, markSize/2];
//console.log(centerMarkIcon);
} // end function centerMarkUpdate


function centerMarkOn() {
/**/
centerMarkPosition();
centerMarkUpdate();	// обязательно после centerMarkPosition, ибо там географическое положение используется для вычисления положения в пикселях
centerMark.addTo(map);
map.on('move', centerMarkPosition);
goToPositionField.addEventListener('focus', function(e){goToPositionManualFlag=true;}); 	// при получении фокуса - прекратить обновление
goToPositionField.addEventListener('blur', function(e){ 	// когда теряет фокус. В результате, даже если карта движется, с полем можно работать
			goToPositionButton.value = goToPositionField.value; 	// разбор введённого как координат происходит потом, когда координаты действительно нужны - для скорости
			goToPositionManualFlag=false;
		}
	); 	// при потере - возобновить
}; // end function centerMarkOn


function centerMarkOff() {
centerMark.remove();
map.off('move', centerMarkPosition);
}; // end function centerMarkOff




function flyByString(stringPos){
/* Получает строку предположительно с координатами, и перемещает туда центр карты */
//console.log('goToPositionButton',goToPositionButton.value,'goToPositionField',goToPositionField.value);
if(!stringPos) stringPos = map.getCenter().lat+' '+map.getCenter().lng; 	// map -- глобально определённая карта
stringPos = stringPos.trim();
//console.log('[flyByString] stringPos=',stringPos);
	// Это написано с использованием аж трёх ИИ, сам я так и ниасилил регулярные выражения
	// Но за то время, что я убил, добиваясь от ИИ правильного результата, я написал бы сам.
	// Ещё и понимал бы, что здесь написано.
	// Напиши регулярное выражение для javascript regex, извлекающее из строки первое число, следующее за указанной подстрокой через любое количество любых нецифровых символов. Число может быть отрицательными.
	function extractNumberAfterKeyword(str, keyword) {
		// Используем экранирование специальных символов регулярного выражения внутри keywor'd'
		const escapedKeyword = keyword.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
		// Регулярное выражение теперь включает аргумент keyword
		const regex = new RegExp(`${escapedKeyword}[^\\d.-]*(-?\\d+(?:\\.\\d+)?)`, 'i');
		// Выполняем поиск соответствия регулярному выражению
		const match = str.match(regex);
		//console.log('[extractNumberAfterKeyword] match:',match);
		if (match && match.length > 1) { // Если найдено совпадение и оно имеет значение
		    return parseFloat(match[1]); // Возвращаем найденное число
		};
		return null; // Если ничего не нашли — возвращаем null
	};

let error,position,x,y,z;
try {
    // Разберём строку как координаты https://github.com/otto-dev/coordinate-parser
    // Писал это дело законченный мудак, и там, кроме кучи бессмысленных объектных наворотов,
    // совершенно шизоидная логика. Исправить её невозможно - проще написать снова. Поэтому
    // проще то, что в этом парсере не предусмотрено, отдельно привести к виду, парсером
    // понимаемому.
	position = new Coordinates(stringPos);
	position = {lon:position.longitude,lat:position.latitude};
	//console.log('[flyByString] Координаты разобраны успешно, position:',position);
} 
catch (error) { 	// coordinate-parser обломался, строка - не координаты.
	//console.log('[flyByString] Координаты йок, stringPos=',stringPos,error);
	// это возможно, строка с lon lat
	position = {lon:extractNumberAfterKeyword(stringPos, 'lon'),lat:extractNumberAfterKeyword(stringPos, 'lat')};
	//console.log('[flyByString] 1 lon=',lon,'lat=',lat);
	if(position.lon == null){
		position.lon = extractNumberAfterKeyword(stringPos, 'lng');
		if(position.lon == null){
			position.lon = extractNumberAfterKeyword(stringPos, 'longitude');
		};
	};
	if(position.lat == null){
		position.lat = extractNumberAfterKeyword(stringPos, 'lat');
		if(position.lat == null){
			position.lat = extractNumberAfterKeyword(stringPos, 'latitude');
		};
	};
	if((position.lon == null) || (position.lat == null)){	// координат так и не нашли
		//console.log("А не номер тайла ли там?");
		x = extractNumberAfterKeyword(stringPos, 'x');
		y = extractNumberAfterKeyword(stringPos, 'y');
		z = extractNumberAfterKeyword(stringPos, 'z');
		//console.log('[flyByString] номер тайла z,x,y:',z,x,y);
		if((x == null) || (y == null) || (z == null)){	// координат так и не нашли
			//console.log("Может быть, там номер тайла просто в виде трёх чисел zxy?");
			const regex = /[-+]?\d*\.?\d+/g;	// все числа
			let zxy = stringPos.match(regex);	// вот какой кретин придумал возвращать null при неудаче поиска? Почему не пустой массив?
			if(zxy) {
				zxy = zxy.map(Number);
				//console.log(zxy);
				if((zxy.length == 3) && isValidTile(zxy[0],zxy[1],zxy[2])){
					position = tileNum2degree(zxy[0],zxy[1],zxy[2]);
					z=zxy[0];
					//console.log('[flyByString] Да, это 3 числа. position=',position,'z=',z);
				}
				else position = null;
			}
			else position = null;
		}
		else{
			position = tileNum2degree(z,x,y);
			position.lon = position.lng
			//console.log('[flyByString] Да, там номер тайла. position=',position,'z=',z);
		};
	};
};
//console.log('[flyByString] 3 position=',position,'z=',z);
if(position){	// координаты нашли
	if(z==null)	map.setView(position); 	// подвинем карту в указанное место
	else map.setView(position,z); 	// подвинем карту в указанное место
	let xhr = new XMLHttpRequest();	// Запросим сервис геокодирования на предмет - что у нас в этом месте
	const url = encodeURI('https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat='+position.lat+'&lon='+(position.lon || position.lng));
	xhr.open('GET', url, true); 	// Подготовим асинхронный запрос
	xhr.setRequestHeader('Referer',url); 	// nominatim.org требует?
	xhr.send();
	xhr.onreadystatechange = function() { // 
		if (this.readyState != 4) return; 	// запрос ещё не завершился
		if (this.status != 200) return; 	// что-то не то с сервером
		//console.log('[flyByString] this.response=',this.response);
		const nominatim = JSON.parse(this.response);
		//console.log('[flyByString] nominatim:',nominatim);
		updGeocodeList(nominatim);
	};
}
else{
	//console.log("это просто строка, возможно, с адресом, сделаем запрос к геосервису");
	position = undefined;
	let xhr = new XMLHttpRequest();
	//const url = encodeURI('https://nominatim.openstreetmap.org/search/'+stringPos+'?format=jsonv2'); 	// прямое геокодирование
	const url = encodeURI('https://nominatim.openstreetmap.org/search?q='+stringPos+'&format=jsonv2'); 	// прямое геокодирование
	xhr.open('GET', url, true); 	// Подготовим асинхронный запрос
	xhr.setRequestHeader('Referer',url); 	// nominatim.org требует? Теперь, .... требует.
	xhr.send();
	xhr.onreadystatechange = function() { // 
		if (this.readyState != 4) return; 	// запрос ещё не завершился
		if (this.status != 200) return; 	// что-то не то с сервером
		const nominatim = JSON.parse(this.response);
		console.log(nominatim);
		updGeocodeList(nominatim);
	};
};
}; // end function flyByString


function updGeocodeList(nominatim){
if(nominatim.error) return;
if(!Array.isArray(nominatim)) nominatim = [nominatim];
geocodedList.innerHTML = ""; 	// очистим список
for(const geoObj of nominatim){
	//console.log(geoObj);
	let optNode = document.createElement('li');
	optNode.innerText = geoObj.display_name || geoObj.error;
	optNode.onclick = function(e) {
		//console.log(e); 
		for(let liNode of geocodedList.children){
			liNode.style.backgroundColor='inherit';
		}
		e.target.style.backgroundColor='#d5d5d5';
		map.setView(L.latLng([geoObj.lat,geoObj.lon]))
	};
	geocodedList.append(optNode);
};
}; // end function updGeocodeList


// Копирование в буфер обмена
function doCopyToClipboard(text) {
/* создаёт control с полем, откуда можно скопировать text в буфер обмена, 
при этом пытается это сделать сама.
Через некоторое время поле исчезает

global copyToClipboard
*/
if(typeof(text) === 'string') {
	if(!copyToClipboard._map) { 	// кривой метод
		//alert('not on map!');
		copyToClipboard.addTo(map);
	}
	copyToClipboardField.value = text;
	copyToClipboardField.focus();
	copyToClipboardField.select(); // 
	let successful = document.execCommand('copy');
	if(successful) {
		copyToClipboardMessage.innerText = copyToClipboardMessageOkTXT;
	}
	else {
		copyToClipboardMessage.style.color='red';
		copyToClipboardMessage.innerText = copyToClipboardMessageBadTXT;
	}
	//console.log('PosFreshBefore',PosFreshBefore);
	setTimeout(doCopyToClipboard,PosFreshBefore); 	// удалим поле через PosFreshBefore, определённый в index
}
else {
	if(typeof copyToClipboard !== 'undefined') copyToClipboard.remove();
}
} // end function doCopyToClipboard


function doCurrentTrackName(liID){
let liObj = document.getElementById(liID);
//console.log('doCurrentTrackName',liID,liObj);
liObj.classList.add("currentTrackName");
liObj.title='Current track';
currentTrackName = liID;
currentTrackShowedFlag = false; 	// флаг, что у нас новый текущий трек. Обрабатывается в currentTrackUpdate index.php
} // end function doCurrentTrackName


function doNotCurrentTrackName(liID){
let liObj = document.getElementById(liID);
liObj.classList.remove("currentTrackName");
liObj.title='';
currentTrackName = '';
} // end function doNotCurrentTrackName


function loggingWait() {
/* запускает/останавливает слежение за наличием пишущегося трека по кнопке в интерфейсе */
if(currTrackSwitch.checked){	// Текущий трек всегда показывается
	startCurrentWaitTrackUpdateProcess();	
	console.log('[loggingWait]  Logging check started by user');
}
else {
	if(currentWaitTrackUpdateProcess){
		clearInterval(currentWaitTrackUpdateProcess);
		currentWaitTrackUpdateProcess = null;
	}	
	console.log('[loggingWait]  Logging check stopped by user');
}
} // end function loggingWait


function loggingRun(run='') {
/* запускает/останавливает запись трека по кнопке в интерфейсе 
или просто вызовом
*/
if(typeof loggingIndicator === 'undefined') return	// loggingRun может быть запущен откуда-нибудь
//console.log('[loggingRun] run=',run);
let logging = 'logging.php';
switch(run){
case 'start':
	if(!loggingIndicator.innerText || loggingIndicator.style.color != 'green'){	// запись не ведётся, или была включена, но не включилась
		logging += '?startLogging=1';
	};
	break;
case 'stop':
	if(loggingIndicator.innerText){	// запись была включена
		logging += '?stopLogging=1';
		if(currentTrackName) doNotCurrentTrackName(currentTrackName);
		console.log('[loggingRun]  Update track stopped because no logging now');
		if(currentWaitTrackUpdateProcess){
			clearInterval(currentWaitTrackUpdateProcess);	
			console.log('[loggingRun] Не должно быть currentWaitTrackUpdateProcess, но он был.');
		}
		if(currTrackSwitch.checked) startCurrentWaitTrackUpdateProcess();	// Текущий трек всегда показывается
	};
	break;
default:
	if(typeof loggingSwitch !== 'undefined'){	// для пользователя со всеми правами
		if(loggingSwitch.checked) {	// Запись пути
			logging += '?startLogging=1';
		}
		else {
			logging += '?stopLogging=1';
			if(currentTrackName) doNotCurrentTrackName(currentTrackName);
			console.log('[loggingRun] Logging stop by user');
			console.log('[loggingRun]  Update track stopped because no logging now');
			if(currentWaitTrackUpdateProcess){
				clearInterval(currentWaitTrackUpdateProcess);	
				//console.log('[loggingRun] Не должно быть currentWaitTrackUpdateProcess, но он был. Убили, запускаем.');
			}
			if(currTrackSwitch.checked) startCurrentWaitTrackUpdateProcess();	// Текущий трек всегда показывается
		};
	};
};
//console.log('[loggingRun] logging=',logging);
loggingCheck(logging);
} // end function loggingRun


function loggingCheck(logging='logging.php') {
/* включает и выключает запись трека, а также проверяет, ведётся ли запись 
путём запроса logging.
Запрос должен вернуть JSON массив из двух значенией: ведётся ли запись bool и имя пишущегося файла
*/
//console.log('[loggingCheck] started');
let xhr = new XMLHttpRequest();
xhr.open('GET', encodeURI(logging), true); 	// Подготовим асинхронный запрос
xhr.send();
xhr.onreadystatechange = function() { // 
	if (this.readyState != 4) return; 	// запрос ещё не завершился
	if (this.status != 200) return; 	// что-то не то с сервером
	//console.log('[loggingCheck] this.response=',this.response);
	let status = JSON.parse(this.response);
	if(status[0]) { 	// состояние gpxlogger после выполнения logging.php, 1 или 0 - запущен успешно
		// Новый текущий трек
		const newTrackName = status[1].substring(0, status[1].lastIndexOf('.')) || status[1]; 	// имя нового текущего (пишущийся сейчас) трека -- имя файла без расширения		
		//console.log(status,'[loggingCheck] Новый текущий трек newTrackName=',newTrackName);
		let newTrackLI = document.getElementById(newTrackName); 	// его всегда нет? Нет, он вполне может быть, если, например, запись запустил не этот клиент
		//console.log(newTrackLI);
		if(!newTrackLI) {
			//console.log(tracks.querySelector('li[title="Current Track"]'));
			//tracks.querySelector('li[title="Current Track"]').classList.remove("currentTrackName");
			if(currentTrackName) doNotCurrentTrackName(currentTrackName);
			newTrackLI = trackLiTemplate.cloneNode(true);
			newTrackLI.id = newTrackName;
			newTrackLI.innerText = newTrackName;
			newTrackLI.hidden=false;
			newTrackLI.classList.remove("template");
			//console.log(newTrackName,newTrackLI);
			trackList.append(newTrackLI);
			doCurrentTrackName(newTrackName);	// обязательно после append, ибо вне дерева элементы не ищутся. JavaScript -- коллекция нелепиц.
		}
		else { 	// иначе он и так текущий. Авотхрен.
			if(newTrackName !== currentTrackName) doCurrentTrackName(newTrackName);	// 
		};
		if(typeof loggingIndicator !== 'undefined'){	// если запись пути осуществляется gpxlogger'ом 
			loggingIndicator.style.color='green';
			loggingIndicator.innerText='\u2B24';
			if(typeof loggingSwitch !== 'undefined'){	// для пользователя со всеми правами
				if(!newTrackName) {	// не было возвращено имени, хотя запись трека работае. Возможно, кто-то запустил запись в какой-то не наш каталог.
					loggingSwitch.disabled = true;	// отключим переключатель, и не будем нигде включать - пусть жмут Shift-Reload
					return; 
				};
			};
		};
		// запустим слежение за логом, если ещё не
		// Но слежение за логом должно быть запущено, только если трек показывается
		// но startCurrentTrackUpdateProcess периодически запускает currentTrackUpdate
		// который при первом запуске... Но процесс запускается, а он не нужен.
		// Поэтому запускаем процесс только если указано "Текущий трек всегда показывается."
		if(currTrackSwitch.checked) {
			startCurrentTrackUpdateProcess();	// в index.php
		}
	}
	else {
		if(typeof loggingIndicator !== 'undefined'){
			if((typeof loggingSwitch !== 'undefined') && loggingSwitch.checked){
				loggingIndicator.style.color='red';
				loggingIndicator.innerText='\u2B24';
			}
			else {
				loggingIndicator.innerText='';
			};
		};
	}
return;
}; // end xhr.onreadystatechange
}; // end function loggingCheck


async function coverage(){
//console.log(cowerSwitch);
//console.log(mapDisplayed.firstElementChild);
if(cowerSwitch.checked){ 	// переключатель в интерфейсе загрузчика
	if(mapDisplayed.firstElementChild){ 	// список показываемых карт не пуст
		if(savedLayers[mapDisplayed.firstElementChild.id].getLayers().length>1){	// в карте больше одного слоя
			cowerSwitch.checked = false;	// для составной (многослойной) карты непонятно, покрытие чего показывать
		}
		else {
			displayMap('COVER',{'r':mapDisplayed.firstChild.id});
			coverMap.innerHTML = mapDisplayed.firstChild.id;
		};
	}
	else cowerSwitch.checked = false;
}
else {
	//console.log(savedLayers);
	if(savedLayers['COVER'] != null) {
		savedLayers['COVER'].remove();
		delete savedLayers['COVER'];	// удалим карту покрытия из кеша
	};
	coverMap.innerHTML = '';
}
return;
} // end function coverage




// MOB
function MOBalarm(latlng=null,MOBmarkerInfo={}) {
/* Добавляет новую точку MOB в mobMarker (который всегда есть), или обновляет имеющуюся, 
и делает mobMarker видимым на карте, если ещё не.
Точка будет в текущих координатах, или указанных.
MOBmarkerInfo - это MOB в формате gpsdPROXY

Концептуально делать это всё путем преобразования mobMarker в mobMarkerJSON, изменением json,
а потом преобразованием json обратно в mobMarker с помощью createMOBpointMarker(mobMarkerJSON).
Тогда вся сопутствующая пурга типа отметок времени и изменений интерфейса выполнится сама.
Но исторически сложилось, что здесь делается не концептуально, а естественным образом, изменением
непосредственно mobMarker.
*/
// Global: map, cursor, currentMOBmarker, centerMark
//console.log('[MOBalarm] MOBmarkerInfo:',JSON.stringify(MOBmarkerInfo));
if(!latlng){
	if(map.hasLayer(cursor)) latlng = cursor.getLatLng(); 	// координаты известны и показываются, хотя, возможно, устаревшие
	else {
		// если даже нет координат -- дадим возможность ставить маркер в центре карты
		centerMarkOn(); 	// включить крестик в середине
		latlng = centerMarkMarker.getLatLng();
		locationMOBdisplay.innerHTML = latTXT+' '+Math.round(latlng.lat*10000)/10000+'<br>'+longTXT+' '+Math.round(latlng.lng*10000)/10000;	
	};
};
const selfmmsi = vesselSelf ? vesselSelf.split(':').pop() : '';
if(!MOBmarkerInfo.mmsi) MOBmarkerInfo.mmsi = selfmmsi;
//const sart = MOBmarkerInfo.mmsi.startsWith('972') || MOBmarkerInfo.mmsi.startsWith('974');	// это точка AIS SART
const sart = MOBmarkerInfo.mmsi != selfmmsi;	// это точка MOB, поставленная не нами
let thisMarkerIs;
// для всяких SART будем обновлять точку, когда как для руками поставленных в этом экземпляре - добавлять
// Точки от AIS SART - единственные в mobMarker с данныи mmsi, когда как точек со своим mmsi
// может быть много. Также может быть много точек, полученных от netAIS MOB.
if(sart){	
	for(const layer of mobMarker.getLayers()){
		if(layer instanceof L.Marker && (MOBmarkerInfo.mmsi == layer.feature.properties.mmsi)){	// пришло обновление именно этого маркера
			thisMarkerIs = layer;
			break;
		};
	};
};
// маркер для этой точки
if(thisMarkerIs) {
	thisMarkerIs.setLatLng(latlng);
	thisMarkerIs.feature.properties.safety_related_text = MOBmarkerInfo.safety_related_text ? MOBmarkerInfo.safety_related_text : ''
	mobMarker.feature.properties.timestamp = MOBmarkerInfo.timestamp ? MOBmarkerInfo.timestamp : Math.round(Date.now()/1000);
}
else {
	thisMarkerIs = L.marker(latlng, {
		"icon": mobIcon, 
		"draggable": !sart,
	});
	thisMarkerIs.feature = {
		"type": "Feature",
		"properties": {
			"mmsi": MOBmarkerInfo.mmsi,
			"safety_related_text": MOBmarkerInfo.safety_related_text ? MOBmarkerInfo.safety_related_text : '',
		},
	};
	thisMarkerIs.on('click', mobMarkerClickFunction);
	if(sart) setMOBpopup(thisMarkerIs);
	else thisMarkerIs.on('dragend', mobMarkerDragendFunction);
	
	mobMarker.addLayer(thisMarkerIs);
	mobMarker.feature.properties.timestamp = Math.round(Date.now()/1000);
};
// Если currentMOBmarker уже есть - не следует его переназначать на маркер SART, потому что
// он может быть вручную указанным маркером, который реально идут спасать
if(!currentMOBmarker || !map.hasLayer(mobMarker) || !sart){
	makeMOBmarkerCurrent(thisMarkerIs);
};
if(!map.hasLayer(mobMarker)) mobMarker.addTo(map); 	// выставим маркер

if(!sart && (loggingIndicator !== undefined && !loggingSwitch.checked)) {	// включим запись трека, но только если это свой MOB
	loggingSwitch.checked = true;
	loggingRun(); 	// хотя в loggingSwitch стоит onChange="loggingRun();" изменение loggingSwitch.checked = true; не приводит к срабатыванию обработчика
}

sendMOBtoServer(); 	// отдадим данные MOB для передачи на сервер
return true;
} // end function MOBalarm


function MOBtabHighLight(on=false){
/* Посветка кнопки MOB */
//const highligting = '<img src="img/redbulletdot.svg" style="position:absolute;left:0;top:1em;width:100%;">';
//const img = MOBtab.querySelector('img');
//console.log('[MOBtabHighLight]',MOBtab);
//let str = MOBtab.innerHTML;
//str = str.replace(highligting,'');
//str = str.replace('</a>','');
//if(on) MOBtab.innerHTML = str+highligting+'</a>';	// Это ломает leaflet-sidebar-v2, о чём там есть комментарий.
//else MOBtab.innerHTML = str+'</a>';
if(on) MOBtab.style.backgroundColor = 'red';
else MOBtab.style.backgroundColor = 'inherit';
}; // end function MOBtabHighLight


function setMOBpopup(layer){
let dataStamp = '';
if(mobMarker.feature.properties.timestamp){
	const d = new Date(mobMarker.feature.properties.timestamp*1000);
	dataStamp = d.getHours()+':'+(d.getMinutes()<10?'0'+d.getMinutes():d.getMinutes());
	//dataStamp = d.getHours()+':'+d.getMinutes();
}
let PopupContent = `
<div>
	<div style='width:100%;'>
		${layer.feature.properties.mmsi||''} 
		<img  width="24px" style="margin:0.1rem;vertical-align:middle;" src="${mob_markerImg}">
	</div>
	<div style='width:100%;background-color:lavender;'>
		<span style='font-size:110%;'>${layer.feature.properties.safety_related_text||''}</span><br>
	</div>
	<span>${dataStamp}</span>
</div>
`;
layer.bindPopup(PopupContent,{});	// таким образом, Popup лепится только к маркерам MOB, пришедшим извне.
}; // end function setMOBpopup


function createMOBpointMarker(mobMarkerJSON){
/*
Создадим mobMarker - мультислой маркеров из переданного GeoJSON,
а потом каждому маркеру в мультислое присвоим иконку, которая в GeoJSON не сохраняется.
Возможно, нарисуем линию от текущего маркера к месторасположению, но саму линию в мультислой добавим обязательно.
Покажем мультислой на карте.

Global: mobMarker, он создаётся заново.
*/
mobMarker = L.geoJSON(mobMarkerJSON);
if(!mobMarker.feature){
	mobMarker.feature = {
		properties: {}
	};
};
// Почему-то в mobMarker timestamp - это mobMarker.feature.properties.timestamp,
// а в mobMarkerJSON = mobMarkerJSON.properties.timestamp
// Вроде бы, это от GeoJSON
if(mobMarkerJSON.properties && mobMarkerJSON.properties.timestamp){	// штатно не, но могут быть куки от предыдущих версий
	mobMarker.feature.properties.timestamp = mobMarkerJSON.properties.timestamp;
};
const selfmmsi = vesselSelf ? vesselSelf.split(':').pop() : '';
let layerID;
mobMarker.eachLayer(function (layer) {
	if(layer instanceof L.Marker)	{
		//const sart = layer.feature.properties.mmsi && (layer.feature.properties.mmsi.startsWith('972') || layer.feature.properties.mmsi.startsWith('974'));	// это точка AIS SART
		const sart = layer.feature.properties.mmsi && layer.feature.properties.mmsi != selfmmsi;	// это точка MOB, поставленная не нами
		layerID = mobMarker.getLayerId(layer);
		layer.setIcon(mobIcon);
		if(!layer.feature.properties) layer.feature.properties = {};
		layer.on('click', mobMarkerClickFunction); 	// текущим будет маркер, по которому кликнули
		if(!layer.getLatLng() || (layer.getLatLng().lat == undefined) || (layer.getLatLng().lng == undefined)){	// У этой точки нет координат. Например, это AIS MOB.
			if(map.hasLayer(cursor)) layer.setLatLng(cursor.getLatLng()); 	// координаты известны и показываются, хотя, возможно, устаревшие - назначим точке свои координаты
			else layer.setLatLng(map.getCenter());
		};
		//console.log('Маркеры в полученной информации MOB ',layer);
		// если вообще не был назначен currentMOBmarker, или мультислой mobMarker не показывается
		//if(!currentMOBmarker || !map.hasLayer(mobMarker)){	// Это вообще не надо, потому что мы создаём весь мультислой заново, и никакого текущего маркера вне создаваемых здесь быть не может.
			if(layer.feature.properties.current) { 	// текущим станет указанный в переданных данных
				//console.log('[createMOBpointMarker] Делаем текущим маркер с координатами:',layer.getLatLng());
				makeMOBmarkerCurrent(layer);
			}
		//};
		if(sart) setMOBpopup(layer);
	}
	// А назачем удалять линию? Затем, что она уже неактуальна. Если надо - тут же будет нарисована новая.
	// Ещё потому, что иначе она будет просто линия, а не toMOBline, и с ней никто ничего не сможет сделать.
	else mobMarker.removeLayer(layer); 	// Считаем, что это toMOBline, и там больше ничего такого нет
});
toMOBline.setLatLngs([]); 	// очистим линию к текущему маркеру MOB
mobMarker.addLayer(toMOBline);	// добавим в мультислой линию, её там нет.
// Возможно, не нужно принудительно устанавливать текущий маркер?
// Последний маркер станет текущим, если текущего вообще не назначали.
// При таком условии если есть MOB SART, то, когда этот маркер снова будет показан после прекращения
// режима MOB, линия к нему не будет проведена. Фича? Ага, но только в том случае, если 
// в MOBclose не currentMOBmarker = null;
if(layerID && !currentMOBmarker){
	//console.log('[createMOBpointMarker] Назначаем текущим последний маркер с координатами:',mobMarker.getLayer(layerID).getLatLng());
	makeMOBmarkerCurrent(mobMarker.getLayer(layerID));	// назначим текущим последний маркер
};
//
//console.log('[createMOBpointMarker] mobMarker:',mobMarker);
/*/ Перерисуем линию, если есть текущий маркер. А надо?
if(currentMOBmarker){
	let latlng1 = cursor.getLatLng();	// cursor-то есть всегда, но какие у него координаты, когда его нет?
	let latlng2 = currentMOBmarker.getLatLng();
	toMOBline.setLatLngs([latlng1,latlng2]); 	// обновим линию к текущему маркеру MOB
};
/*/
mobMarker.addTo(map); 	// покажем мультислой с маркерами MOB

mobMarker.eachLayer(function (layer) { 	// сделаем каждый маркер draggable, кроме чужих маркеров
	if(layer instanceof L.Marker && is_currentMOBmarkerSelf(layer)){	
		layer.dragging.enable(); 	// переключение возможно, только если маркер на карте
		layer.on('dragend', mobMarkerDragendFunction); 	// отправим на сервер новые сведения, когда перемещение маркера закончилось. Если просто указать функцию -- в sendMOBtoServer передаётся event. Если в одну строку -- всё равно передаётся event. Что за???
	}
});
}; // end function createMOBpointMarker


function MOBclose() {
mobMarker.remove(); 	// убрать мультислой-маркер с карты
//currentMOBmarker = null;
mobMarker.clearLayers(); 	// очистить мультислой от маркеров
toMOBline.setLatLngs([]);	// сделаем линию никакой
mobMarker.addLayer(toMOBline); 	// вернём туда линию
//console.log("[MOBclose] mobMarker:",mobMarker);
storageHandler.del('mobMarker');
azimuthMOBdisplay.innerHTML = '&nbsp;';
distanceMOBdisplay.innerHTML = '&nbsp;';
directionMOBdisplay.innerHTML = '&nbsp;';
locationMOBdisplay.innerHTML = '&nbsp;';
delMOBmarkerButton.disabled = true;
//centerMarkOff(); 	// выключить крестик в середине -- не надо, ибо при закрытии панели оно уже вызывается
MOBtabHighLight(false);	// убрать подсветку кнопки
sidebar.close();	// закрыть панель
} // end function MOBclose


function realMOBclose(){
mobMarker.feature.properties.timestamp = Math.round(Date.now()/1000);
sendMOBtoServer(false); 	// передадим на сервер, что режим MOB прекращён
MOBclose();
}; // end function realMOBclose


function delMOBmarker(){
/* Удаляет текущий маркер MOB
mobMarker это LayerGroup 
Вызывается юзером
*/
//console.log('[delMOBmarker] currentMOBmarker before del ',currentMOBmarker);
if(!is_currentMOBmarkerSelf() || !checkSelfMOBmarkerScount()) return;	// нельзя убрать чужой или последний свой маркер
mobMarker.removeLayer(currentMOBmarker);
currentMOBmarker = null;
// Сделаем текущим первый попавшийся свой маркер, или никакого?
let layerID;
for(const layer of mobMarker.getLayers()){
	if(!(layer instanceof L.Marker)) continue;
	if(is_currentMOBmarkerSelf(layer)) {
		makeMOBmarkerCurrent(layer);
		break;
	}
	layerID = mobMarker.getLayerId(layer);
};
//if(!currentMOBmarker) makeMOBmarkerCurrent(mobMarker.getLayer(layerID));	// сделаем текущим последний маркер
sendMOBtoServer(); 	// отдадим новые данные MOB для передачи на сервер
} // end function delMOBmarker


function makeMOBmarkerCurrent(LMarker){
/* Global currentMOBmarker */
if(!(LMarker instanceof L.Marker)) return;
// Забавно, что в javascript нижеследующие операторы могут быть выполнены в любой последовательности
// с одинаковым результатом. Но всё же расположим их в разумной.
currentMOBmarker = LMarker;
clearCurrentStatus(); 	// удалим признак current у всех маркеров
currentMOBmarker.feature.properties.current = true;
if(is_currentMOBmarkerSelf() && checkSelfMOBmarkerScount()) {
	//console.log('Это наш маркер');
	delMOBmarkerButton.disabled = false; // включим/выключим кнопку удаления маркера MOB
}
else {
	//console.log('Это чужой или единственный маркер',checkSelfMOBmarkerScount());
	delMOBmarkerButton.disabled = true;	// выключим кнопку удаления маркера
};

if(!mobMarker.hasLayer(currentMOBmarker)) mobMarker.addLayer(currentMOBmarker);	// можно добавить сколько угодно одних и тех же слоёв
mobMarker.feature.properties.timestamp = Math.round(Date.now()/1000);
}; // end function makeMOBmarkerCurrent


function clearCurrentStatus() {
/* удаляет признак "текущий маркер" у всех маркеров мультислоя mobMarker */
mobMarker.eachLayer(function (layer) { 	// удалим признак current у какого-то маркера
	if((layer instanceof L.Marker) && (layer.feature.properties.current == true))	{
		layer.feature.properties.current = false;
	}
});
} // end function clearCurrentStatus


function is_currentMOBmarkerSelf(marker=null){
/* Возвращает true, если текущая или указанная точка MOB поставлена нашим судном. С любого клиента. 
В случае GaladrielMap SignalK ed. есть что-то типа своего mmsi, и идентифицируется по нему.
В случае просто GaladrielMap mmsi есть только у gpsdPROXY, поэтому считаем, что если mmsi нет - то это мы.
*/
if(!marker) marker = currentMOBmarker;
let ret;
const selfmmsi = vesselSelf ? vesselSelf.split(':').pop() : '';
//console.log('[is_currentMOBmarkerSelf] selfmmsi=',selfmmsi,'marker:',marker);
if(marker.feature){	// L.Marker
	if(marker.feature.properties.mmsi && (marker.feature.properties.mmsi !== selfmmsi)){
		ret = false;
	}
	else ret = true;
}
else if(marker.properties){	// mobMarkerJSON
	if(marker.properties.mmsi && (marker.properties.mmsi !== selfmmsi)){
		ret = false;
	}
	else ret = true;
};
//console.log('[is_currentMOBmarkerSelf]  selfmmsi=',selfmmsi,'return=',ret);
return ret;
}; // end function is_currentMOBmarkerSelf


function checkSelfMOBmarkerScount(){
/* Считает, имеется ли больше одного своего маркеров MOB */
let n=0;
for(const layer of mobMarker.getLayers()){
	if(!(layer instanceof L.Marker)) continue;
	if(is_currentMOBmarkerSelf(layer)) n++;
	if(n > 1) return true;
};
return false;
}; // end function checkSelfMOBmarkerScount


function mobMarkerDragendFunction(event){
//console.log("MOB dragged end, send to server new coordinates",mobMarker);
mobMarker.feature.properties.timestamp = Math.round(Date.now()/1000);
if(event.target.feature.properties.current == true){
	let latlng1 = cursor.getLatLng();	// cursor-то есть всегда, но какие у него координаты, когда его нет?
	let latlng2 = event.target.getLatLng();
	toMOBline.setLatLngs([latlng1,latlng2]); 	// обновим линию к текущему маркеру MOB
};
sendMOBtoServer(); 
}; // end function mobMarkerDragendFunction


function mobMarkerClickFunction(event){
//console.log("MOB click",event.target);
if(event.target.feature.properties.current == true) return;
makeMOBmarkerCurrent(event.target)
//console.log("MOB click, send to server new coordinates",mobMarker);
sendMOBtoServer(); 
}; // end function mobMarkerClickFunction


function sendMOBtoServer(status=true){
/* Кладёт данные MOB в массив, который передаётся на сервер 
mobMarker -- это Leaflet LayerGroup, т.е. там исчерпывающая информация
*/
//console.log("sendMOBtoServer status=",status,mobMarker);
let mobMarkerJSON = null;
mobMarkerJSON = mobMarker.toGeoJSON(); 	//
if(!mobMarkerJSON.properties){	// вообще-то, toGeoJSON должна сохранять левые поля, но она делает это как-то иногда...
	mobMarkerJSON.properties = {"timestamp": Math.round(new Date().getTime()/1000)};
};
if(mobMarker.feature.properties.timestamp) mobMarkerJSON.properties.timestamp = mobMarker.feature.properties.timestamp;
if(status){
	//console.log('[sendMOBtoServer] Посадим куку MOB');
	storageHandler.save('mobMarker',mobMarkerJSON);
}
else {
	storageHandler.del('mobMarker');
};
//console.log('Sending to server mobMarkerJSON',JSON.stringify(mobMarkerJSON));
upData.MOB = GeoJSONtoMOB(mobMarkerJSON,status);	// приведение к формату gpsdPROXY
//console.log('[sendMOBtoServer] Sending to server upData.MOB:',upData.MOB);
//console.log('[sendMOBtoServer] upData=','?UPDATE={"updates":['+JSON.stringify(upData.MOB)+']};');
//console.log('[sendMOBtoServer] spatialWebSocket.readyState:',spatialWebSocket.readyState);

// отдадим данные MOB для передачи на сервер через глобальный сокет для передачи координат.
// Он есть, иначе -- нет координат и нет проблем.
// Его может не быть, а MOB можно поставить и без координат.
if(spatialWebSocket && spatialWebSocket.readyState == 1) {	// при этом в index.php в spatialWebSocket.onopen эта функция вызывается сразу по открытию соединения с gpsdPROXY, так что если есть gpsdPROXY - данные станут общими.
	spatialWebSocket.send('?UPDATE={"updates":['+JSON.stringify(upData.MOB)+']};'); 	
};
}; // end function sendMOBtoServer


function MOBtoGeoJSON(MOBdata){
/* Переделывает объект MOB из формата gpsdPROXY в mobMarkerJSON: Leaflet GeoJSON для GaladrielMap */
//console.log('[MOBtoGeoJSON] MOBdata:',MOBdata);
let mobMarkerJSON = {
	"type":"FeatureCollection",
	"features":[],
	"properties": {
		"timestamp": MOBdata.timestamp
	}
};
for(const point of MOBdata.points){
	if(point.coordinates.length === 0 || point.coordinates[0]==null || point.coordinates[1]==null) continue;	// Точки без координат просто не показываем. А что делать?
	const feature = {	
		"type":"Feature",
		"properties":{
			"current": Boolean(point.current),
			"mmsi": String(point.mmsi),
			"safety_related_text": String(point.safety_related_text)
		},
		"geometry":{
			"type":"Point",
			"coordinates": point.coordinates
		}
	};
	mobMarkerJSON.features.push(feature);
};
//console.log('[MOBtoGeoJSON] mobMarkerJSON:',mobMarkerJSON);
return mobMarkerJSON;
}; // end function MOBtoGeoJSON


function GeoJSONtoMOB(mobMarkerJSON,status){
/* Переделывает Leaflet GeoJSON мультислоя mobMarker в объект MOB формата gpsdPROXY */
//console.log('[GeoJSONtoMOB] mobMarkerJSON:',mobMarkerJSON);
let MOB={
	"class": 'MOB',
	"status": status,
	"points": [],
	"timestamp": status ? mobMarkerJSON.properties.timestamp : Math.round(new Date().getTime()/1000),
	"source": '972'+vesselSelf.substring(3)
};
for(let feature of mobMarkerJSON.features){
	switch(feature.geometry.type){
	case "Point":
		MOB.points.push({
			'coordinates':feature.geometry.coordinates,
			'current':feature.properties.current,
			'mmsi':feature.properties.mmsi,
			'safety_related_text':feature.properties.safety_related_text
		});
		break;
	case "LineString":
		break;
	};
};
return MOB;
}; // end function GeoJSONtoMOB




// Круги дистанции
function distCirclesUpdate(distCircles){
/* Устанавливает диаметр и подписи кругов дистанции 
в зависимости от координат и масштаба.
*/
if(!distCircles[0] || !distCircles[0].getLatLng()) return;
let distCirclesRadius;
const zoom = Math.round(map.getZoom());	// масштаб может быть дробным во время собственно масштабирования
const metresPerPixel = (40075016.686 * Math.abs(Math.cos(distCircles[0].getLatLng().lat*(Math.PI/180))))/Math.pow(2, map.getZoom()+8); 	// in WGS84
//console.log("[distCirclesUpdate] zoom",zoom,"метров в пикселе:",metresPerPixel);
switch(zoom){
case 0:
case 1:
case 2:
case 3:
case 4:
	distCirclesRadius = [200000,500000,1000000,2000000];
	break
case 5:
case 6:
	distCirclesRadius = [50000,100000,150000,300000];
	break
case 7:
case 8:
	distCirclesRadius = [10000,20000,50000,100000];
	break
case 9:
case 10:
	distCirclesRadius = [5000,10000,20000,30000];
	break
case 11:
case 12:
	distCirclesRadius = [1000,2000,5000,10000];
	break
case 13:
case 14:
	distCirclesRadius = [200,500,1000,2000];
	break
case 15:
	distCirclesRadius = [100,200,300,500];
	break
case 16:
default:
	distCirclesRadius = [50,100,200,300];
}
let label;
for (let i=0; i<4; i++)	{
	distCircles[i].setRadius(distCirclesRadius[i]);
	distCircles[i].unbindTooltip();
	if(distCirclesRadius[0]>=1000) label = (distCirclesRadius[i]/1000).toString()+' '+dashboardKiloMeterMesTXT
	else label = distCirclesRadius[i].toString();
	distCircles[i].bindTooltip(label,{permanent:true,direction:'center',className:'distCirclesRadiusTooltip',offset:[0,-distCirclesRadius[i]/metresPerPixel]});	
}
//return distCirclesRadius[2]/metresPerPixel;	
} // end function distCirclesUpdate


function distCirclesToggler() {
/* включает/выключает показ окружностей дистанции по переключателю в интерфейсе */
if(distCirclesSwitch.checked) {
	distCircles.forEach(circle => circle.addTo(positionCursor));
	storageHandler.save('distCirclesSwitch',true);
}
else {
	distCircles.forEach(circle => circle.removeFrom(positionCursor));
	storageHandler.save('distCirclesSwitch',false);
};
}; // end function distCirclesToggler



// Ветер
function windSwitchToggler() {
/* включает/выключает показ символа ветра по переключателю в интерфейсе */
if(windSwitch.checked) {
	windSymbolMarker.setLatLng(cursor.getLatLng());	// хотя его может и не быть. Но если не установить координаты, может происходить ошибка в leaflet, если символ показывается до очередного обновления координат, когда они устанавливаюся для всех слоёв, включая символ ветра.
	if(!positionCursor.hasLayer(windSymbolMarker)) windSymbolMarker.addTo(positionCursor);
	storageHandler.save('WindSwitch',true);
}
else {
	windSymbolMarker.removeFrom(positionCursor);
	storageHandler.save('WindSwitch',false);
};
}; // end function windSwitchToggler


function windSymbolUpdate(data){
/* Ветер определяется естественно - относительно носа судна 
Global: track,heading
*/
//console.log('[windSymbolUpdate] useTrueWind=',useTrueWind);
if(useTrueWind){	// options.js указано использовать истинный ветер
	//console.log('[windSymbolUpdate] wspeedt=',data.wspeedt,'wanglet=',data.wanglet,'track=',track);
	if(data.wspeedt != null && data.wanglet != null && track != null){
		let dir = data.wanglet + track - 90;	// картинка-то у нас горизонтальна
		if(dir >= 360) dir -= 360;
		realWindSymbolUpdate(dir,data.wspeedt);
	}
	else realWindSymbolUpdate();
}
else {	// указано использовать вымпельный ветер
	//console.log('[windSymbolUpdate] heading=',data.heading,'wind dir=',data.wangler+data.heading,'wspeedr=',data.wspeedr);
	/*/ Это работает только в новых браузерах, но думаю, что слишком новых
	if(data.wspeedr && data.wangler && (heading ?? track)){	//
		let dir = data.wangler + (heading ?? track) - 90;	// картинка-то у нас горизонтальна
		if(dir >= 360) dir -= 360;
		realWindSymbolUpdate(dir,data.wspeedr);
	}
	else realWindSymbolUpdate();
	/*/
	// А это - работает во всех.
	let hdng = heading || track || mheading;
	if(data.wspeedr != null && data.wangler != null && hdng != null){	//
		let dir = data.wangler + hdng - 90;	// картинка-то у нас горизонтальна
		if(dir >= 360) dir -= 360;
		realWindSymbolUpdate(dir,data.wspeedr);
	}
	else realWindSymbolUpdate();
};
}; // end function windSymbolUpdate


function realWindSymbolUpdate(direction=0,speed=0){
/**/
// Символ
let windSVG = document.getElementById('wSVGimage');
if(!windSVG) return;	// картинка там как-то не сразу появляется
let windMark = windSVG.getElementById('wMark');

while (windMark.firstChild) {	// удалим все символы из значка
	windMark.removeChild(windMark.firstChild);
};
let pos = 0, w25=0;
if(speed){	// стрелка
	windMark.appendChild(document.createElementNS('http://www.w3.org/2000/svg', 'use'));
	windMark.lastChild.setAttribute('x',String(pos));
	windMark.lastChild.setAttribute('y','0');
	windMark.lastChild.setAttributeNS('http://www.w3.org/1999/xlink','xlink:href','#bLine');
	pos += 70;
};
if(Math.floor(speed/25)){	// перо 25 м/сек
	speed -= 25;
	w25=1;
};
for(let i=Math.floor(speed/5); i>0; i--){	// перья 5 м/сек
	speed -= 5;
	//console.log('pos',pos);
	windMark.appendChild(document.createElementNS('http://www.w3.org/2000/svg', 'use'));
	windMark.lastChild.setAttribute('x',String(pos));
	windMark.lastChild.setAttribute('y',0);
	windMark.lastChild.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href','#w5');
	pos += 10;
};
if(w25){
	windMark.appendChild(document.createElementNS('http://www.w3.org/2000/svg', 'use'));
	windMark.lastChild.setAttribute('x',String(pos));
	windMark.lastChild.setAttribute('y',0);
	windMark.lastChild.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href','#w25');
};
if(Math.floor((speed*10)/25)) {	// половинное перо
	windMark.appendChild(document.createElementNS('http://www.w3.org/2000/svg', 'use'));
	if(pos==70) windMark.lastChild.setAttribute('x',String(70-20));
	else windMark.lastChild.setAttribute('x',String(70-2.5));
	windMark.lastChild.setAttribute('y',0);
	windMark.lastChild.setAttributeNS('http://www.w3.org/1999/xlink', 'xlink:href','#w2.5');
};
// напрвление
windSymbolMarker.setRotationAngle(direction);
} // end function realWindSymbolUpdate




function restoreDisplayedRoutes(){
// Восстановим показываемые маршруты и заодно согласуем списки routeList и routeDisplayed
if(!SelectedRoutesSwitch.checked) return;
let showRoutes = storageHandler.restore('showRoutes'); 	// storageHandler from galadrielmap.js
if(!showRoutes) return;
showRoutes.forEach(	function(layerName){ 	// 
	// однако же, возможно повторение id, раз он имя файла? Получение всех li, содержащих строку.
	// [... выражение] просто делает из результатов выражения массив
	// но результат querySelectorAll и так массив (в отличии от)? Авотхрен, оно тоже NodeList, хоть и статический, и методы массива там ёк
	//const routeListLi = [... document.querySelectorAll('#routeList > li')].filter(el => el.textContent.includes(layerName));
	//const routeListLi = [... routeList.querySelectorAll('li')].filter(el => el.textContent.includes(layerName));
	const routeListLi = [... routeList.querySelectorAll('li')].filter(el => el.textContent == layerName);
	if(routeListLi.length) { 	// объект с этим именем есть в списке routeList
		//const routeDisplayedLi = [... routeDisplayed.querySelectorAll('li')].filter(el => el.textContent.includes(layerName));
		const routeDisplayedLi = [... routeDisplayed.querySelectorAll('li')].filter(el => el.textContent == layerName);
		if(routeDisplayedLi.length) { 	// этот объект уже есть в списке routeDisplayed, т.е., маршрут показывается
			routeListLi[0].remove();	// удалим его из routeList
			routeListLi[0] = null;
		}
		else {	// иначе выберем объект, т.е., покажем маршрут
			selectTrack(routeListLi[0],routeList,routeDisplayed,displayRoute)
		};
	};	// 	если нет -- и ладно
});	// end forEach function(layerName)
}; // end function restoreDisplayedRoutes


function hideControlsControl(hideControlPosition){
/* Создаёт невидимый псевдо-control, по тапу по которому все указанные в controlsList control делаются невидимыми на экране
На самом деле, тут просто style.display = 'none', потому что штатный control совсем неудобен
для этой цели, и штатные функции leaflet неудобны в силу общего кретинизма javascript, поэтому всё примитивно.
*/
let doit=true;
switch(hideControlPosition){
case 'topleft':
	hideControl.style.top = '0';
	hideControl.style.bottom = null;
	hideControl.style.right = null;
	hideControl.style.left = '0';
	break;
case 'topmiddle':
	hideControl.style.top = '0';
	hideControl.style.bottom = null;
	hideControl.style.right = null;
	hideControl.style.left = 'calc(50vw - var(--control-size)/2)';
	break;
case 'topright':
	hideControl.style.top = '0';
	hideControl.style.bottom = null;
	hideControl.style.right = '0';
	hideControl.style.left = null;
	break;
case 'rightmiddle':
	hideControl.style.top = 'calc(50vh - var(--control-size)/2)';
	hideControl.style.bottom = null;
	hideControl.style.right = '0';
	hideControl.style.left = null;
	break;
case 'bottomright':
	hideControl.style.top = null;
	hideControl.style.bottom = '0';
	hideControl.style.right = '0';
	hideControl.style.left = null;
	break;
case 'bottommiddle':
	hideControl.style.top = null;
	hideControl.style.bottom = '0';
	hideControl.style.right = null;
	hideControl.style.left = 'calc(50vw - var(--control-size)/2)';
	break;
case 'bottomleft':
	hideControl.style.top = null;
	hideControl.style.bottom = '0';
	hideControl.style.right = null;
	hideControl.style.left = '0';
	break;
case 'leftmiddle':
	hideControl.style.top = null;
	hideControl.style.top = 'calc(50vh - var(--control-size)/2)';
	hideControl.style.right = null;
	hideControl.style.left = '0';
	break;
default:
	doit=false;
};
//console.log('[hideControlsControl] hideControlPosition=',hideControlPosition,'doit=',doit);
if(doit){
	hideControl.style.display = 'unset';
	// Тут нужна именованная функция, тогда не будет повторной её установки в качестве обработчика.
	// А анонимная функция установится повторно, ибо все анонимные функции разные.
	// Авотхрен! И именованная функция тоже устанавливается многократно, несмотря на https://developer.mozilla.org/ru/docs/Web/API/EventTarget/addEventListener
	// Опять авотхрен! Именованная функция, определённая сдесь же - да, устанавливается многократно,
	// ибо да - она определяется снова, и тогда - другая. Т.е., должна быть именованная функция из
	// внешней области видимости. В данном случае - блин, глобальная.
	//hideControl.removeEventListener('click', hideControlEventListener);
	hideControl.addEventListener('click', hideControlEventListener);	
};
}; // end function hideControlsControl


function hideControlEventListener(event){
	//console.log('hideControl click:',event);
	for(let control of controlsList){
		//console.log('hideControl click control:',control.getContainer().style.display);
		//if(control._map) control.remove();	// так оно удаляется из DOM, а у нас везде используются значения полей и переключателей.
		//else control.addTo(map);
		if(control.getContainer().style.display == 'none') control.getContainer().style.display = 'unset';
		else control.getContainer().style.display = 'none';
	};
}; // end function hideControlEventListener


function hideControlsToggler(target){
/*  */
//console.log('[hideControlsToggler] target:',target);
if(target.value == 'onoffswitch') {
	if(target.checked){	// возможность сокрытия включили
		for(let radio of settings.querySelectorAll('input[type="radio"][name="hideControlPosition"]')){
			//console.log('[hideControlsToggler] radio:',radio);
			radio.disabled = false;
			if(radio.checked) hideControlsControl(radio.value);
		};
	}
	else{	// возможность сокрытия выключили
		for(let radio of settings.querySelectorAll('input[type="radio"][name="hideControlPosition"]')){
			//console.log('[hideControlsToggler] radio:',radio);
			radio.disabled = true;
		};
		hideControl.removeEventListener('click', hideControlEventListener);
		hideControl.style.display = 'none';
	};
	storageHandler.save('hideControlsSwitch',hideControlsSwitch.checked);
}
else {	// изменили расположения переключателя сокрытия
	hideControlsControl(target.value);	// если возможность сокрытия выключена - то и сменить ничего нельзя.
	storageHandler.save('hideControlPosition',target.value);
};
}; // end function hideControlsToggler




// Функции маршрутной точки
function nextWPT(){
/* Там, однако, может не быть соединения с сервером. */
//console.log("nextWPT!",spatialWebSocket);
spatialWebSocket.send('?WPT={"action":"nextWPT"};');
}; // end function nextWPT

function prevWPT(){
/**/
//console.log("prevWPT!",spatialWebSocket);
spatialWebSocket.send('?WPT={"action":"prevWPT"};');
}; // end function prevWPT

function cancelFollowing(){
//console.log("cancelFollowing!",spatialWebSocket);
spatialWebSocket.send('?WPT={"action":"cancel"};');
}; // end function cancelFollowing

function startFollowing(){
/* Global currentRoute editableObjectLeafletID */
//console.log("startFollowing!",editableObjectLeafletID.value,currentRoute.getLayerRecursive(editableObjectLeafletID.value));
// Очистим возможное существующее указание на текущий маршрут и
// найдём объект, который будет новым текущим маршрутом
let target;
currentRoute.eachLayerRecursive(function(layer){
	if(currentRoute.getLayerId(layer)==editableObjectLeafletID.value) target = layer;
	if(layer.feature && layer.feature.properties && layer.feature.properties.cmt) {
		layer.feature.properties.cmt = layer.feature.properties.cmt.replace('current','');	// Во-первых, считаем, что current там встречается только один раз. Во-вторых, надеемся, что layer - это ссылка на соответствующий объект.
	};
})	// 
if(target == null){
	console.log("[startFollowing] Not found route to following in currentRoute:",currentRoute);
	return;
};
target.feature.properties.name = editableObjectName.value;
target.feature.properties.desc = editableObjectDescr.value;
target.feature.properties.cmt = (target.feature.properties.cmt||'')+" current";	// обозначим, что этому надо следовать. "Это" может быть как rte, так и wpt
DOsaveGPX(function (fileName){
	cancelEditing();
	fileName = `${selfServerPath}/${routeDir}/${fileName}`
	//console.log('Тут надо послать сигнал про',fileName);
	spatialWebSocket.send(`?WPT={"action":"start","wayFileName":"${fileName}"};`);
});
}; // end function startFollowing


function WPTbuttonsON(){
if(typeof followWPTbutton == 'undefined') return;	// кнопки могут отсутствовать у неполноценных юзеров
nextWPTbutton.disabled = false;
followWPTbutton.disabled = false;
followWPTbutton.innerHTML = nofollowWPTbuttonTXT;
followWPTbutton.removeEventListener('click',startFollowing);
followWPTbutton.addEventListener('click',cancelFollowing);
prevWPTbutton.disabled = false;
}; // end function WPTbuttonsON

function WPTbuttonsReady(){
if(typeof followWPTbutton == 'undefined') return;	// кнопки могут отсутствовать у неполноценных юзеров
// Неважно, есть ли уже режим следования или нет, делаем невозможным управление им
nextWPTbutton.disabled = true;
followWPTbutton.disabled = false;
followWPTbutton.innerHTML = followWPTbuttonTXT;
followWPTbutton.removeEventListener('click',cancelFollowing);
followWPTbutton.addEventListener('click',startFollowing);
prevWPTbutton.disabled = true;
}; // end function WPTbuttonsON

function WPTbuttonsOFF(){
if(typeof followWPTbutton == 'undefined') return;	// кнопки могут отсутствовать у неполноценных юзеров
nextWPTbutton.disabled = true;
followWPTbutton.disabled = true;
followWPTbutton.innerHTML = followWPTbuttonTXT;
//followWPTbutton.addEventListener('click',startFollowing);	// оно не нужно
prevWPTbutton.disabled = true;
}; // end function WPTbuttonsOFF


function WPTbuttonsNotReady(){
if(!followWPTbutton) return;	// кнопки могут отсутствовать у неполноценных юзеров
if(map.hasLayer(wptMarker)){	// на карте имеется путевая точка, режим следования включён?
	WPTbuttonsON();
}
else {	// режим следования выключен
	WPTbuttonsOFF();
};
};	// end function WPTbuttonsNotReady




// Управление панорамой
function PANOslaveSelect(event){
//console.log('[PANOslaveSelect] event:',event.target.options);
let selected = storageHandler.restore('PANOslaves') || [];
const UUIDregex = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
for (let i = 0; i < event.target.options.length; i++) {
    //console.log(event.target.options[i]);
	const index = selected.indexOf(event.target.options[i].value);
    if(event.target.options[i].selected){	// эта показывалка выбрана
    	//console.log('[PANOslaveSelect] является выбранной option:',event.target.options[i].value);
    	// Её нет в сохранённых и она не uuid, т.е. - не случайное имя
    	if (index == -1 && !UUIDregex.test(event.target.options[i].value)) selected.push(event.target.options[i].value);
    }
    else{	// эта показывалка не выбрана
    	//console.log('[PANOslaveSelect] является НЕ выбранной option:',event.target.options[i].value);
		if (index > -1) selected.splice(index, 1);	// удалить 1 элемент в положении index
    };
};
if(event.target.selectedOptions.length) panoControlMarker.addTo(map);	// покажем курсор панорамы
else {
	panoControlMarker.remove();	// Убрать маркер управления панорамой
	disablePANOcontrols();
};
storageHandler.save('PANOslaves',selected);
}; // end function PANOslaveSelect()


function clientNameUpdate(newName){
/* Global: clientName */
clientName = String(newName).trim();
storageHandler.save('clientName',clientName);
WATCHgreeting.clientName = clientName;
//console.log('[clientNameUpdate] новое имя=',newName,WATCHgreeting);
sendWATCH();	
}; // end function clientNameUpdate


function sendPanoControlMarkerPosition(){
/* Global: PANOslavesList panoControlMarker */
for (const option of PANOslavesList.selectedOptions) {
	//console.log('[sendPanoControlMarkerPosition] пошлём сообщение к',option.value,option.positionSended);
	sendCOMMAND('PANO',  {"clientToName":option.value, 
		"action":{
			"setViewPoint":{
				"point" : panoControlMarker.getLatLng(),
				"bearing" : panoControlMarker.options.rotationAngle
			}
		}
	});
};
}; // end function sendPanoControlMarkerPosition


function enablePANOcontrols(){
if(!panoControl.isOpen) return;	// панель управления панорамой закрыта
//panoControlMarker.addTo(map);
panoControlPad.querySelectorAll('button').forEach(btn => btn.disabled = false);	// включить кнопочки управления панорамой
panoControlPad.querySelectorAll('input').forEach(btn => btn.disabled = false);	// включить кнопочки управления панорамой
}; // end function enablePANOcontrols

function disablePANOcontrols(){
if(panoControlMarker) panoControlMarker.remove();	// Убрать маркер управления панорамой
panoControlPad.querySelectorAll('button').forEach(btn => btn.disabled = true);	// отключить кнопочки управления панорамой
panoControlPad.querySelectorAll('input').forEach(btn => {btn.disabled = true;});	// отключить кнопочки управления панорамой
}; // end function disablePANOcontrols


function sendCameraCommand(command){
/* Global: PANOslavesList panoControlMarker */
for (const option of PANOslavesList.selectedOptions) {
	//console.log('[sendCameraCommand] пошлём команду камеры',command,'к',option.value);
	sendCOMMAND('PANO',  {"clientToName":option.value, 
		"action":{
			"cameraCommand":command
		}
	});
};
}; // end function sendCameraCommand





// Общие функции

function loadScriptSync(scriptURL){
/* Синхронная загрузка javascript 
Вопреки распространённому мнению, script.async = false не приводит к синхронной загрузке.
Это свойство в случае загрузки скрипта из скрипта вообще ничего не делает, и имеет смысл
только при загрзке <script src=""><script>, где указывает, что надо сохранить порядок загрузки
*/
const xhr = new XMLHttpRequest();
xhr.open('GET', encodeURI(scriptURL), false); 	// Подготовим синхронный запрос
xhr.send();
if (xhr.status == 200) { 	// Успешно
	let script = document.createElement("script");
	script.textContent = xhr.responseText;
	document.head.appendChild(script);
	//console.log("[loadScriptSync] Загружен скрипт",scriptURL,script);
	return script;
}
return false;
} // end function loadScriptSync


// Отправка сообщений
function sendWATCH(){
/* Фактически, отправляет подписку 
Global: subscribe spatialWebSocket
*/
if(spatialWebSocket.readyState == 1) {
	WATCHgreeting.subscribe = subscribe.join();
	//console.log(`?WATCH=${JSON.stringify(WATCHgreeting)};`);
	spatialWebSocket.send(`?WATCH=${JSON.stringify(WATCHgreeting)};`);
};
}; // end function sendWATCH


function sendMessage(message=''){
/*  Global: messageQueue spatialWebSocket */
const queueLength = 5;	// сколько сообщений максимум будет в очереди, чтобы они не копились
if(message) messageQueue.push(message);	// добавим в конец
//console.log('[sendMessage] очередь сообщений',messageQueue);
while(messageQueue.length > queueLength){	// уберём сначала до нужной длины
	messageQueue.shift();
}
//console.log('[sendMessage] очередь сообщений',messageQueue);
if(spatialWebSocket.readyState == 1) {
	for(message of messageQueue){
		//console.log('[sendMessage] посылаем сообщение в spatialWebSocket',message);
		spatialWebSocket.send(message);
		messageQueue.shift();	
	};
};
}; // end function sendMessage


function sendCOMMAND(command,parametr){
command = `?${command}=${JSON.stringify(parametr)};`;
//console.log('[sendCOMMAND] кладём в очередь команду',command);
sendMessage(command);
}; // end function sendCOMMAND





function bearing(latlng1, latlng2) {
/**/
//console.log(latlng1,latlng2)
const rad = Math.PI/180;
let lat1,lat2,lon1,lon2;
lat1 = (latlng1.lat || latlng1.latitude || latlng1[0])  * rad;
lat2 = (latlng2.lat || latlng2.latitude || latlng2[0])  * rad;
lon1 = (latlng1.lng || latlng1.lon || latlng1.longitude || latlng1[1]) * rad;
lon2 = (latlng2.lng || latlng2.lon || latlng2.longitude || latlng2[1]) * rad;
//console.log('lat1=',lat1,'lat2=',lat2,'lon1=',lon1,'lon2=',lon2)

let y = Math.sin(lon2 - lon1) * Math.cos(lat2);
let x = Math.cos(lat1) * Math.sin(lat2) - Math.sin(lat1) * Math.cos(lat2) * Math.cos(lon2 - lon1);
//console.log('x',x,'y',y)

let bearing = ((Math.atan2(y, x) * 180 / Math.PI) + 360) % 360;
if(bearing >= 360) bearing = bearing-360;

return bearing;
} // end function bearing


function destinationPoint(latlng1,bearing,distance){
/*  http://www.movable-type.co.uk/scripts/latlong.html
Given a start point, initial bearing, and distance, this will calculate the destina­tion point 
travelling along a (shortest distance) great circle arc.
*/
const R = 6371e3; // metres
const rad = Math.PI/180;
lat1 = latlng1.lat || latlng1.latitude || latlng1[0];
lon1 = latlng1.lng || latlng1.lon || latlng1.longitude || latlng1[1];
const φ1 = lat1 * rad; // φ, λ in radians
const λ1 = lon1 * rad;
const brng = bearing * rad;

const φ2 = Math.asin( Math.sin(φ1)*Math.cos(distance/R) +
                      Math.cos(φ1)*Math.sin(distance/R)*Math.cos(brng) );
const λ2 = λ1 + Math.atan2(Math.sin(brng)*Math.sin(distance/R)*Math.cos(φ1),
                           Math.cos(distance/R)-Math.sin(φ1)*Math.sin(φ2));

let lon2 = λ2 / rad;
lon2 = (lon2+540)%360-180;	//  	The longitude can be normalised to −180…+180
const lat2 = φ2 / rad;

return({"lng":lon2,"lat":lat2});
}; // end function destinationPoint



function tileNum2degree(zoom,xtile,ytile) {
/* Tile numbers to lon./lat. left top corner
// http://wiki.openstreetmap.org/wiki/Slippy_map_tilenames
*/
const n = Math.pow(2, zoom)
const lon_deg = xtile / n * 360.0 - 180.0;
const nn = Math.PI - (2 * Math.PI * ytile) / Math.pow(2, zoom);
const lat_deg = (180 / Math.PI) * Math.atan(0.5 * (Math.exp(nn) - Math.exp(-nn)));
return {'lat': lat_deg,'lng': lon_deg};
}; // end function tileNum2degree


function isValidTile(z, x, y) {
/* проверяет, номер тайла ли */
if (!Number.isInteger(z) || z < 0 || z > 22) return false;
const max = (1 << z) - 1;	// 2^z - 1   Максимальное количество тайлов в строке или колонке на уровне z
if (!Number.isInteger(x) || x < 0 || x > max) return false;
if (!Number.isInteger(y) || y < 0 || y > max) return false;
return true;
}; // end function isValidTile


/**
Эти казлы так и ниасилили юникод в JavaScript. Багу более 15 лет.
 * ASCII to Unicode (decode Base64 to original data)
 * @param {string} b64
 * @return {string}
 */
function atou(b64) {
  return decodeURIComponent(escape(atob(b64)));
}

/**
 * Unicode to ASCII (encode data to Base64)
 * @param {string} data
 * @return {string}
 */
function utoa(data) {
  return btoa(unescape(encodeURIComponent(data)));
}


function realtime(dataUrl,fUpdate,upData) {
/* Запрашивает dataUrl с параметрами upData, и скармливает полученное функции fUpdate
fUpdate - функция обновления. Все должно делаться в ней. Получает json object
upData - данные для отправки
*/
//console.log('[realtime] dataUrl=',dataUrl);
//console.log('[realtime] upData:',upData);
if(upData) {
	if(dataUrl.includes('?')) dataUrl += '&upData=';
	else dataUrl += '?upData=';
	dataUrl += encodeURIComponent(JSON.stringify(upData));
}
fetch(dataUrl)
.then((response) => {
    return response.text();
})
.then(data => { 		// The Body mixin of the Fetch API represents the body of the response/request, allowing you to declare what its content type is and how it should be handled.
	try {
		//console.log('[realtime] data=', data);
		return JSON.parse(data);
	}
	catch(err) {
		// error handling
		//console.log(err);
		throw Error(err); 	// просто сбросим ошибку ближайшему catch
	}
})
.then(data => {
	//console.log('RealTime inbound data',data);
	for (let prop in upData) {  	// очистим передаваемые данные, раз сеанс связи состоялся
		delete upData[prop];
	}
	fUpdate(data);
})
.catch( (err) => {
	fUpdate({'error':err.message});
});

}; 	// end function realtime



/* Определения классов */
String.prototype.encodeHTML = function () {
    return this.replace(/&/g, '&amp;')
               .replace(/</g, '&lt;')
               .replace(/>/g, '&gt;')
               .replace(/"/g, '&quot;')
               .replace(/'/g, '&apos;');
};


// control для копирования в клипбоард
L.Control.CopyToClipboard = L.Control.extend({
	onAdd: function(map) {
			var div = L.DomUtil.create('div','CopyToClipboardClass');
			div.innerHTML = `
				<span id='copyToClipboardMessage' onClick='doCopyToClipboard()'></span>
				<input id='copyToClipboardField' type='text'  size='12' >
			`;
			return div;
		},
	onRemove: function(map) {
		// Nothing to do here
		}
}); // end L.Control.CopyToClipboard

L.Layer.include({	
	getParentLayer: function() {return this._map || this._mapToAdd;}
});


L.LayerGroup.include({	
	// рекурсивный eachLayer. Их просили это сделать с 2016 года, но они только плачь по Украине осилили. 
	// https://github.com/Leaflet/Leaflet/issues/4461
	eachLayerRecursive: function(method, context) {
		this.eachLayer(function(layer) {
			if (layer._layers) layer.eachLayerRecursive(method, context);	// а почему они не применяют instanceof? Медленно? 
			else method.call(context, layer);
		});
	},
	// рекурсивный getLayers
	getLayersRecursive: function(classOnly=undefined) {
		let res = [];
		this.eachLayer(function(layer){
			if (layer._layers) res.concat(layer.getLayersRecursive());
			else {
				if(classOnly){
					if(layer instanceof classOnly) res.push(layer);
				}
				else res.push(layer);
			};
		});
		return res;
	},
	// рекурсивный hasLayer
	hasLayerRecursive: function(what) {
		let res = false;
		if(this.hasLayer(what)) return true;
		for(const layer of this.getLayers()){	// нужно прекратить обход, eachLayer не подойдёт
			if(!(layer instanceof L.LayerGroup)) continue;	// это не LayerGroup
			if(layer.hasLayer(what)) return true;
			else res = layer.hasLayerRecursive(what);
		}
		return res;
	},
	// рекурсивный getLayer Returns the layer with the given internal ID.
	getLayerRecursive: function(what) {
		let res = this.getLayer(what);
		if(res!=null) return res;
		for(const layer of this.getLayers()){	// нужно прекратить обход, eachLayer не подойдёт
			if(!(layer instanceof L.LayerGroup)) continue;	// это не LayerGroup
			res = layer.getLayer(what);
			if(res!=null) return res;
			else res = layer.getLayerRecursive(what);
		}
		return res;
	}
}); // end L.LayerGroup.include


L.RotateMarker = L.Marker.extend({
// Подразумевается, что Leaflet и Leaflet.RotatedMarker уже подключены
options: {    // Опции для L.RotatedMarker
	rotationAngle: 0,
	rotationOrigin: 'bottom center',
},

initialize: function (latlng, options) {
	L.Marker.prototype.initialize.call(this, latlng, options);	// Инициализация базового маркера
	this._isRotating = false;	// Инициализация состояния вращения
},

onAdd: function (map) {
	L.Marker.prototype.onAdd.call(this, map);	// Вызываем onAdd родительского класса
	this._map = map;	// Ссылка на карту
	this.on('click', this._toggleRotation, this);	// Привязываем события мыши
},	// end onAdd

onRemove: function (map) {
	// Убираем обработчики при удалении с карты
	this.off('click', this._toggleRotation, this);
	L.Marker.prototype.onRemove.call(this, map);
},	// end onRemove

_toggleRotation: function (eventL) {
	//L.DomEvent.preventDefault(event);
	L.DomEvent.stop(eventL);
	if(this._isRotating){	// вращение включено, надо выключить
		this._isRotating = false;
		this._map.off('mousemove', this._rotate, this);
		this._map.off('click', this._rotate, this);
		this.fire('markerRotateEnd', {});
	}
	else{
		this._isRotating = true;
		this._map.on('mousemove', this._rotate, this);
		this._map.once('click', function () {
			this._isRotating = false;
			this._map.off('mousemove', this._rotate, this);
			//console.log('[_toggleRotation] off');
			// Создаём событие и сразу его запускаем.
			// Но его нельзя запустить от this, потому что у this нет dispatchEvent. Чтобы была
			// dispatchEvent, нужно чтобы класс L.RotateMarker extends EventTarget и имел 
			// constructor() {super()}. Как это здесь сделать - я не знаю.
			// Поэтому запускаем событие от того, что, внезапно, есть и имеет dispatchEvent,
			// а нужное передаём в detail.
			//const markerRotateEndEvent = new CustomEvent("markerRotateEnd",{"detail":{"realTarget":this},"bubbles": true});
			//this._icon.dispatchEvent(markerRotateEndEvent);
			// Но Агафонкин обо всём, оказывается, уже позаботился:
			this.fire('markerRotateEnd', {});
		}, this);
	};
}, // end _toggleRotation

_rotate: function (eventL) {
// Устанавливаем угол поворота (используем метод из L.RotatedMarker)
	// event leaflet какой-то неправилный event
	if (!this._isRotating) return;
	//L.DomEvent.preventDefault(eventL);
	L.DomEvent.stop(eventL);
	//console.log('eventL.latlng:',eventL.latlng,'this.getLatLng:',this.getLatLng())
	this.setRotationAngle(bearing(this.getLatLng(), eventL.latlng));
}	// end _rotate
});
// Вспомогательная функция для создания экземпляра
L.rotateMarker = function (latlng, options) {
	return new L.RotateMarker(latlng, options);
};
//




const storageHandler = {
	_storageName : 'GaladrielMapOptions',
	_store: {'empty':true},	// типа, флаг, что ещё не считывали из хранилища. Так проще и быстрей в этом кривом языке.
	storage: false,	// теоретически, можно указать, куда именно записывать? Но только мимо проверки доступности.
	//storage: 'cookie',
	//storage: 'storage',
	save: function(key,value=null){
		/* сохраняет key->value, но можно передать список пар одним параметром 
		или просто строку с именем переменной */
		let values = {};
		if(arguments.length == 2){	// два аргумента - это key->value
			values[key] = value;
		}
		else if(typeof key == 'object') {	// один, но список key->value
			values = key;
		}
		else {	// один, тогда это строка - имя переменной
			//values[key] = window[key];	// это обломается, если key - не глобальная переменная, объявленная через var
			// поэтому нижесказанное - единственный способ получить значение объекта по его имени.
			// Он сработает и с локальным объектом, и с объектами, объявленными через let и const
			values[key] = eval(key);
			//console.log('[storageHandler] save key=',key,window[key]);
		};
		//console.log('[storageHandler] save',values,'to storage:',this.storage,'store:',this._store);
		for(let key in values){
			this._store[key] = values[key];
		};
		this._store.empty = false;
		this._saveStore();
	},
	restore: function(key){
		//alert('[storageHandler] restore '+key);
		if(this._store.empty){
			this._restoreStore();
			this._store.empty = false;
		};
		return this._store[key.trim()];
	},
	restoreAll: function(){
		if(this._store.empty){
			this._restoreStore();
			this._store.empty = false;
		};
		delete this._store.empty;
		for(let varName in this._store){
			window[varName] = this._store[varName];	// window[varName] - создаётся глобальная переменная с именем, являющимся значением varName
		};
		this._store.empty = false;
	},
	del: function(key){
		if(this._store.empty){
			this._restoreStore();
			this._store.empty = false;
		};
		delete this._store[key.trim()];
		this._saveStore();
	},
	_findStorage: function(){
		try {
			window.localStorage.setItem("__storage_test__", "__storage_test__");
			window.localStorage.removeItem("__storage_test__");
			this.storage='storage';
		}
		catch (err) {
			this.storage='cookie';	// куки-то всегда можно, да?
		};
	},
	_saveStore: function(){
		if(!this.storage) this._findStorage();
		switch(this.storage){
		case 'storage':
			//console.log('_saveStore:',JSON.stringify(this._store));
			window.localStorage.setItem(this._storageName, JSON.stringify(this._store));
			break;
		case 'cookie':
			let expires = new Date(Date.now() + (60*24*60*60*1000));	// протухнет через два месяца
			expires = expires.toUTCString();
			document.cookie = this._storageName+"="+JSON.stringify(this._store)+"; expires="+expires+"; path=/; SameSite=Lax;";
			break;
		default:
			console.log('storageHandler: the parameters are not saved, there is nowhere');
		};
	},
	_restoreStore: function(){
		if(!this.storage) this._findStorage();
		switch(this.storage){
		case 'storage':
			this._store = JSON.parse(window.localStorage.getItem(this._storageName));
			//console.log('_restoreStore:',JSON.stringify(this._store));
			if(!this._store) this._store = {'empty':true};
			break;
		case 'cookie':
			this._store = JSON.parse(document.cookie.match(new RegExp(
				"(?:^|; )" + this._storageName.replace(/([\.$?*|{}\(\)\[\]\\\/\+^])/g, '\\$1') + "=([^;]*)"
			))[1]);
			if(!this._store) this._store = {'empty':true};
			break;
		default:
			console.log('storageHandler: no saved parameters, there is nowhere');
		};
	}
}; // end storageHandler

/*//////// for collision test purpose /////////
// Функции для отладки предупреждения о столкновениях
function displayCollisionAreas(selfArea=null){
//
function mkPolyline(area){
	let polyline = [];
	area.forEach(point => {polyline.push([point.lat,point.lon]);});
	polyline.push([area[0].lat,area[0].lon]);
	return polyline;
};
//collisisonAreas.remove();	// так гораздо медленней
collisisonAreas.clearLayers();	// очистим слой 
if(selfArea){
	//console.log('selfArea:',selfArea);
	let polyline = mkPolyline(selfArea);
	collisisonAreas.addLayer(L.polyline(polyline,{color: 'red',weight: 2,}));
}
for(let vessel in vehicles){
	//console.log(vessel,vehicles[vessel]);
	if(!vehicles[vessel].options.collisionArea) continue;	// 
	//console.log(vessel,vehicles[vessel].options.collisionArea);
	let polyline = mkPolyline(vehicles[vessel].options.collisionArea);
	//console.log('vessel',vessel,'course=',vehicles[vessel].options.course,'polyline:',polyline.length);
	collisisonAreas.addLayer(L.polyline(polyline,{color: 'red',weight: 2,}));
};
collisisonAreas.addTo(map);
} // end function displayCollisionAreas

/*//////// for collision test purpose /////////

