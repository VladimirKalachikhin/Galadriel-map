PLEASE! If you may use Apache - use it!

Place all files, except README.txt to  /etc/nginx/conf.d/
or place nginx_galadrielmap_conf directory to /etc/nginx/ and edit nginx.conf by add 
 include nginx_galadrielmap_conf/*.conf;
string to end default server{ listen 80 default_server; } section
restart nginx
 
Используйте Apache, если это возможно! Не надо вот этого...

Поместите все файлы из этого каталога (за исключением README.txt) в каталог /etc/nginx/conf.d/
или
поместите этот каталог рядом с каталогом /etc/nginx/conf.d и добавьте в nginx.conf строку
 include nginx_galadrielmap_conf/*.conf;
в конец главного блока server{ listen 80 default_server; }
перезапустите nginx
