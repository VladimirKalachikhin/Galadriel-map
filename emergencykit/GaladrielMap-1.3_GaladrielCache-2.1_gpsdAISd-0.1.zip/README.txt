It does not work on Windows!
This contains complete and configured GaladrielMap and GaladrielCache.
Place GaladrielMap directory in root filesystem and update web server configuration.
Apache configuration contains in apache2_galadrielmap.conf Manual inside.
Nginx configuration contains in nginx_galadrielmap_conf Manual also inside.

Apache more, more simply to configuration, and has excellent performance. Use it!


Архив содержит полный набор файлов GaladrielMap и GaladrielCache, сконфигурированных и готовых к использованию.
Предполагается, что каталог GaladrielMap расположен в корне файловой системы.
apache2_galadrielmap.conf - конфигурация для сервера Apache. Внутри файла есть инструкция.
Каталог nginx_galadrielmap_conf - конфигурация для сервера Nginx. Инструкция то же есть.

Разумеется, сервер не может быть под управлением Windows. 
Если имеется возможность выбора веб-сервера - всегда используйте Apache. Настройка Nginx весьма нетривиальна, и с первого раза не получится. И оно того не стоит.
