По-русски ниже.
It does not work on Windows!

Prepare SD card to cache

# mkfs.ext4 -O 64bit,metadata_csum -b 4096 -i 4096 /dev/sdb1

-b 4096 -i 4096 set block to 4096 bytes and increase i-nodes to max.  
-O 64bit,metadata_csum needs for compability with old Android devices.  
/dev/sdb1 - your SD card partition.

You must have the PHP7 installed with modules:
cli
php-fpm - if you don't use Apache2
curl
exif
fileinfo
gd
iconv
json
mbstring
openssl
pcntl
session
shmop
simplexml
sockets
sqlite3
tokenizer
zip
These modules are included in the PHP by default in "full" linux, but not in OpenWRT nor Raspberry Pi oses.

This contains complete and configured GaladrielMap and GaladrielCache wit local AIS & netAIS support.
BUT EXCEPTION!: You must update /GaladrielMap/netAIS/params.php to you actual .onion address from TOR 'hostname' file, for example:
# cat /var/lib/tor/hidden_service_netAIS/hostname
in Ubuntu, see torrc config file. Without this, you will not be able to open you private netAIS group. But be able to connect to others.

Place GaladrielMap directory from zip to root filesystem:
unzip GaladrielMap-2.0_GaladrielCache-2_gpsdPROXY-0_netAIS-1.zip "GaladrielMap/*" -d /
Set owner, if you want:
chown -hR :www-data /GaladrielMap
Set write rights to tiles directory if it is necessary:
$ chmod 775 /GaladrielMap/tileproxy/tiles
Also set write rights to directories:
$ chmod 775 /GaladrielMap/tileproxy/loaderJobs
$ chmod 775 /GaladrielMap/netAIS/data
$ chmod 775 /GaladrielMap/netAIS/server

And update web server configuration:
Apache configuration contains in apache2_galadrielmap.conf Manual inside.
Nginx configuration contains in nginx_galadrielmap_conf Manual also inside.
hiawatha configuration for VenusOS contains in hiawatha_galadrielmap.conf Manual inside

TOR configuration is tor/ Copy the contents to \etc\tor. Do not copy the torrc.custom the TOR is not blocked in your country.
It is advisable to change the addresses inside torrc to the current ones.

Apache more, more simply to configuration, and has excellent performance. Use it!
Apache configuration:
Copy GaladrielMap config to Apache sites configs dir:
sudo unzip GaladrielMap-1.4_GaladrielCache-2.3_gpsdAISd-1.0_netAIS-0.0.zip "apache2_galadrielmap.conf" -d /etc/apache2/sites-available/
Create symlink to enable:
sudo ln -s /etc/apache2/sites-available/apache2_galadrielmap.conf /etc/apache2/sites-enabled/apache2_galadrielmap.conf
Restart apache:
sudo service apache2 restart

Now set up vehicle info in /GaladrielMap/netAIS/boatInfo.ini

The /GaladrielMap/map/samples directory contains an NMEA demo file and a tool to play it back.
To see the simulation of GPS and AIS signal reception, you need to run the player and gpsd, as descripted in the documentation.
However, if gps starts automatically in your system, you must first stop it with the following commands:
# systemctl stop gpsd
# systemctl stop gpsd.socket
them 
$ /GaladrielMap/map/samples/startSimulation

To stop simulation:
$ /GaladrielMap/map/samples/stopSimulation


Архив содержит полный набор файлов GaladrielMap и GaladrielCache с поддержкой AIS и netAIS, сконфигурированных и готовых к использованию.
За исключением! Нужно указать фактически получившийся после конфигурации скрытого сервиса tor .onion адрес в /GaladrielMap/netAIS/params.php
Адрес находится в файле hostname, расположенном по пути, указанном в файле конфигурации tor torrc. В Ubuntu это 
# cat /var/lib/tor/hidden_service_netAIS/hostname
при использовании приложенного файла torrc.
Если не указать ваш .onion адрес в /GaladrielMap/netAIS/params.php, то нельзя будет организовать собственную группу netAIS. Но подключиться к другим -- можно.

Подготовка SD накопителя:

# mkfs.ext4 -O 64bit,metadata_csum -b 4096 -i 4096 /dev/sdb1

-b 4096 -i 4096 устанавливает размер блока файловой системы в 4096 bytes и увеличивает количество i-nodes до максимально возможного.  
-O 64bit,metadata_csum требуется для совместимости с некоторыми устройствами на Android. Не обязательно.  
/dev/sdb1 - требуемый раздел на SD накопителе.

На сервере должен быть установлен PHP7 со следующими модулями:
cli
php-fpm - если предполагается использовать не Apache2
curl
exif
fileinfo
gd
iconv
json
mbstring
openssl
pcntl
session
shmop
simplexml
sockets
sqlite3
tokenizer
zip
Все эти модули обычно входят в состав PHP в "полноценных" вариантах Linux, но в OpenWRT и сборках для Raspberry Pi многие из этих модулей надо ставить отдельно.

Установка программ:
Предполагается, что каталог GaladrielMap расположен в корне файловой системы:
unzip GaladrielMap-2.0_GaladrielCache-2_gpsdPROXY-0_netAIS-1.zip "GaladrielMap/*" -d /
Установите владельца, если нужно (нужно в полноценных системах):
chown -hR :www-data /GaladrielMap
Не забудьте дать права на запись в каталог, куда будут складываться тайлы:
$ chmod 777 /GaladrielMap/tileproxy/tiles
, а также на каталоги
$ chmod 777 /GaladrielMap/map/track
$ chmod -R 775 /GaladrielMap/tileproxy/loaderJobs
$ chmod -R 775 /GaladrielMap/netAIS/data
$ chmod 775 /GaladrielMap/netAIS/server

apache2_galadrielmap.conf -- конфигурация для сервера Apache. Внутри файла есть инструкция.
Каталог nginx_galadrielmap_conf - конфигурация для сервера Nginx. Инструкция тоже есть.
hiawatha_galadrielmap.conf -- конфигурация для веб-сервера hiawatha, используемого в VenusOS. Инструкция внутри файла. Её надо обязательно прочесть!

Конфигурация tor находится в каталоге tor/. Просто скопируйте содерживое в \etc\tor. Файл torrc.custom нужен для обхода блокировки TOR в России. Рекомендуется ознакомиться с содержимым.
Возможно, потребуется поменять адреса в соответствии с установкой tor.

Разумеется, сервер не может быть под управлением Windows. 
Если есть возможность выбора веб-сервера - всегда используйте Apache. Настройка Nginx требует лишних знаний и с первого раза не получится. И оно того не стоит.
Настройка Apache:
Скопируйте конфиг от GaladrielMap в каталог для конфигов Apache:
sudo unzip GaladrielMap-1.4_GaladrielCache-2.3_gpsdAISd-1.0_netAIS-0.0.zip "apache2_galadrielmap.conf" -d /etc/apache2/sites-available/
Сделайте символьную ссылку для подключения конфига:
sudo ln -s /etc/apache2/sites-available/apache2_galadrielmap.conf /etc/apache2/sites-enabled/apache2_galadrielmap.conf
Перезапустите Apache:
sudo service apache2 restart

Наконец, укажите параметры судна для netAIS: in /GaladrielMap/netAIS/boatInfo.ini

В каталоге /GaladrielMap/map/samples имеется демонстрационный файл NMEA и средство для его проигрывания.
Чтобы увидеть имитацию получения сигнала ГПС и AIS, нужно запустить проигрыватель и gpsd, как указано в документации.
Однако, если в вашей системе gpsd запускается автоматически, его нужно сначала остановить следующими командами:
# systemctl stop gpsd
# systemctl stop gpsd.socket

после этого можно просто
$ /GaladrielMap/map/samples/startSimulation

Для остановки имитации:
$ /GaladrielMap/map/samples/stopSimulation

