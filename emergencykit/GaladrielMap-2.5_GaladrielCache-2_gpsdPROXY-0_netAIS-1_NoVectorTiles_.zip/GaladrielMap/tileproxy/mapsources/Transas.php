<?php
/*
https://www.fleetviewonline.com/cdmo/html5/#/fvo
Нет высот мостов и ЛЭП

Надо сперва зайти:
https://www.fleetviewonline.com/fvo/logonff/login.ashx?UID=Guest&PWD=Guest
Будут положены куки:
/		AD	77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48U2VjdXJpdHlDb250ZXh0VG9rZW4gcDE6SWQ9Il9lNjk0OTk3Mi1kOTU3LTRlOTctOGY2Mi02NmNmNTM5NTA0YjgtMEQyNzBFMDhERDc2MTZENTM1NThCN0RGQzQwRUVFRjkiIHhtbG5zOnAxPSJodHRwOi8vZG9jcy5vYXNpcy1vcGVuLm9yZy93c3MvMjAwNC8wMS9vYXNpcy0yMDA0MDEtd3NzLXdzc2VjdXJpdHktdXRpbGl0eS0xLjAueHNkIiB4bWxucz0iaHR0cDovL2RvY3Mub2FzaXMtb3Blbi5vcmcvd3Mtc3gvd3Mtc2VjdXJlY29udmVyc2F0aW9uLzIwMDUxMiI+PElkZW50aWZpZXI+dXJuOnV1aWQ6ZDcyNjY4NzctZWM1Ni00MGZiLWIxNTQtZDdiNGMyNTJhOGZiPC9JZGVudGlmaWVyPjxJbnN0YW5jZT51cm46dXVpZDozYjkxNDcwNy1hOGE1LTRjNmEtOThhMi0yNjJiODA1MzQyOTY8L0luc3RhbmNlPjwvU2VjdXJpdHlDb250ZXh0VG9rZW4+
			77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48U2VjdXJpdHlDb250ZXh0VG9rZW4gcDE6SWQ9Il9jYzg4MGI4MS05MjlkLTRhZWYtOTIyYi03MDI5MDc5NzgzNGUtN0Q1NTQ5N0NBNDZGN0IzODQ5MUJCREQyN0I1QUY1MzUiIHhtbG5zOnAxPSJodHRwOi8vZG9jcy5vYXNpcy1vcGVuLm9yZy93c3MvMjAwNC8wMS9vYXNpcy0yMDA0MDEtd3NzLXdzc2VjdXJpdHktdXRpbGl0eS0xLjAueHNkIiB4bWxucz0iaHR0cDovL2RvY3Mub2FzaXMtb3Blbi5vcmcvd3Mtc3gvd3Mtc2VjdXJlY29udmVyc2F0aW9uLzIwMDUxMiI+PElkZW50aWZpZXI+dXJuOnV1aWQ6NzFmZWQ2NmItNjMzZS00ZGJiLTgyMGEtNTg4N2ViYmFkOTUzPC9JZGVudGlmaWVyPjxJbnN0YW5jZT51cm46dXVpZDozMjFjYTgzMS01ZDI0LTRiODktODlmNS00YmVlNWU0NjI0M2Y8L0luc3RhbmNlPjwvU2VjdXJpdHlDb250ZXh0VG9rZW4+
			77u/PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0idXRmLTgiPz48U2VjdXJpdHlDb250ZXh0VG9rZW4gcDE6SWQ9Il9jYzg4MGI4MS05MjlkLTRhZWYtOTIyYi03MDI5MDc5NzgzNGUtMjBGMzVGRTQ3OUYwRjZERDMxNEJEMkE4QjhBODdDNTAiIHhtbG5zOnAxPSJodHRwOi8vZG9jcy5vYXNpcy1vcGVuLm9yZy93c3MvMjAwNC8wMS9vYXNpcy0yMDA0MDEtd3NzLXdzc2VjdXJpdHktdXRpbGl0eS0xLjAueHNkIiB4bWxucz0iaHR0cDovL2RvY3Mub2FzaXMtb3Blbi5vcmcvd3Mtc3gvd3Mtc2VjdXJlY29udmVyc2F0aW9uLzIwMDUxMiI+PElkZW50aWZpZXI+dXJuOnV1aWQ6MGM4OGFlYjItZjNkYy00ZmNkLTk2ZDUtYThhNGU2NzIyM2VhPC9JZGVudGlmaWVyPjxJbnN0YW5jZT51cm46dXVpZDo5YjI0YjA4ZS03YWQ4LTQzMTItYjBlYi00YmJiNWMwMDdjOGM8L0luc3RhbmNlPjwvU2VjdXJpdHlDb250ZXh0VG9rZW4+
/fvo	UD1	1295D3C0BA85F3CA07EC90B13EC4775673E7C258E029862E911D174A2ACB411D5D34265208C097B9607276F6E77980AB35ADACEE7D404443D606B5F7A439D15A8049434B11F00DC5DAD7E235A5EA18AE541E965E27707841B3A961AECF5B3DAC52085B8C1BD93729587D625C0CAEBF05422CF5461FFE77E6F6F7C4ACF25C71AA75485EF32C488140F0831C43A104D5ABA8954D7B8DBD17DB9E7EB6A0141A3768310B36FAAAA2ACCDFD423D414F68A29AA73B2568E2D71D607A4FE3D640B147CB
			596EA2F1D999D32F7991FF1B98A3B7D68FFF7DA40DF4BC4D05C7A9889817725CD8D1A87C7273D1953D7927ABBD4812C550F1D7D8228452B5B0256FBBFF73BE98A3B7F6BEB647660B0ACC1B0196821E0D34C47652B281235246FACA3B80E287EAEFBD01ADF495653221C0C7F028AAB04910A056ED22FA62A04A2327C1F284CBE20AC31F4DAE1BFC7A88CC6C2B52765AA67930E5159FD1734C31DAEA968847813958D244BFB46763C3D0E434966A3C7AF5E206DE90BDA0269D606CA58841179E0C
/ LastOpenedPage	Home
 
Потом можно получить тайл:
https://www.fleetviewonline.com/cdmo/Services/Charts/ChartWms.ashx?service=WMS&request=GetMap&version=1.3.0&layers=trs_inset%2Ctrs_coastline%2Ctrs_drying_area%2Ctrs_depth_contour%2Ctrs_lighthouse%2Ctrs_buoy%2Ctrs_racon%2Ctrs_sounding%2Ctrs_drying_height%2Ctrs_isolated_danger%2Ctrs_line%2Ctrs_recommended_route%2Ctrs_text%2Ctrs_other_feature%2Ctrs_ground%2Ctrs_contour_line%2Ctrs_height%2Ctrs_coastline_object&styles=&format=image%2Fpng&transparent=false&maxZoom=18&crs=EPSG%3A3857&width=256&height=256&bbox=3346107.3502119,8375052.3151502,3355891.2898324,8384836.2547707
https://www.fleetviewonline.com/cdmo/Services/Charts/ChartWms.ashx?service=WMS&request=GetMap&version=1.3.0&layers=trs_inset%2Ctrs_coastline%2Ctrs_drying_area%2Ctrs_depth_contour%2Ctrs_lighthouse%2Ctrs_buoy%2Ctrs_racon%2Ctrs_sounding%2Ctrs_drying_height%2Ctrs_isolated_danger%2Ctrs_line%2Ctrs_recommended_route%2Ctrs_text%2Ctrs_other_feature%2Ctrs_ground%2Ctrs_contour_line%2Ctrs_height%2Ctrs_coastline_object&styles=&format=image%2Fpng&transparent=false&maxZoom=18&crs=EPSG%3A3857&width=256&height=256&bbox=3346107.3502119,8365268.3755297,3355891.2898324,8375052.3151502
https://www.fleetviewonline.com/cdmo/Services/Charts/ChartWms.ashx?service=WMS&request=GetMap&version=1.3.0&layers=trs_inset%2Ctrs_coastline%2Ctrs_drying_area%2Ctrs_depth_contour%2Ctrs_lighthouse%2Ctrs_buoy%2Ctrs_racon%2Ctrs_sounding%2Ctrs_drying_height%2Ctrs_isolated_danger%2Ctrs_line%2Ctrs_recommended_route%2Ctrs_text%2Ctrs_other_feature%2Ctrs_ground%2Ctrs_contour_line%2Ctrs_height%2Ctrs_coastline_object&styles=&format=image%2Fpng&transparent=false&maxZoom=18&crs=EPSG%3A3857&width=256&height=256&bbox=3355891.2898324,8365268.3755297,3365675.2294529,8375052.3151502
и будут положены куки:

/cdmo	UD1	CC68DAF643DEF599AAB00CE645034C82C20C49D574E815765097C576BF2E9EA5316D6D65A8D11F29A4385377A4BBAF14C09020527C89F35E459CA2D0674D39BF7C710150E30777192C796589EE2FE1BA18C86C84D57A953077452C09652316AB7922EE4E4870B9F07C43BFE976576A1199FE69B498FD82DFB453052090219E76E1105D1B358816420281D3BC1D1E7AE388C72F788AE4B49E4D10D4439667785851B603EDA519A464BAE171CA4E3F9A77F8DE9231B5CED68B457FFB4DC4F57B26
/		ASP.NET_SessionId	qwtfoc1cat2b4epdckp2vc1v

но никакие из них не нужны, кроме AD. Имея только AD, можно получать тайлы
И оно действительно получается. Т.е., если здесь указать свежий AD -- файл отдаётся.
*/
require_once('fcommon.php');

//$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, один год
$ttl = 86400*30; //cache timeout in seconds время, через которое тайл считается протухшим, один месяц
// $ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$ContentType = 'image/png'; 	// if content type differ then file extension
$minZoom = 2;
$maxZoom = 18;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,19905,9851,'d670a7b3');	// to source check; tile number and CRC32b hash

// $getURLparams -- массив со всяким для tilefromsource.php
// поскольку этот файл require там, где это всё есть:
$getURLparams['tileCacheDir'] = $tileCacheDir;
$getURLparams['mapSourcesName'] = $mapSourcesName;

$functionGetURL = <<<'EOFU'
function getURL($z,$x,$y,$getURLparms) {
/* 
Меркатор на сфере
*/
global $on403; 	// потому что мы собираемся менять этот параметр уже после require этого файла
$loginUrl = 'https://www.fleetviewonline.com/fvo/logonff/login.ashx?UID=Guest&PWD=Guest';
$tokenTimeOut = 30*60; // сек. - время, через которое токен считается протухшим, и надо запрашивать снова
// set it if you hawe Tor as proxy, and want change exit node every $tilesPerNode try. https://stackoverflow.com/questions/1969958/how-to-change-the-tor-exit-node-programmatically-to-get-a-new-ip
// tor MUST have in torrc: ControlPort 9051 without authentication: CookieAuthentication 0 and #HashedControlPassword
// Alternative: set own port, config tor password by tor --hash-password my_password and stay password in `echo authenticate '\"\"'`
$getTorNewNode = "(echo authenticate '\"\"'; echo signal newnym; echo quit) | nc localhost 9051"; 	

$userAgents = array();
$userAgents[] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36';
$userAgents[] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0';
$userAgents[] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36';
$userAgents[] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36';
$userAgents[] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36';
$userAgents[] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_3) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0.3 Safari/604.5.6';
$userAgents[] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36';
$userAgents[] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0';
$userAgents[] = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0';
$userAgents[] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:59.0) Gecko/20100101 Firefox/59.0';
$userAgent = $userAgents[array_rand($userAgents)];

$RequestHead='Referer: https://www.fleetviewonline.com/cdmo/html5/';
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8\r\n" . 
"Accept-Encoding: gzip, deflate, br\r\n" .
"Accept-Language: ru,en-US;q=0.7,en;q=0.3\r\n" .
"Connection: keep-alive\r\n" .
"DNT: 1\r\n" .
"Host: www.fleetviewonline.com\r\n" .
"Sec-Fetch-Dest: document\r\n" . 
"Sec-Fetch-Mode: navigate\r\n" . 
"Sec-Fetch-Site: none\r\n" . 
"Sec-Fetch-User: ?1\r\n" . 
"TE: trailers\r\n" . 
"Upgrade-Insecure-Requests: 1\r\n" . 
"User-Agent: $userAgent\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE
	),
);

$tokenFileName = "{$getURLparms['tileCacheDir']}/{$getURLparms['mapSourcesName']}/token";
//echo "tokenFileName=$tokenFileName;\n";
list($token,$tokenTimeStamp) = @$_SESSION['TransasToken'];
if(!$token) { 	// нет сессии - протухла или клиент cli, или клиент не умеет печеньки
	list($token,$tokenTimeStamp) = unserialize(@file_get_contents($tokenFileName));
}
if((time()-$tokenTimeOut) > $tokenTimeStamp) { 	  echo "токена нет ($tokenTimeStamp==0) или токен протух\n";
	$tokenTimeStamp = 0;
	$context = stream_context_create($opts);
	$token = get_headers($loginUrl,true,$context)['Set-Cookie'];
	//echo "token=$token;\n\n";
	if(substr($token,0,3)==='AD=') $tokenTimeStamp = time();
	else {
		$token = '';
		$on403='wait';
	}
	$_SESSION['TransasToken'] = array($token,$tokenTimeStamp); 	// сохраним токен
	$umask = umask(0); 	// сменим на 0777 и запомним текущую
	file_put_contents($tokenFileName, serialize(array($token,$tokenTimeStamp))); 	// запишем файл с токеном
	@chmod($bannedSourcesFileName,0777); 	// чтобы при запуске от другого юзера была возаможность 
	umask($umask); 	// 	

	if($getTorNewNode AND @$opts['http']['proxy']) { 	// можно менять выходную ноду Tor.
		echo"getting new Tor exit node\n";
		$res=exec($getTorNewNode);	// сменим выходную ноду Tor
		//echo "Обращение к tor за сменой ноды окончилочь с $res\n";
	}
}
//echo "token=$token;\n\n";
// Вообще-то, при отсутствии токена бесполезно спрашивать файл
$url = '';
if($token) {
	$opts['http']['header'].="Cookie: $token\r\n";
	$url = 'https://www.fleetviewonline.com/cdmo/Services/Charts/ChartWms.ashx?service=WMS&request=GetMap&version=1.3.0&layers=trs_inset%2Ctrs_coastline%2Ctrs_drying_area%2Ctrs_depth_contour%2Ctrs_lighthouse%2Ctrs_buoy%2Ctrs_racon%2Ctrs_sounding%2Ctrs_drying_height%2Ctrs_isolated_danger%2Ctrs_line%2Ctrs_recommended_route%2Ctrs_text%2Ctrs_other_feature%2Ctrs_ground%2Ctrs_contour_line%2Ctrs_height%2Ctrs_coastline_object&styles=&format=image%2Fpng&transparent=false&maxZoom=18&crs=EPSG%3A3857';
	$leftTop = tileNum2ord($z,$x,$y);	// fcommon.php
	$rightBottom = tileNum2ord($z,$x+1,$y+1);
	$url .= '&width=256&height=256';
	$url .= "&bbox={$leftTop['x']},{$rightBottom['y']},{$rightBottom['x']},{$leftTop['y']}";	//  Bounding box corners (lower left, upper right) https://mapserver.org/es/ogc/wms_server.html?highlight=BBOX
}
return array($url,$opts);
}
//echo getURL(10,558,326,['tileCacheDir'=>'tiles','mapSourcesName'=>'Transas'])[0]."\n";
EOFU;
?>
