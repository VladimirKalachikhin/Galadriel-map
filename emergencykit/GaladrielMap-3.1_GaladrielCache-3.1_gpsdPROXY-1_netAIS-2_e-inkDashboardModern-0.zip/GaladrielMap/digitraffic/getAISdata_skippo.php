<?php ob_start();
/* a:3:{s:8:"latitude";d:60.1688;s:9:"longitude";d:24.939;s:6:"radius";i:5;}
Оно общается через std io только

Запросить конкретное судно:
Это, видимо, лайба, зарегистрированная на skippo:
https://boat-data-service.skippo.io/data/2412/dUkwzDCZ20baCDok6pJdWhuSF712
Там есть сведения о владельце?

Это нормальная лайба, с mmsi:
https://boat-data-service.skippo.io/data/2412/265577470

Что такое /2412/ ?
*/
// ссылка на источник информации о положении целей AIS
$urlAISlocations = 'https://boat-data-service.skippo.io/data/mapAll';	// AIS locations data url

require "params.php";
require "fconnect.php";
require "fGeodesy.php";
require "fSkippo.php";

//$poi = 'a:3:{s:8:"latitude";d:60.1688;s:9:"longitude";d:24.939;s:6:"radius";i:5;}';	// Гельсингфорс
//$poi = 'a:3:{s:8:"latitude";d:59.5435;s:9:"longitude";d:18.586;s:6:"radius";i:5;}';	// LJUSTERO<>OSTANA :-)
$poi = '';
do{
	$poi .= trim(fgets(STDIN));
}while(!feof(STDIN));
$poi = unserialize($poi);
//print_r($poi);

$url = $urlAISlocations;
//echo "getDataTimeout=$getDataTimeout;\n";
$ch = curl_init();
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Cache-Control: no-cache',
'Connection: keep-alive',
//'User-Agent: '.randomUserAgent(),	// fCommon.php
//'Referer: https://www.skippo.se/',
'Authorization:	Basic '.$AISdataSources['skippo']['token']	// Как долго проживёт токен?
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, round($getDataTimeout/3));
curl_setopt($ch, CURLOPT_TIMEOUT, $getDataTimeout);
//curl_setopt($ch, CURLOPT_NOPROXY,'');
if($proxyURL and $AISdataSources['skippo']['proxy']) curl_setopt($ch,CURLOPT_PROXY,$proxyURL);
curl_setopt($ch, CURLOPT_URL,$url);
$AISlocations = curl_exec($ch);
$info = curl_getinfo($ch);
//print_r($info);
if (curl_errno($ch) || substr($info['http_code'],0,1) !== '2') {
	ob_end_clean();
	echo "Failed to get coordinates of AIS targets from $url\n";
	if($proxyURL and $AISdataSources['skippo']['proxy']) $proxyProc('getAISdata_skippo',5);
	exit(1);
};
$AISlocations = json_decode($AISlocations,true);
// Это массив id : data
//end($AISlocations);	//  указатель на последний элемент
//$id = key($AISlocations);	// ключ по текущему указателю
//$n = count($AISlocations);
//echo "Получено $n целей AIS, последняя: $id\n";
//print_r($AISlocations[$id]);

// Переведём полученное в формат digitraffic
$digiAISlocations = array();
//$tMIN=99999999999; $tMAX=0;
foreach($AISlocations as $key=>$target){
	//if($target['s']>$tMAX) $tMAX = $target['s'];
	//if($target['s']<$tMIN) $tMIN = $target['s'];
	//if($target['id']=='230992660'){echo "Судно: ";print_r($target);echo "\n";};
	//if($target['t']==14){echo "Судно: ";print_r($target);echo "\n";};
	// Отфильтруем что не попадает в указанную точку
	if($poi and (equirectangularDistance($poi,$target)>($poi['radius']*1000))) {
		unset($AISlocations[$key]);
		continue;
	};
	//if($target['id']=='230992510'){echo "Kupeli ";print_r($target);echo "\n";};
	//if($target['id']=='265585310'){echo "JUPITER ";print_r($target);echo "\n";};
	// если там лайба сообщества skippo, то это строка вида 85ebIzVCp5PD2oklXV8XbJq0l8i1 (хеш?)
	$digiAISlocations[$key] = array(	// будем делать вид, что у нас корректный GeoJSON, хотя функция updInstrumentsData всё равно потом переделывает его в (почти) плоский список
		'mmsi' => $target['id'],
		'type' => 'Feature',
		'geometry' => array(
			'type' => 'Point',
			'coordinates' => Array($target['lon'],$target['lat'])	// долгота, широта, высота
		),	
		'properties' => array(
			'mmsi' => $target['id'],
			'cog' => $target['c'],
			'timestampExternal' => intval($target['ts']/1000),
			'status' => $target['a'],	// anchor?
			'shipType' => shipType($target['t']),
		)
	);
};

//$n = count($digiAISlocations);
//echo "Осталось $n целей AIS"; //echo ", sMIN=$tMIN; sMAX=$tMAX;\n";
//print_r($AISlocations);
//echo "\n";
$digiAISlocations = array(
	"type" => "FeatureCollection",
	"features" => $digiAISlocations
);

ob_end_clean();
echo serialize($digiAISlocations);
exit(0);
?>
