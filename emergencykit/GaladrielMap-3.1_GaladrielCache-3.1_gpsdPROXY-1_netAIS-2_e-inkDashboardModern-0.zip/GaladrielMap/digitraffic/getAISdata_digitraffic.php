<?php ob_start();
/* a:3:{s:8:"latitude";d:60.1688;s:9:"longitude";d:24.939;s:6:"radius";i:5;}
Оно общается через std io только
*/
// ссылка на источник информации о положении целей AIS
$urlAISlocations = 'https://meri.digitraffic.fi/api/ais/v1/locations';	// AIS locations data url

require_once("params.php");
require_once("fconnect.php");

//$poi = 'a:3:{s:8:"latitude";d:60.1688;s:9:"longitude";d:24.939;s:6:"radius";i:5;}';
$poi = '';
do{
	$poi .= trim(fgets(STDIN));
}while(!feof(STDIN));
$poi = unserialize($poi);
//print_r($poi);

$url = $urlAISlocations;
if($poi) $url .= "?latitude={$poi['latitude']}&longitude={$poi['longitude']}&radius={$poi['radius']}";
//echo "getDataTimeout=$getDataTimeout;\n";
$ch = curl_init();
// Оно всегда отдаёт в gzip, и не хочет отдавать, если просить не в gzip.
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Accept-Encoding: gzip, deflate, br',
'Cache-Control: no-cache',
'Connection: keep-alive'
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, round($getDataTimeout));
curl_setopt($ch, CURLOPT_TIMEOUT, $getDataTimeout*3);
//curl_setopt($ch, CURLOPT_NOPROXY,'');
if($proxyURL and $AISdataSources['digitraffic']['proxy']) curl_setopt($ch,CURLOPT_PROXY,$proxyURL);
curl_setopt($ch, CURLOPT_URL,$url);
$AISlocations = curl_exec($ch);
$info = curl_getinfo($ch);
//print_r($info);
ob_end_clean();
if (curl_errno($ch) or substr($info['http_code'],0,1) !== '2') {
	echo "Failed to get coordinates of AIS targets from $url with ".curl_error($ch)."\n";
	if($proxyURL and $AISdataSources['digitraffic']['proxy']) $proxyProc('getAISdata_digitraffic',5);
	exit(1);
};
$AISlocations = json_decode(gzdecode($AISlocations),true);
//print_r($AISlocations); exit;
array_walk($AISlocations['features'], function (&$parm, $key){
	if(isset($parm['properties']['timestampExternal'])){
		$parm['properties']['timestampExternal'] = intval($parm['properties']['timestampExternal']/1000);
	};
});
//echo "Has ".count($AISlocations['features'])." AIS trgets from digitraffic\n";
//print_r($AISlocations);
echo serialize($AISlocations);
exit(0);
?>
