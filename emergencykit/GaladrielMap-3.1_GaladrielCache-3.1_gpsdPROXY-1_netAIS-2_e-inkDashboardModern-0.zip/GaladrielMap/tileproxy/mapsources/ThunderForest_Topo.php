<?php
/*
*/
$humanName = array('ru'=>'Топокарта ThunderForest','en'=>'ThunderForest topo map');
//$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, один год
$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, один год
// $ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$ContentType = 'image/png'; 	// if content type differ then file extension
$minZoom = 0;
$maxZoom = 19;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,20337,10160,'d205b575');	// to source check; tile number and CRC32b hash

$getURL = function ($z,$x,$y) {
/* 
*/
$userAgent = randomUserAgent();
$RequestHead='Referer: https://www.thunderforest.com';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		//'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
/*
b4a4b0be65f742cebec15881dfd86675	// 3
6170aad10dfd42a38d4d8c709a536f38	// используется на огромном количестве сайтов
e426aa11f4764b36b140f271cd2c19e0
87bdf2c81dfd4f5d860a05f723194743
3e8acaf16b3f4e36a80a1732e9e82c40
e6b144cfc47a48fd928dad578eb026a6
a5dd6a2f1c934394bce6b0fb077203eb
31c72629130e4e72a501d27da108a5ec
3665f3b7157a42acbe16b19250fbef88
0f36e188a85944d2ae0061fbdd8c1ae3
ba3556f7645b4ee296a9640f5abc12ce
d50c6e02b42c48739c4c15211438a8a3
ef996ca032914859a67a54a2b12ced14
1cb29df7e8ff4f36a2c857f9b95f32ca
21e672fc26574b979698192597bfe670	// мой
7c352c8ff1244dd8b732e349e0b0fe8d	// с thunderforest.com
*/

$server = array('a','b','c');
$url = 'https://'.$server[array_rand($server)].'.tile.thunderforest.com/landscape';
$url .= "/$z/$x/$y.png";
$url .= '?apikey=6170aad10dfd42a38d4d8c709a536f38';

return array($url,$opts);
};
?>
