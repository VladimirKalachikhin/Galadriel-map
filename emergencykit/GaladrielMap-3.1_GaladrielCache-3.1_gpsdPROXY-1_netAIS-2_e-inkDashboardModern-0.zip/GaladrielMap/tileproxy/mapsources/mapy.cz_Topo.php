<?php
/* Оно протухло, но разбираться лень 
Работает.
*/
$humanName = array('ru'=>'Топокарта mapy.cz','en'=>'mapy.cz topo map');
//$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, один год
$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, пол-года
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$ContentType = 'image/png'; 	// if content type differ then file extension
$minZoom = 0;
$maxZoom = 19;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
//'3df36e26' 	// чистый голубой квадрат
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,19906,9852,'f521f22d');	// to source check; tile number and CRC32b hash

$getURL = function ($z,$x,$y) {
$url = 'https://mapserver.mapy.cz/turist-en/';
$url .= "$z-$x-$y";
$userAgent = randomUserAgent();
$RequestHead='Referer: https://mapserver.mapy.cz';
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
return array($url,$opts);
};
?>
