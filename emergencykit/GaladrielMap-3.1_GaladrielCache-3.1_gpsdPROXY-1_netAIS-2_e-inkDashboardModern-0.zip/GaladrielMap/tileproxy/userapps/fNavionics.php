<?php
/**/
function GetNavToken($opts) {
/* Запрашивает новый токен с navionics.com. Для запроса токена используется текущее время.
Токен подходит для карт с navionics.com
Возвращает массив, 
первый элемнт которого - токен или пустая строка, если что-то пошло не так
второй - unixtimestamp получения токена
*/
global $globalProxy;
// http://www.sasgis.org/wikisasiya/doku.php/%D0%BE%D0%BF%D0%B8%D1%81%D0%B0%D0%BD%D0%B8%D0%B5_%D0%BF%D0%B0%D1%81%D0%BA%D0%B0%D0%BB%D1%8C_%D1%81%D0%BA%D1%80%D0%B8%D0%BF%D1%82%D0%BE%D0%B2
// оригинальный запрос токена:
// https://tile1.navionics.com/tile/get_key/Navionics_webapi_03480/activecaptain.garmin.com?_=1751406150407 	
//$VTimeStamp = time();    
$VTimeStamp = round(microtime(true)*100); 
//$VRequestUrl = 'http://backend.navionics.com/tile/get_key/Navionics_internalpurpose_00001/webapp.navionics.com?_=' . $VTimeStamp;
$VRequestUrl = 'https://tile'.(rand(1,5)).'.navionics.com/tile/get_key/Navionics_webapi_03480/activecaptain.garmin.com?_=' . $VTimeStamp;
//$VRequestUrl = 'https://tile'.(rand(1,5)).'.navionics.com/tile/get_key/undefined/maps.garmin.com';
//$VRequestUrl = 'https://tile1.navionics.com/tile/get_key/undefined/maps.garmin.com';
//$VRequestUrl = 'https://tile'.(rand(1,5)).'.navionics.com/tile/get_key/Navionics_webapi_04041/maps.garmin.com';
$context = stream_context_create($opts); 	// 
try {
	//echo "[GetNavToken] VRequestUrl=$VRequestUrl;\n"; echo "context:"; print_r($opts); echo "\n";
	$VNavToken = file_get_contents($VRequestUrl, FALSE, $context); 	// 
	//echo "[GetNavToken] http_response_header:"; print_r($http_response_header); echo "/n";
	//error_log("fNavionics.php [GetNavToken]: {$http_response_header[0]} NavToken: $VNavToken");
	if((strpos($http_response_header[0],'403') !== FALSE) or (strpos($http_response_header[0],'204') !== FALSE)) { 	// Forbidden or No Content
		$VNavToken = '';
	};
	//$VNavToken = 'eyJrZXkiOiJOYXZpb25pY3Nfd2ViYXBpXzA0MDQxIiwia2V5RG9tYWluIjoibWFwcy5nYXJtaW4uY29tIiwicmVmZXJlciI6Im1hcHMuZ2FybWluLmNvbSIsInJhbmRvbSI6MTcyMzQ2NDUxNzExMH0';
	if(!$VNavToken) { 	// не хочет отдавать, что делать?
		$VNavToken = ''; $VTimeStamp = 0;
		throw new Exception('[GetNavToken] No NavToken getting from server');
	};
	echo "[GetNavToken]: Received new token\n";
	$VTimeStamp /= 100;	// чтобы обратно в секундах
}
catch (Exception $e) {
	$VNavToken = ''; $VTimeStamp = 0;
	error_log('fNavionics.php [GetNavToken] NavToken fetch error: '.$e->getMessage());
}
//echo "<br>fNavionics VNavToken=$VNavToken;\n";
return array($VNavToken,$VTimeStamp);
}; // end function GetNavToken


function GetNavToken_Garmin($opts) {
/* Запрашивает новый токен с garmin.com. Дополнительной информации не требуется.
Токен подходит для карт с garmin.com
Возвращает массив, 
первый элемнт которого - токен или пустая строка, если что-то пошло не так
второй - unixtimestamp получения токена
*/
global $globalProxy;
//$VTimeStamp = time();    
$VRequestUrl = 'https://maps.garmin.com/marine/api/getNavionicsTokens';	//
$context = stream_context_create($opts); 	// 
try {
	//echo "[GetNavToken] VRequestUrl=$VRequestUrl;\n";
	$VNavToken = file_get_contents($VRequestUrl, FALSE, $context); 	// 
	//echo "[GetNavToken] http_response_header:"; print_r($http_response_header); echo "/n";
	//$VNavToken = '{"access_token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJjNDcyNmIxMC0yNjM3LTQ4ZjQtODY3NC1lZTk5NmI5NjE0MGUiLCJhdWQiOiJtYXBzLmdhcm1pbi5jb20iLCJpc3MiOiJnYXJtaW4uY29tIiwiZXhwIjoxNzUxNzYyNjg3LCJpYXQiOjE3NTE3NTU0ODd9.YBdyCPxnCSU9KVyqB6TT98ItrIodYiYokICGs9Ljr1tU6NC4ggD3_ogbuxDe4jWmj1SKZIgMm4SV4bjDTy0R_1MVsTk7JgLYhsXVZaufyEV7hnGd2gKwY9JKU7fs2rwEC_mzsWp8RFtzr1bZI6KUZMCwaeHJzIBYX7kMO25_i2AiHlJ_ZuVsit24TFt05wfhI4YItPZgbTBQomJ8Y-AtxtxLcAAtMlC2tBu_bnW44sc-qH4xCVg_TPP_Zg-DGuTFKG-ejqkdk-8TCg99JYbnctkUhGsE2C2vc5-XFHQMy5E7vJ4qeMRoz9px4322gojESjVbwfiWF1g_hhJDoSNBbw","configuration_token":"eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJycG4iOiJpbnRlcm5hbF9zZXJ2aWNlIiwiYXByIjoiMDEwLUQyMTEyLTEwIn0.Ua7QtpbvTn16y9WDFnzUSiTCzjQbltqcBFAkiFv1PEY"}';
	if((strpos($http_response_header[0],'403') !== FALSE) or (strpos($http_response_header[0],'204') !== FALSE)) { 	// Forbidden or No Content
		$VNavToken = '';
	};
	if(!$VNavToken) { 	// не хочет отдавать, что делать?
		$VNavToken = ''; $VTimeStamp = 0;
		throw new Exception('[GetNavToken] No NavToken getting from server');
	};
	echo "[GetNavToken]: Received new token\n";
	//$VNavToken = json_decode($VNavToken,true);	// не будем пока, хотя оно json
}
catch (Exception $e) {
	$VNavToken = ''; $VTimeStamp = 0;
	error_log('fNavionics.php [GetNavToken] NavToken fetch error: '.$e->getMessage());
}
//echo "[fNavionics] VNavToken=$VNavToken;     \n";
return array($VNavToken,$VTimeStamp);
}; // end function GetNavToken

?>
