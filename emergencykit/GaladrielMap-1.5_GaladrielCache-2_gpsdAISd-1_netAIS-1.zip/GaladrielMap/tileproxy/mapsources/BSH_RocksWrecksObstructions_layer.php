<?php
/*
*/
require('BSH_common');
$getURLparams = array(
'map'=>'NAUTHIS_RocksWrecksObstructions',
'layers'=>'2,12,22,32,42,9,19,29,39,49,59',
'bgcolor'=>'0xFFFFFF' 
);

?>
