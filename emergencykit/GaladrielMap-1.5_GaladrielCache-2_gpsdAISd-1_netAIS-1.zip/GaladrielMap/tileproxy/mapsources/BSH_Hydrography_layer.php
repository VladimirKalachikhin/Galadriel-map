<?php
/*
*/
require('BSH_common');
$getURLparams = array(
'map'=>'NAUTHIS_Hydrography',
'layers'=>'29,30,65,66,101,102,137,138,173,174,209,210',
'bgcolor'=>'0x777777' 
);

?>
