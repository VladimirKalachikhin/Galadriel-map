<?php
$title = 'Управление netAIS';
$myGroupNameTXT = 'Моя группа';

$serverTXT = 'Своя группа netAIS';
$serverOffTXT = ' не запущена';
$serverOnTXT = "работает.";
$torErrTXT = ' СБОЙ: требуется служба TOR, но эта служба не работает.';
$yggdrasilErrTXT = 'СБОЙ: требуется служба Yggdrasil, но эта служба не работает.';
$serverErrTXT = ' СБОЙ - неизвестная причина. Права?';

$serverPlaceholderTXT = 'Нужно! Сетевой адрес';
$serverNamePlaceholderTXT = 'Понятное наименование';
$serverDescrPlaceholderTXT = 'Краткое описание';

$vehicleDestinationPlaceholderTXT = 'Куда';
$vehicleETAplaceholderTXT = 'Время прибытия';

$AISstatusTXT = array(
0=>'Двигаюсь под мотором',
1=>'На якоре',
2=>'Без экипажа',
3=>'Ограничен в манёвре',
4=>'Ограничен осадкой',
5=>'Ошвартован',
6=>'На мели',
7=>'Занят ловлей рыбы',
8=>'Двигаюсь под парусом',
11=>'Тяну буксир',
12=>'Толкаю состав или буксирую под бортом',
14=>'Нуждаюсь в помощи',
15=>'неопределённое'
);
$AISstatus14criminalTXT = 'На нас совершено криминальное нападение!';
$AISstatus14fireTXT = 'На борту пожар!';
$AISstatus14medicalTXT = 'Нуждаемся в срочной медицинской помощи!';
$AISstatus14wreckTXT = 'Опасность затопления судна!';
$AISstatus14mobTXT = 'Человек за бортом!';
$vehicleDescrPlaceholderTXT = 'Описание состояния';
?>
