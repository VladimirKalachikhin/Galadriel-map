<?php ob_start();
// ссылка на источник сведений о целях AIS
$urlAISvessels = 'https://boat-data-service.skippo.io/data/2412/';	// AIS targets metadata url

require_once("params.php");
require_once("fconnect.php");

//$mmsiS = array('983542156','538008208','273262130','230081740');	// массив mmsi
//$mmsiS = array('273437230','273397150','511101899','230081740');	// массив mmsi
//$mmsiS = array('jihnW0Ln6uPskHwQ7A5zSRty8m32');	// массив mmsi
//$mmsiS = array('ViCJ6qtvk1XlLn8UNNt6vHvnaa13');	// массив mmsi
//$mmsiS = array('265004000');	// массив mmsi

$digiAISlocations = array(); 	// собираемые метаданные
$mmsiS = '';	// массив mmsi
do{
	$mmsiS .= trim(fgets(STDIN));
}while(!feof(STDIN));
$mmsiS = unserialize($mmsiS);
//echo "noMetaData=";print_r($mmsiS);
if(!$mmsiS) return;

$ch = curl_init();
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Cache-Control: no-cache',
'Connection: keep-alive',
//'User-Agent: '.randomUserAgent(),	// fCommon.php
//'Referer: https://www.skippo.se/',
'Authorization:	Basic '.$AISdataSources['skippo']['token']	// Как долго проживёт токен?
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, round($getDataTimeout));
curl_setopt($ch, CURLOPT_TIMEOUT, $getDataTimeout*10);
//curl_setopt($ch, CURLOPT_NOPROXY,'');
if($proxyURL and $AISdataSources['skippo']['proxy']) curl_setopt($ch,CURLOPT_PROXY,$proxyURL);
$toGET = count($mmsiS); $badCount = 0;
// Переведём полученное в формат digitraffic
$digiAISlocations = array();
foreach($mmsiS as $mmsi){
	curl_setopt($ch, CURLOPT_URL,"$urlAISvessels/$mmsi");
	$AISlocation = curl_exec($ch);
	//print_r($info);
	$info = curl_getinfo($ch);
	if(curl_errno($ch) or (($info['http_code'] != '200')  and ($info['http_code'] != '404'))){
		//echo "Failed to get speed & location for mmsi $mmsi\n";
		$badCount++;
		if($proxyURL and $AISdataSources['skippo']['proxy']) $proxyProc('getAISdata',5);
		continue;
	};
	$AISlocation = json_decode($AISlocation,true);
	$digiAISlocations[$mmsi] = array(	// будем делать вид, что у нас корректный GeoJSON, хотя функция updInstrumentsData всё равно потом переделывает его в (почти) плоский список
		'mmsi' => $AISlocation['boatId'],
		'type' => 'Feature',
		'geometry' => array(
			'type' => 'Point',
			'coordinates' => Array($AISlocation['location']['lon'],$AISlocation['location']['lat'])	// долгота, широта, высота
		),	
		'properties' => array(
			'mmsi' => $AISlocation['boatId'],
			'sog' => $AISlocation['location']['speed'],
			'timestampExternal' => intval($AISlocation['location']['timestamp']/1000),
		)
	);
};
curl_close($ch);
$digiAISlocations = array(
	"type" => "FeatureCollection",
	"features" => $digiAISlocations
);
ob_end_clean();
//echo json_encode($digiAISlocations);
//print_r($digiAISlocations);
if($toGET == $badCount) {
	echo "getAISspeed_skippo: Failed to get speed & location from skippo for all mmsi in this point\n";
	exit(1);
}
else echo serialize($digiAISlocations);
exit(0);
?>
