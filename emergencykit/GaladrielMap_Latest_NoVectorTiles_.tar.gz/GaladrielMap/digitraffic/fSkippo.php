<?php
/**/
function shipType($skippoType){
switch((int)$skippoType){
case 0:
	$AIStype = 37;	// Pleasure Craft
	break;
case 1:
	$AIStype = 36;	// Sailing Vessel
	break;
case 2:
	$AIStype = 60;	// Passenger
	break;
case 3:
	$AIStype = 51;	// SAR
	break;
case 4:
	$AIStype = 55;	// Law Enforce
	break;
case 5:
	$AIStype = 35;	// Military
	break;
case 6:
	$AIStype = 34;	// Dive Vessel водолазное судно
	break;
case 7:
	$AIStype = 40;	// High-Speed Craft
	break;
case 8:
	$AIStype = 30;	// Fishing
	break;
case 9:
	$AIStype = 80;	// Tanker
	break;
case 10:
	$AIStype = 70;	// Cargo
	break;
case 11:
	$AIStype = 31;	// Tug буксир
	break;
case 12:
	$AIStype = 50;	// Pilot
	break;
case 13:
	$AIStype = 54;	// Anti-Pollution
	break;
case 14:
	$AIStype = 20;	// Wing In Grnd	гидросамолёт, marinetraffic почему-то считает гидросамолёты экранопланами
	break;
case 15:
	$AIStype = 53;	// Port Tender 59	Special Craft Saneringsskip
	break;
case 16:
	$AIStype = 0;	// NOT AVAILABLE OR NO SHIP
	break;
case 17:
	$AIStype = 56;	// Local Vessel	Skippo Liten båt	маленькая лодка
	break;
case 18:
	$AIStype = 57;	// Local Vessel	Skippo Daycruiser
	break;
case 19:
	$AIStype = 37;	// Skippo Motorbåt med kabin
	break;
case 20:
	$AIStype = 36;	// Skippo Segelbåt med kabin
	break;
default:
	$AIStype = 0;
};
return $AIStype;
}; // end function shipType

?>
