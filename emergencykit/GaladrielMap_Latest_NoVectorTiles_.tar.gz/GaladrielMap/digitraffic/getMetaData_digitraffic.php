<?php ob_start();
// ссылка на источник сведений о целях AIS
$urlAISvessels = 'https://meri.digitraffic.fi/api/ais/v1/vessels';	// AIS targets metadata url

require_once("params.php");
require_once("fconnect.php");

//$noMetaData = array('983542156','538008208','273262130','230081740');	// массив mmsi
//$noMetaData = array('273437230','273397150','511101899','230081740','266026000');	// массив mmsi

$metaDataS = array(); 	// собираемые метаданные
$noMetaData = '';	// массив mmsi
do{
	$noMetaData .= trim(fgets(STDIN));
}while(!feof(STDIN));
$noMetaData = unserialize($noMetaData);
//echo "noMetaData=";print_r($noMetaData);
if(!$noMetaData) return;

$ch = curl_init();
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Accept-Encoding: gzip, deflate, br',
'Cache-Control: no-cache',
'Connection: keep-alive'
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, round($getDataTimeout));
curl_setopt($ch, CURLOPT_TIMEOUT, $getDataTimeout*3);
//curl_setopt($ch, CURLOPT_NOPROXY,'');
if($proxyURL and $AISdataSources['digitraffic']['proxy']) curl_setopt($ch,CURLOPT_PROXY,$proxyURL);
$toGET = count($noMetaData); $badCount = 0; $errStr = '';
foreach($noMetaData as $mmsi){
	// Для всех целей оно в gzip, но для одной -- не сжато
	curl_setopt($ch, CURLOPT_URL,"$urlAISvessels/$mmsi");
	$metadata = curl_exec($ch);
	//print_r($info);
	$info = curl_getinfo($ch);
	if(curl_errno($ch) or (($info['http_code'] != '200')  and ($info['http_code'] != '404'))){
		//echo "Failed to get metadata for mmsi $mmsi\n";
		$errStr = 'Err # '.curl_errno($ch).' Err:'.curl_error($ch).'; http_code='.$info['http_code'];
		$badCount++;
		if($proxyURL and $AISdataSources['digitraffic']['proxy']) $proxyProc('getAISdata',5);
		continue;
	};
	if(!$metadata) continue;	// Данных может и не быть, если спросили mmsi, которого нет у digitraffic
	$metadata = json_decode($metadata,true);
	array_walk($metadata, function (&$parm, $key){
		if($key=='timestamp'){
			$parm = intval($parm/1000);
		};
	});
	$metaDataS[] = $metadata;
};
curl_close($ch);
//ob_end_clean();

//print_r($metaDataS);
if($toGET == $badCount) {
	echo "getMetaData: Failed to get metadata from digitraffic for all mmsi, last error: $errStr\n";
	exit(1);
}
else echo serialize($metaDataS);
exit(0);
?>
