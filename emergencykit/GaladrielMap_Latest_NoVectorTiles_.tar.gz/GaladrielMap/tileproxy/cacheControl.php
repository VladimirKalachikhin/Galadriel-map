<?php
/* web - интерфейс для получения информации об имеющихся картах, управления загрузчикаом
и ещё для чего-нибудь.
Типа, API. Возвращает json.

The web interface for obtaining information about available maps, loader management, etc.
Return json

curl -v http://stagerserver.local/tileproxy/cacheControl.php?getMapList
curl -v http://stagerserver.local/tileproxy/cacheControl.php?getMapInfo=C-MAP

curl -v http://stagerserver.local/tileproxy/cacheControl.php?loaderStatus
curl -v http://stagerserver.local/tileproxy/cacheControl.php?loaderStatus\&restartLoader

*/
$usage='Usage:
	Получить список карт
cacheControl.php?getMapList		get maps list
return: JSON

	Получить сведения о карте из её файла описания:
	Get map info:
cacheControl.php?getMapInfo=map_source_file_name	
return: JSON

	Получить описание карты:
	Get map description:
cacheControl.php?getMapDescription=map_source_file_name	
return: JSON

	Поставить задание на скачивание:
	Create & run tile loading job:
cacheControl.php?loaderJob=map_source_file_name.zoom&xys=csv_of_XY[&infinitely] 
return: JSON

	Получить состояние заданий на скачивание:
	Get loader status:
cacheControl.php?loaderStatus[&stopLoader]|[&restartLoader][&infinitely]] 	
return: JSON
';

ob_start(); 	// попробуем перехватить любой вывод скрипта
ini_set('error_reporting', E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);
chdir(__DIR__); // задаем директорию выполнение скрипта

require('fIRun.php'); 	// 
require 'fCommon.php';	// функции, используемые более чем в одном крипте
require 'fTilesStorage.php';	// стандартные функции получения тайла из локального источника

require('params.php'); 	// пути и параметры 
if(!$phpCLIexec) $phpCLIexec = trim(explode(' ',trim(shell_exec("ps -p ".(getmypid())." -o command=")))[0]);	// из PID системной командой получаем командную строку и берём первый отделённый пробелом элемент. Считаем, что он - команда запуска php. Должно работать и в busybox.

//$_REQUEST['getMapList'] = true;
//$_REQUEST['getMapInfo'] = 'NAIS';

$result = null;
if(array_key_exists('getMapList',$_REQUEST)){	
// Вернуть список имеющихся карт
	// Получаем список имён карт
	$mapsInfo = null;
	foreach(glob("$mapSourcesDir/*.php") as $name) {
		//echo "$name<br>\n";
		/*/ Это ооооочень медленно. Может быть, token_get_all()?
		$res = exec($phpCLIexec.' -l "'.$name.'"',$output,$ret);
		if($ret){
			error_log("$name $res, skip");
			continue;
		};
		/*/
		$mapName=explode('.php',end(explode('/',$name)))[0]; 	// basename не работает с неанглийскими буквами!!!! Да нормально всё работает...
		$humanName = array();
		require('mapsourcesVariablesList.php');	//
		include($name);
		/*/ Это ещё боле медленно. Кроме того, eval != include? При include нет никаких warnings, а при eval - есть.
		$src = file_get_contents($name);
		$src = substr(substr($src,strpos($src,'<?php')+5),0,strrpos($src,'?>'));	// заведомо считаем, что оно там есть
		try {
			eval($src);
		}
		catch (ParseError $error) {
			//error_log("$name has exception: {$error->getMessage()}, skip map.");
			echo "$name has exception: {$error->getMessage()}, skip map.<br>\n";
			continue;
		};
		/*/
		if($humanName){	// из описания источника
			if(!$humanName['en']) $humanName['en'] = $mapName;
		}
		else $humanName['en'] = $mapName;
		$mapsInfo[$mapName] = $humanName;
	};
	$result = $mapsInfo;
	//echo "список имён карт:"; print_r($result); echo "\n";
}
elseif($mapName=filter_var($_REQUEST['getMapInfo'],FILTER_SANITIZE_URL)){	
// Вернуть сведения о конкретной карте
	require('mapsourcesVariablesList.php');	// потому что в файле источника они могут быть не все, и для новой карты останутся старые
	require("$mapSourcesDir/$mapName.php");	// при отсутствии оно обломится, и ничего возвращено не будет
	$mapInfo = array(
		'humanName'=>$humanName,
		'ttl'=>$ttl,	// например, клиент может повторно запросить карту через короткий $ttl
		'mapTiles'=>$mapTiles
	);
	if($clientData) $mapInfo['clientData']=$clientData;
	if($requestOptions) $mapInfo['requestOptions']=$requestOptions;
	if(isset($minZoom)) $mapInfo['minZoom']=$minZoom;
	if(isset($maxZoom)) $mapInfo['maxZoom']=$maxZoom;
	if($bounds) $mapInfo['bounds']=$bounds;
	if(is_string($mapTiles)) {
		if($ext) $mapInfo['ext']=$ext;
		if($ContentType) $mapInfo['ContentType']=$ContentType;
		if($content_encoding) $mapInfo['content_encoding']=$content_encoding;
		if($vectorTileStyleURL) $mapInfo['vectorTileStyleURL']=$vectorTileStyleURL;
		if($vectorTileFonsURL) $mapInfo['vectorTileFonsURL']=$vectorTileFonsURL;
		if($vectorTileSpritesURL) $mapInfo['vectorTileSpritesURL']=$vectorTileSpritesURL;
		if($EPSG) $mapInfo['epsg']=$EPSG;
	};
	$result = $mapInfo;
	//echo "сведения о $mapName:"; print_r($result); echo "\n";
}
elseif($mapName=filter_var($_REQUEST['getMapDescription'],FILTER_SANITIZE_URL)){	
// Вернуть сведения о конкретной карте
	$mapInfo = array();	// массив имя_карты => описание, массив
	require('mapsourcesVariablesList.php');	// потому что в файле источника они могут быть не все, и для новой карты останутся старые
	require("$mapSourcesDir/$mapName.php");	// при отсутствии оно обломится, и ничего возвращено не будет
	if(is_string($mapTiles)) $mapInfo[$mapName] = array();	// простая карта
	elseif(is_string($mapTiles[0])) $mapInfo[$mapName] = array();	// многослойная карта
	else {	// составная карта
		foreach($mapTiles as $map){
			$mapInfo[$map['mapName']] = array();
		};
	};
	foreach($mapInfo as $mapName => &$info){
		include('mapsourcesVariablesList.php');	// потому что в файле источника они могут быть не все, и для новой карты останутся старые
		$res = include("$mapSourcesDir/$mapName.php");
		if($res === false) continue;
		$info['humanName'] = $humanName;
		$info['mapDescription'] = $mapDescription;
		if($EPSG) $info['epsg']=$EPSG;
		if(isset($minZoom)) $info['minZoom']=$minZoom;
		if(isset($maxZoom)) $info['maxZoom']=$maxZoom;
		if($bounds) $info['bounds']=$bounds;
		$info['mapDescriptionFile'] = realpath("$mapSourcesDir/$mapName.php");
		$info['mapDataFile'] = realpath("$tileCacheDir/$mapName/");
		if($info['mapDataFile']===false) $info['mapDataFile'] = realpath("$tileCacheDir/$mapName.mbtiles");
		if($vectorTileStyleURL) $info['vectorTileStyleURL'] = $vectorTileStyleURL;
		if($getURL){
			$info['online'] = true;
			$uri = $getURL(0,0,0,null);
			if(is_array($uri))	list($uri,$opts) = $uri;
			if($opts['http']['proxy']) $info['proxy'] = $opts['http']['proxy'];
		};
	};
	unset($info);	// Reference to a $value of the last array element remain even after the foreach loop. It is recommended to destroy these using unset().
	$result = $mapInfo;
}
//elseif($jobName=filter_var($_REQUEST['loaderJob'],FILTER_SANITIZE_STRING)){	
elseif($jobName=$_REQUEST['loaderJob']){	
// Поставить задание на скачивание
	$XYs = $_REQUEST['xys'];
	//echo "XYs=$XYs; jobName=$jobName; <br>\n";
	//$jobName='OpenTopoMap.11';
	//$XYs="1189,569\n1190,569\n1191,569";
	if($jobName != 'restart') {
		$name_parts = pathinfo($jobName);
		//echo "name_parts:<pre>"; print_r($name_parts); echo "</pre>";
		if(!(is_numeric($name_parts['extension']) AND (intval($name_parts['extension']) <=20 AND intval($name_parts['extension']) >=0))) goto LOADERJOBEND; 	// расширение - не масштаб
		if(!is_file("$mapSourcesDir/".$name_parts['filename'].'.php')) goto LOADERJOBEND; 	// нет такого источника
		if(!$XYs) goto LOADERJOBEND; 	// нет собственно задания
		// Создадим задание
		$umask = umask(0); 	// сменим на 0777 и запомним текущую
		// нужно положить в каталог заданий для загрузчика, ибо аналогичное задание уже может выполняться, и если его дать планировщику, то оно исчезнет
		if(file_exists("$jobsInWorkDir/$jobName")){
			file_put_contents("$jobsInWorkDir/$jobName", "$x,$y\n",FILE_APPEND); 	// создадим/добавим файл задания для загрузчика
			@chmod("$jobsInWorkDir/$jobName",0666); 	// чтобы запуск от другого юзера
		};
		file_put_contents("$jobsDir/$jobName",$XYs,FILE_APPEND); 	// возможно, такое задание уже есть. Тогда, скорее всего, тайлы указанного масштаба не будут загружены, а будут загружены эти тайлы следующего масштаба. Не страшно.
		// Сохраним задание на всякий случай
		file_put_contents("$jobsDir/oldJobs/$jobName".'_'.gmdate("Y-m-d_Gis", time()),$XYs);
		//file_put_contents("$jobName",$XYs);
		@chmod("$jobsDir/$jobName",0666); 	// чтобы запуск от другого юзера
		umask($umask); 	// 	Вернём. Зачем? Но umask глобальна вообще для всех юзеров веб-сервера
	};

	// Запустим планировщик
	// Если эта штука вызывается для нескольких карт подряд, то просто при запуске планировщика
	// каждый его экземпляр видит, что запущены другие, и завершается. В результате не запускается ни один.
	// Поэтому будем запускать планировщик не чаще чем раз в секунд.
	$infinitely = '';
	if(array_key_exists('infinitely',$_REQUEST)) $infinitely = '--infinitely';
	$status = 0;
	//echo (time()-$_SESSION['loaderJobStartLoader'])." ";
	if((time()-$_SESSION['loaderJobStartLoader'])>3) {
		exec("$phpCLIexec loaderSched.php $infinitely > /dev/null &",$ret,$status); 	// если запускать сам файл, ему нужны права
		//exec("$phpCLIexec loaderSched.php $infinitely > /dev/null 2>&1 &",$ret,$status); 	// если запускать сам файл, ему нужны права
		//exec("$phpCLIexec loaderSched.php > log_$jobName.txt 2>&1 &",$ret,$status); 	// если запускать сам файл, ему нужны права
		if($status==0)$_SESSION['loaderJobStartLoader'] = time();	// при успешном запуске
	};
	$result = array("status"=>$status,"jobName"=>$jobName);
	LOADERJOBEND:
}
elseif(array_key_exists('loaderStatus',$_REQUEST)){	
// Получить состояние заданий на скачивание
	if(array_key_exists('restartLoader',$_REQUEST)) {
		$infinitely = '';
		if(array_key_exists('infinitely',$_REQUEST)) $infinitely = '--infinitely';
		exec("$phpCLIexec loaderSched.php $infinitely > /dev/null 2>&1 &",$ret,$status);
		//echo "exec ret="; print_r($ret); echo "status=$status;\n";
		sleep(1);
	};
	
	$stopLoader = false;
	if(array_key_exists('stopLoader',$_REQUEST)) $stopLoader = true;

	$jobsInfo = array();
	clearstatcache();
	foreach(preg_grep('~.[0-9]$~', scandir($jobsDir)) as $jobName) {	 	// возьмём только файлы с цифровым расшрением
		$jobSize = filesize("$jobsDir/$jobName");
		if(!$jobSize) continue;	// внезапно может оказаться файл нулевой длины
		$jobComleteSize =  @filesize("$jobsInWorkDir/$jobName"); 	// файла в этот момент может уже и не оказаться
		//echo "jobSize=$jobSize; jobComleteSize=$jobComleteSize; <br>\n";
		if($jobComleteSize==0) $jobComleteSize = $jobSize;
		$jobsInfo[$jobName] = round((1-$jobComleteSize/$jobSize)*100); 	// выполнено
		
		if($stopLoader) {	// просто удалим выполняющиеся файлы заданий
			unlink("$jobsInWorkDir/$jobName");
			unlink("$jobsDir/$jobName");
		};
	};
	//echo "jobsInfo:<pre>"; print_r($jobsInfo); echo "</pre>";
	// Определим, запущен ли планировщик
	if(IRun('loaderSched')) $result = array("loaderRun"=>true,"jobsInfo"=>$jobsInfo);
	else $result = array("loaderRun"=>false,"jobsInfo"=>$jobsInfo);
}
elseif(array_key_exists('collectMBTiles',$_REQUEST)){	
	exec("$phpCLIexec collectMBTiles.php > /dev/null 2>&1 &",$ret,$status);
	$result = array("collectMBTiles"=>$status);
}
else {
	$result = array("usage"=>$usage);
};

ob_clean(); 	// очистим, если что попало в буфер
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header('Content-Type: application/json;charset=utf-8;');

//echo json_encode($result,JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
echo json_encode($result,JSON_UNESCAPED_UNICODE);	// однострочный JSON передастся быстрее

$content_lenght = ob_get_length();
header("Content-Length: $content_lenght");
ob_end_flush(); 	// отправляем и прекращаем буферизацию
?>
