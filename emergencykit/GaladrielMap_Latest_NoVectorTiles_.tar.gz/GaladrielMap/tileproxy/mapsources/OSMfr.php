<?php
/* Вполне дурацкая карта: нет рельефа, нет ЛЭП, нет много чего ещё, левые цвета. Зато быстро.
 */
$humanName = array('ru'=>'карта-схема OpenStreetMap','en'=>'OpenStreetMap');
//$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим. 86400 - сутки
$ttl = 60*60*24*30*12*3; //cache timeout in seconds время, через которое тайл считается протухшим, 3 года, потому что эти суки стали радикально упрощать карты бывших хохляцких территорий
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 3;
$maxZoom = 18;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(14,9898,5151,'65f0640a');	// to source check; tile number and CRC32b hash

$getURLoptions['r'] = pathinfo(__FILE__, PATHINFO_FILENAME);	// $getURLoptions будет передан в $getURL


$getURL = function ($z,$x,$y) {
$srv = ['a','b','c'];
$url='https://tile-'.$srv[array_rand($srv)].'.openstreetmap.fr/hot/';
$url .= "$z/$x/$y".".png";

$userAgent = randomUserAgent();
//$userAgent = 'Mozilla/5.0 (X11; Linux x86_64; rv:147.0) Gecko/20100101 Firefox/147.0';
$referer = "Referer: https://www.openstreetmap.org/\r\n";
//$RequestHead="Connection: keep-alive\r\n";
//$accept = "Accept: image/avif,image/webp,image/png,image/svg+xml,image/*;q=0.8,*/*;q=0.5\r\n";

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n$referer$accept$RequestHead",
		//'proxy'=>'tcp://127.0.0.1:8118',
		//'timeout' => 60,
		//'request_fulluri'=>TRUE
	)
);
changeTORnode($getURLoptions['r']);
return array($url,$opts);
};
?>
