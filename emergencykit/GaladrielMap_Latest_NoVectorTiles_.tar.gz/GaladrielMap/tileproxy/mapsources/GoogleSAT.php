<?php
$humanName = array('ru'=>'Космоснимки Google','en'=>'Google satellite photos');
$ttl = 86400*365; // 1 year cache timeout in seconds время, через которое тайл считается протухшим
$ext = 'jpeg'; 	// tile image type/extension
$minZoom = 0;
$maxZoom = 20;

$getURL = function ($z,$x,$y) {
/* функция получения тайла позаимствована из OruxMaps */
$server = array(0,1,2,3);
$userAgent = randomUserAgent();
$RequestHead='Referer: http://google.com';

//$headersLang = 'iw'; // hebrew
$headersLang = 'ru'; // russian
//$headersLang = 'en'; // english
//$headersLang = ''; // local
$url = 'http://mt'.$server[array_rand($server)].".google.com/vt/lyrs=s@176103410&s=Galileo&scale=1&hl=$headersLang";
$url .= "&x=$x&y=$y&z=$z";

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n"
	)
);
return array($url,$opts);
};
?>
