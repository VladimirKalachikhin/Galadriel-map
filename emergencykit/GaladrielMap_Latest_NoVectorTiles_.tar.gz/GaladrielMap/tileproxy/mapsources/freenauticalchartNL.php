<?php
/* https://freenauticalchart.net/ 
https://freenauticalchart.net/download/
*/
$humanName = array('ru'=>'Голландия, морская бумажная карта','en'=>'Netherlands nautical paper chart');
$ttl = 60*60*24*30*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 7;
$maxZoom = 19;
$bounds = array('leftTop'=>array('lat'=>53.5884,'lng'=>3.1284),'rightBottom'=>array('lat'=>51.1966,'lng'=>6.6804));
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,16766,10874,'3b72d210');	// to source check; tile number and CRC32b hash

$getURL = function ($z,$x,$y) {
/**/
//$userAgent = randomUserAgent();
$RequestHead='Referer: https://freenauticalchart.net/';

$url = 'https://freenauticalchart.net/qmap-nl';
$url .= "/".$z."/".$x."/".$y.".png";
$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
changeTORnode('freenauticalchart');
return array($url,$opts);
};
?>
