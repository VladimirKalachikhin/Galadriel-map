<?php
/* Это NAIS, но напрямую? wms, а не через кеш gatekeeper.
Причём gatekeeper, видимо, умер, а теперь opencache.statkart.no/gatekeeper/

https://github.com/torarve/leaflet-kartverket
https://status.geonorge.no/cache.html
https://kartkatalog.geonorge.no/
https://norgeskart.no/#!?project=norgeskart&layers=1002&zoom=3&lat=7197864.00&lon=396722.00
https://cache.kartverket.no/
https://routeinfo.no/
https://norgeskart.no/geoportal/#!?zoom=5&project=geonorge&layers=1006&lat=6534573.25&lon=-149955.50&wms=https:%2F%2Fwms.geonorge.no%2Fskwms1%2Fwms.geonorge_dekningskart%3Fdatasett%3Dkv_stormflo,https:%2F%2Fopenwms.statkart.no%2Fskwms1%2Fwms.gp_dek_oversikt%3Fdatasett%3Dkv_stormflo&addLayers=gp_dek_oversikt_wms&type=dek&markerLat=6534573.25&markerLon=-149955.50000000003&panel=searchOptionsPanel

https://opencache.statkart.no/gatekeeper/gk/gk.open_gmaps?layers=sjokartraster&zoom=14&x=8771&y=4112


То же самое, но токен, где взять?:
но в другой разграфке tilematrixset=utm33n
https://norgeskart.no/#!?project=norgeskart&layers=1002&zoom=3&lat=7197864.00&lon=396722.00
Токен:
https://norgeskart.no/ws/gatekeeper.py?key=73e029c3632c49bb1586fc57a60fb701kv
теперь - где взять key?

gatekeeper{1-3}
https://gatekeeper2.geonorge.no/BaatGatekeeper/gk/gk.cache?REQUEST=GetMap&SERVICE=WMS&VERSION=1.1.1&FORMAT=image%2Fpng&STYLES=&TRANSPARENT=true&LAYERS=sjokartraster&GKT=1F2BDB48318B3B3D6FCBF5EA2EA627A78B55C99595ED0779FA68F374CE57BD3BB7D9350585877582FAC855FEE311B923F347E1E28E01E2A78D018F0853CD0DA1&WIDTH=256&HEIGHT=256&SRS=EPSG%3A3857&BBOX=1197309.6110590026%2C8376275.307602754%2C1198532.6035115654%2C8377498.300055317
https://gatekeeper2.geonorge.no/BaatGatekeeper/gk/gk.cache_wmts?&gkt=B5B67D41AD55131D42FCB85545AFADD0EAFBAD91D5A7AD9F4AE431BEFD257F966B0D02D7D9F4BA2209BA73A64A649FC7018EB317F23B083A8D018F0853CD0DA1&layer=sjokartraster&style=default&tilematrixset=EPSG%3A25833&Service=WMTS&Request=GetTile&Version=1.0.0&Format=image%2Fpng&TileMatrix=EPSG%3A25833%3A12&TileCol=2058&TileRow=1398



То же самое? там sjokartraster2, а не sjokartraster: https://wms.geonorge.no/skwms1/wms.sjokartraster2?service=wms&version=1.3.0&request=getcapabilities
         https://wms.geonorge.no/skwms1/wms.sjokartraster2?REQUEST=GetMap&SERVICE=WMS&VERSION=1.3.0&FORMAT=image%2Fpng&STYLES=&TRANSPARENT=true&LAYERS=all&WIDTH=256&HEIGHT=256&CRS=EPSG%3A3857&BBOX=1193640.6337013133%2C8378721.292507879%2C1194252.1299275947%2C8379332.788734161
То же самое, но в другой разграфке tilematrixset=utm33n:
https://cache.kartverket.no/test/wmts?layer=sjokartraster&style=default&tilematrixset=utm33n&Service=WMTS&Request=GetTile&Version=1.0.0&Format=image%2Fpng&TileMatrix=13&TileCol=4078&TileRow=3540
*/
$humanName = array('ru'=>'Морская карта Норвегии','en'=>'NAIS Norwegian marine map');
//$ttl = 60*60*24*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
$ttl = 60*60*24*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
//$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать. OpenTopoMap банит скачивальщиков, поэтому короткое.
$ext = 'png'; 	// tile image type/extension
$minZoom = 1;
$maxZoom = 18;
$bounds = array('leftTop'=>array('lat'=>84.7344,'lng'=>-173.0237),'rightBottom'=>array('lat'=>-79.0029,'lng'=>37.9688));
// crc32 хеши тайлов, которые не надо сохранять: логотипы, тайлы с дурацкими надписями. '1556c7bd' чистый голубой квадрат 'c7b10d34' чистый голубой квадрат - не мусор! Иначе такие тайлы будут скачиваться снова и снова, а их много.
$trash = array(
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
// array($zoom,$x,$y,$hash)
$trueTile=array(15,17360,9532,'b4e0815d');	// to source check; tile number and CRC32b hash. Oslo

$getURLoptions['r'] = pathinfo(__FILE__, PATHINFO_FILENAME);	// $getURLoptions будет передан в $getURL

$getURL = function ($z,$x,$y) {
/* */
$url = 'https://wms.geonorge.no/skwms1/wms.sjokartraster2?REQUEST=GetMap&SERVICE=WMS&VERSION=1.3.0&FORMAT=image%2Fpng&STYLES=&TRANSPARENT=true&LAYERS=all&CRS=EPSG%3A3857';

$userAgent = randomUserAgent();

$RequestHead='Referer: https://geonorge.no/';
//$RequestHead='';

//$leftTop = tileNum2ord($z,$x,$y);	// fcommon.php
//$rightBottom = tileNum2ord($z,$x+1,$y+1);
//$url .= '&WIDTH=256&HEIGHT=256';
// 5х3 от середины
$leftTop = tileNum2ord($z,$x-2,$y-1);	// 5х3 fcommon.php
$rightBottom = tileNum2ord($z,$x+3,$y+2);
$url .= '&WIDTH=1280&HEIGHT=768';

$url .= "&BBOX={$leftTop['x']}%2C{$rightBottom['y']}%2C{$rightBottom['x']}%2C{$leftTop['y']}";

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE,
		'protocol_version'=>1.1
	)
);
//print_r($opts);
// set it if you hawe Tor as proxy, and want change exit node every $tilesPerNode try. https://stackoverflow.com/questions/1969958/how-to-change-the-tor-exit-node-programmatically-to-get-a-new-ip
// tor MUST have in torrc: ControlPort 9051 without authentication: CookieAuthentication 0 and #HashedControlPassword
// Alternative: set own port, config tor password by tor --hash-password my_password and stay password in `echo authenticate '\"\"'`
changeTORnode($getURLoptions['NAIS']);

return array($url,$opts);
};	// end function getURL

//
$putTile = function ($mapName,$imgArray,$trueTile=array(),$options=array()){
/* Custom storage to file procedure.
We get a large picture, and we have to cut it into standard tiles before saving it.
Let's use the functions from fTilesStorage.php
*/
list($z,$x,$y,$ext,$originalImg) = requestedTileInfo($imgArray);	// просто первый элемент $imgArray
if($originalImg){	// received file may be a null if unsuccessful
	// Split image to tiles
	$imgs = splitToTiles($originalImg,$z,$x-2,$y-1,$ext);	// 5х3 от середины
	//$imgs = splitToTiles($originalImg,$z,$x,$y,$ext);
	// After split, the requested tile may not be the first in the array.
	$imgs = requestedTileFirst($z,$x,$y,$ext,$imgs);	// Stay the requested tile first in array
}
else {
	$imgs = $imgArray;
};
$res = putTileToFile($mapName,$imgs,$trueTile,$options);
return $res;
}; // end function putTile
?>
