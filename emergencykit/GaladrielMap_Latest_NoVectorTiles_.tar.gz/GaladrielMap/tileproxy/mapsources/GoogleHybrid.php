<?php
$humanName = array('ru'=>'Космоснимки + карта Google','en'=>'Google hybrid');
$ttl = 86400*365; // 1 year cache timeout in seconds время, через которое тайл считается протухшим
$ext = 'jpeg'; 	// tile image type/extension
$minZoom = 0;
$maxZoom = 20;
/* функция получения тайла позаимствована из OruxMaps */
$getURL = function ($z,$x,$y) {
$server = array(0,1,2,3);
$userAgent = randomUserAgent();
$RequestHead='Referer: http://google.com';

//$headersLang = 'iw'; // hebrew
$headersLang = 'ru'; // russian
//$headersLang = 'en'; // english
//$headersLang = ''; // local
$url = 'http://mt'.$server[array_rand($server)].".google.com/vt/lyrs=s,m&hl=$headersLang";
$url .= "&x=$x&y=$y&z=$z";

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n"
	),
	'socket' => array(
		//'bindto' => '0:0', // Force IPv4 - надо, если провайдер даёт ipv6 адрес, но не даёт сети
	)
);

return array($url,$opts);
};
?>
