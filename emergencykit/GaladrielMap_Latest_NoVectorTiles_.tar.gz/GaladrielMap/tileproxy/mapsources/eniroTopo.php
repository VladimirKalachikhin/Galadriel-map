<?php
/* Algorithm getted from https://github.com/osmandapp/Osmand/issues/5818 and other
 http://192.168.10.10/tileproxy/tiles.php?z=12&x=2374&y=1161&r=eniroTopo
*/
$humanName = array('ru'=>'Топокарта Eniro','en'=>'Eniro topo map');
$ttl = 86400*30*12; //cache timeout in seconds время, через которое тайл считается протухшим. 86400 - сутки
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 4;
$maxZoom = 18;
$bounds = array('leftTop'=>array('lat'=>71.4,'lng'=>4.1),'rightBottom'=>array('lat'=>49,'lng'=>31.9));
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,18938,9278,'09b04b6d');	// to source check; tile number and CRC32b hash

$getURL = function ($z,$x,$y) {
$server = array('','01','02','03','04');
$url='https://map'.$server[array_rand($server)].'.eniro.com/geowebcache/service/tms1.0.0/map/';
//$url='https://map.eniro.com/geowebcache/service/tms1.0.0/nautical/';
$y = ((1 << $z) - 1 - $y);
$url .= "$z/$x/$y".".png";
return $url;
};
?>
