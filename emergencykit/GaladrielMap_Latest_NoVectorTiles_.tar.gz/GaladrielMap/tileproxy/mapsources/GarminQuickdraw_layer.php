<?php
/* Thanks to VadimK60 http://www.sasgis.org/forum/viewtopic.php?f=2&t=3523
*/
$humanName = array('ru'=>'Народный слой глубин Garmin Quickdraw','en'=>'Garmin Quickdarw folk bathymetry');
$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим. 86400 - сутки
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 4;
$maxZoom = 18;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,19879,9844,'5c0d7d3a');	// to source check; tile number and CRC32b hash
//
$prepareTileImgBeforeReturn = function ($img){
// Заменяет в картинке цвета на цвета указанной прозрачности, требует sudo apt install php-gd 
//
$img = addTransparent($img,70);
return array('img'=>$img);
}; // end function prepareTileImg

$requestOptions = array('prepareTileImg'=>true);	// указание, что функцию prepareTileImgBeforeReturn надо применять всегда
//
$getURL = function ($z,$x,$y) {
$url = 'https://downloadqdc.garmin.com/GCSProxyServlet/MarineImages/';
$GRMN = '';
for($i=0;$i<$z;$i++){
	$G = 0;
	$mask = 1 << $i;
	if(($x & $mask) <> 0) $G += 1;
	if(($y & $mask) <> 0) $G += 2;
	$GRMN = $G . $GRMN;
}
$url = $url.$GRMN.'.png?units=m';

$RequestHead='Referer: https://downloadqdc.garmin.com';
$userAgent = randomUserAgent();

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		//'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);

return array($url,$opts);
} // end function getURL
?>
