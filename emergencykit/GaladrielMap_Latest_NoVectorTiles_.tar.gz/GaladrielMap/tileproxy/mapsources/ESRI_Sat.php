<?php
/*
Можно попросить сервер увеличивать картинку, сли снимка нет. Оно надо?
https://www.arcgis.com/home/webmap/viewer.html?featurecollection=https%3A%2F%2Fservices.arcgisonline.com%2Farcgis%2Frest%2Fservices%3Ff%3Djson%26option%3Dfootprints&supportsProjection=true&supportsJSONP=true
*/
$humanName = array('ru'=>'Космоснимки ESRI','en'=>'ESRI satellite photos');
$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, один год
//$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, пол-года
// $ttl = 0; 	// тайлы не протухают никогда
$ext = 'jpg'; 	// tile image type/extension
$ContentType = 'image/jpeg'; 	// if content type differ then file extension
$minZoom = 0;
$maxZoom = 19;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
//'3df36e26' 	// чистый голубой квадрат
);
$getURL = function ($z,$x,$y) {
/* 
 http://192.168.10.10/tileproxy/tiles.php?z=12&x=2374&y=1161&r=ESRI_Sat
*/
$url = 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile';
$url .= "/$z/$y/$x";
return $url;
};
?>
