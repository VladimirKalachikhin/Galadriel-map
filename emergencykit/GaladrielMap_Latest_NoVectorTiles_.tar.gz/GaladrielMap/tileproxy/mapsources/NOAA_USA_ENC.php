<?php
/*
php tilefromsource.php -z15 -x9644 -y12323 -rNOAA_USA_ENC --maxTry=15

Возможно, следует спрашивать у сервиса большую картинку?
*/
$humanName = array('ru'=>'Морская карта NOAA, USA ENC','en'=>'NOAA ENC USA nautical chart');
$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, один год
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$ContentType = 'image/png'; 	// if content type differ then file extension
$minZoom = 3;
$maxZoom = 22;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(14,4822,6161,'808a0939');	// to source check; tile number and CRC32b hash
//
$getURL = function ($z,$x,$y) {
// 
//$userAgent = randomUserAgent();
$userAgent = '';
//$RequestHead='Referer: https://gis.charttools.noaa.gov/';
$RequestHead='';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
$url = 'https://gis.charttools.noaa.gov/arcgis/rest/services/MCS/ENCOnline/MapServer/exts/MaritimeChartService/MapServer/export?f=image&format=PNG32&transparent=true&layers={layers}&display_params={display_params}&size=256%2C256&bboxsr=3857&imagesr=3857&dpi=96';
$options = json_decode('
{
	"ECDISParameters":{
		"version":"10.6.1 P5",
		"DynamicParameters":{
			"Parameter":[
				{"name":"DeepContour","value":10},
				{"name":"DisplayDepthUnits","value":1},
				{"name":"DisplayLightSectors","value":2},
				{"name":"DisplaySafeSoundings","value":2},
				{"name":"HonorScamin","value":1},
				{"name":"OptionalDeepSoundings","value":1},
				{"name":"SafetyContour","value":5},
				{"name":"SafetyDepth","value":10},
				{"name":"ShallowContour","value":2},
				{"name":"TwoDepthShades","value":1}
			]
		}
	}
}'
,true);
$layers = "show:0,1,2,3,4,5,6,7,9";
$url = str_replace("{display_params}",urlencode(json_encode($options)),$url);
$url = str_replace("{layers}",urlencode($layers),$url);

$leftTop = tileNum2ord($z,$x,$y);	// fcommon.php
$rightBottom = tileNum2ord($z,$x+1,$y+1);
// bbox=-8244587.101865853%2C4963749.342781731%2C-8239160.072857463%2C4966931.034084185
$url .= "&bbox={$leftTop['x']}%2C{$rightBottom['y']}%2C{$rightBottom['x']}%2C{$leftTop['y']}";
return array($url,$opts);
};
?>
