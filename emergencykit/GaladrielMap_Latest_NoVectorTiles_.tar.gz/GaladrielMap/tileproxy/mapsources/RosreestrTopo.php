<?php
/*  Единая электронная картографическая основа (Росреестр)
Масштаб 17 есть местами, 18-19 -- планы некоторых городов.
Однако, карта тоже "чтобы враг не догадался". Отсутствуют изменения двадцатилетней давности.
Сервер борется со скачиванием путём установки лимита скачивания с одного ip: 
Traffic blocked because of exceed per IP shaper session quota. Please contact the system administrator.<br> Your session quota is:0, further traffic will be blocked.
Вероятно, этот лимит един для всех незарегистрированных ip, и быстро исчерпывается.
Кроме того, сервер вообще не отвечает на запросы с не российских ip.
Поэтому менять ip через tor бессмысленно.
pkk - это "публичная кадастровая карта"
*/
$humanName = array('ru'=>'Единая картографическая основа (Росреестр)','en'=>'Russian goverment topo map (Rosreestr)');
$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим. 86400 - сутки
//$ttl = 0; 	// тайлы не протухают никогда
// Время, через которое протухает тайл нулевого размера, обозначающий нерешаемые проблемы скачивания.
$noTileReTry=86400*7; 	// empty tile timeout, good if < $ttl sec. 
$ext = 'png'; 	// tile image type/extension
$minZoom = 3;
$maxZoom = 19;
$getURLoptions = array('maxTry'=>10);
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(14,9898,5151,'2cef2969');	// to source check; tile number and CRC32b hash

$prepareTileImgBeforeReturn = function ($img){
// Заменяет в картинке цвет на прозрачный, требует sudo apt install php-gd 
// На этой карте цвет моря - 160,205,255, цвет рек #A0CDFF, 160,205,255 Если заменить его на прозрачный, можно наложить
//эту карту на непрозрачные морские
//
$img = setColorsTransparent($img,array(array(164,206,252),array(160,205,255)));
return array('img'=>$img,'mime_type'=>'image/png');
}; // end function prepareTile

$getURL = function ($z,$x,$y) {
$url='https://nspd.gov.ru/cgk/map/38/tms/';
$url .= "$z/$x/$y.png";

$userAgent = randomUserAgent();
//$RequestHead='Referer: https://rosreestr.ru';	// Там Referer - запрос с главной страницы. Но и без работает.

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
return array($url,$opts);
};
?>
