<?php
/* 
https://julkinen.traficom.fi/oskari/action?action_route=GetLayerTile&id=46&SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&FORMAT=image%2Fpng&TRANSPARENT=true&LAYERS=cells&STYLES=style-id-202&WIDTH=256&HEIGHT=256&CRS=EPSG%3A3067&BBOX=567584%2C6771712%2C568096%2C6772224
Проекция EPSG%3A3067, но есть и EPSG%3A3857 . То же самое, видимо, и CRS%3A84

https://julkinen.traficom.fi/s57/wms
https://julkinen.traficom.fi/s57/wms?service=WMS&version=1.3.0&request=GetCapabilities
https://julkinen.traficom.fi/s57/wms?request=GetMap&service=WMS&version=1.3.0&layers=cells&styles=style-id-202&srs=EPSG%3A3067&bbox=567584%2C6771712%2C568096%2C6772224&width=256&height=256&format=image%2Fpng
*/
$humanName = array('ru'=>'Финляндия, морская карта, слой','en'=>'Finland ENC map layer','fi'=>'Suomen ENC merikartta, kerros');
$mapDescription = array('ru'=>'Старая карта Transas в стиле S57 с глубиной мели в 30 метров.
<a href="https://julkinen.traficom.fi/oskari/">oskari</a>
This dataset produced by the Finnish Transport and Communications Agency 
is licensed under a Creative Commons Attribution 4.0 International License - http://creativecommons.org/licenses/by/4.0/ 
"Source: Finnish Transport and Communications Agency. Not for navigational use. Does not meet the requirements for appropriate nautical charts."

Однако, нагло не пускают русских, и через tor и через общеизвестные VPN и proxy. 
Поэтому нужно искать не общеизвестный proxy.
','en'=>'<a href="https://julkinen.traficom.fi/oskari/">oskari</a>
This dataset produced by the Finnish Transport and Communications Agency 
is licensed under a Creative Commons Attribution 4.0 International License - http://creativecommons.org/licenses/by/4.0/ 
"Source: Finnish Transport and Communications Agency. Not for navigational use. Does not meet the requirements for appropriate nautical charts."
');
//$ttl = 60*60*24*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
$ttl = 60*60*24*30*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
//$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать.
$ext = 'png'; 	// tile image type/extension
$minZoom = 5;
$maxZoom = 18;
$bounds = array('leftTop'=>array('lat'=>65.85,'lng'=>19.17),'rightBottom'=>array('lat'=>59.67,'lng'=>30.38));
// crc32 хеши тайлов, которые не надо сохранять: логотипы, тайлы с дурацкими надписями. '1556c7bd' чистый голубой квадрат 'c7b10d34' чистый голубой квадрат - не мусор! Иначе такие тайлы будут скачиваться снова и снова, а их много.
$trash = array(
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,18956,9316,'c74ccf96');	// to source check; tile number and CRC32b hash


$getURL = function ($z,$x,$y,$getURLoptions=array()) {
/* 
style-id-200	Standard
style-id-201	Standard - Transparent Land
style-id-202	Full
style-id-203	Full - Transparent Land
*/
$url = 'https://julkinen.traficom.fi/s57/wms?request=GetMap&service=WMS&version=1.3.0&layers=cells&styles=style-id-203&srs=EPSG%3A3857&format=image%2Fpng';

$userAgent = randomUserAgent();
//$RequestHead='Referer: ';
$RequestHead='';

/*/ Один тайл
$leftTop = tileNum2ord($z,$x,$y);	// fcommon.php
$rightBottom = tileNum2ord($z,$x+1,$y+1);
$url .= '&width=256&height=256';
/*/
// 5х3 от середины
$leftTop = tileNum2ord($z,$x-2,$y-1);	// 5х3 fcommon.php
$rightBottom = tileNum2ord($z,$x+3,$y+2);
$url .= '&WIDTH=1280&HEIGHT=768';
//
$url .= "&bbox={$leftTop['x']}%2C{$rightBottom['y']}%2C{$rightBottom['x']}%2C{$leftTop['y']}";

$proxyesList = array(
'tcp://58.147.186.214:3125',
'tcp://47.243.92.199:3128',
'tcp://36.66.242.118:8080',
'tcp://4.149.153.123:3128',
'tcp://49.229.100.235:8080',
'tcp://177.234.194.30:999',
'tcp://103.227.187.1:6080',
'tcp://47.91.104.88:3128',
'tcp://8.213.151.128:3128'
);
$proxy = $proxyesList[array_rand($proxyesList)];
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>$proxy,
		//'timeout' => 30,
		'request_fulluri'=>true,
		//'protocol_version'=>1.1
	)
);
//print_r($opts);

return array($url,$opts);
};
//

$putTile = function ($mapName,$imgArray,$trueTile=array(),$options=array()){
/* Custom storage to file procedure.
We get a large picture, and we have to cut it into standard tiles before saving it.
Let's use the functions from fTilesStorage.php
*/
list($z,$x,$y,$ext,$originalImg) = requestedTileInfo($imgArray);	// просто первый элемент $imgArray
//echo "Для сохранения получен файл размером ".(strlen($originalImg))." байт\n";
if($originalImg){	// received file may be a null if unsuccessful
	// Split image to tiles
	$imgs = splitToTiles($originalImg,$z,$x-2,$y-1,$ext);	// 5х3 от середины
	//$imgs = splitToTiles($originalImg,$z,$x,$y,$ext);
	// After split, the requested tile may not be the first in the array.
	$imgs = requestedTileFirst($z,$x,$y,$ext,$imgs);	// Stay the requested tile first in array
}
else {
	$imgs = $imgArray;
};
$res = putTileToFile($mapName,$imgs,$trueTile,$options);
return $res;
}; // end function putTile
?>
