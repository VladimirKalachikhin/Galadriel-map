<?php
/*
http://88.99.52.155/cgi-bin/tapp/tilecache.py/1.0.0/topomapper_v2/12/2374/1161
http://88.99.52.155/tmg/12/2374/1161
*/
$humanName = array('ru'=>'Топографические карты Генерального штаба от retromap','en'=>'Russian military maps from retromap.ru');
//$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, один год
$ttl = 0; 	// тайлы не протухают никогда
$ext = 'jpg'; 	// tile image type/extension
$ContentType = 'image/jpeg';
$minZoom = 11;
$maxZoom = 13;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(13,4949,2575,'$y');	// to source check; tile number and CRC32b hash


$getURL = function ($z,$x,$y) {
/*
https://hutun.ru/tiles/9/1419909/Z14/5149/9896.jpg
 */
global $ext;

//$userAgent = randomUserAgent();
//$userAgent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36';
$RequestHead='Referer: https://retromap.ru/';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		//'timeout' => 60,
		'request_fulluri'=>TRUE,
		//'protocol_version'=>1.1
	),
//	'socket' => array(
//		'bindto' => '0:0', // Force IPv4 - надо, если провайдер даёт ipv6 адрес, но не даёт сети
//	)
);

$url = 'https://hutun.ru/tiles/9';
if($z<13) $url .= '/14199019';
else $url .= '/1419909';
$url .= "/Z$z/$y/$x.$ext";
return array($url,$opts);
};

$getTile = 'getTileFromSQLite'; 	
$putTile = 'putTileToSQLite';

?>
