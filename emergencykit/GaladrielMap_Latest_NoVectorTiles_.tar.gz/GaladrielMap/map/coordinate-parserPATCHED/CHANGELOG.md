## [1.0.2] - 2016-01-13
### Changed
- Do not require presence of Math.sign()

## [1.0.1] - 2015-11-19
### Fixed
- Allow degree part of latitude/longitude to be zero

## [1.0.0] - 2015-11-06
### Added
- Added coordinate Parser class
- Compatibility with numerous decimal, DMS, and exotic coordinate formats
- Pass single coordinate string to constructor
- Throw error if provided coordinate string is invalid
- Obtain decimal result through instance's getLatitude() and getLongitude()
