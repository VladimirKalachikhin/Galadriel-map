<?php
/* Нет России, высоты ЛЭП и мостов есть.
Изобаты выглядят подробней, чем в Navionics Sonar
Вроде бы, не банит, поэтому TOR ненужен.
Но по дороге банит CloudFront, если нет заголовка Referer.

https://appchart.c-map.com/core/map
https://tiles.c-map.com/wmts/maxnp_int1_hrb/webmercator/17/75824/37265.png

Приведённая здесь конфигурация предполагает, что на этой же машине имеется узел tor
У tor должен быть включен управляющий сокет.

По умолчанию всё это отключено. Для включения нужно раскомментировать параметр 'proxy' и 'timeout' 
в массиве $opts
*/
//$humanName = array('ru'=>'Морская карта C-MAP','en'=>'C-MAP nautical chart');
$humanName = array('en'=>'C-MAP nautical chart');
$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, год
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 4;
$maxZoom = 18;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
'b5cbf9c1',
'c1bf06e3',
'508cbed2',
'c1bf06e3',
'f2ebed17',
'dc988b94',
'd4485cec',
'7f04b330',
'082d0f19',
'060577bc',
'af4a527c',
'6c2b2e39',
'59d35f0a',
'c1e67243',
'4cc9b768',
'14f66baf',
'd3f3383b',
'43a7d23d',
'e3e44173',
'30efa4b5',
'64e272d0',
'5a4243fd',
'06e2e3d9',
'1ff7cb5e',
'5d30732c',
'd0e497c7',
'597f6d72',
'dc3a3302',
'053a5fd0',
'574786e3',
'bf1c1ae3',
'fa8cb267',
'a0ff450d',
'44f9ca5b',
'1795aa10',
'f7e556b9',
'cac3a620',
'404910bb',
'2bbec659',
'9bc7fcdc',
'ed3be00e',
'bae3119d',
'52bd90a6',
'124592d3',
'da6855ff',
'0957c278',
'1e908149',
'da58f2fe',
'adc67bdc',
'3def0370',
'3d5fa3c7',
'd88afe8d',
'7ca91177',
'0e2af770',
'85bee8ba',
'3c7a226d',
'910c73a8',
'54a1f2dd',
'2da05ab6',
'9bb140c6',
'c2e891e1',
'3ff4d36c',
'76a83aca',
'c14e2f98',
'449c3a0a',
'37129bfc',
'62384618',
'ece244c4',
'53635dce',
'df647e1c',
'9b20ac3c',
'9b702e7b',
'07efe0aa',
'cbc84f25',
'59c7a81c',
'7e755bd9',
'e871ba76',
'039e89ca',
'073aa510',
'97b934b8',
'f2836951',
'0456ddd0',
'727121ff',
'aee34f44',
'54eb4c5e',
'378a2c2e',
'e4abe4c7',
'5747f6d4',
'8408ea95',
'd28dace0',
'4d756336',
'ce784523',
'1903633d',
'd8feb630',
'24d07482',
'5edde46b',
'89afedd2',
'59d187d7',
'bfac003e',
'5cdfa8fc',
'81fcf0b4',
'32c7c519',
'7b1ee4f9',
'545fc58c',
'd0ae0e25',
'bf3b8caa',
'652ed0da',
'a3d78a7f',
'c5c17599',
'36c2669b',
'881e80e2',
'792e692c',
'a82c9775',
'd3a79250',
'6c5136b3',
'1382c075',
'cbb5133a',
'50365659',
'243539a5',
'4a3827fb',
'996a910b',
'7a613d1f',
'46f219ad',
'6c5136b3',
'1810d493',
'7bd80ce7',
'906c28f8',
'8333d6a1',
'32505766',
'0713358a',
'6e9ed0de',
'd51b7656',
'4f7ec762',
'46bb1d0f',
'c13f35f3',
'68fdb146',
'9931da81',
'36b5fd55',
'ec48f952',
'3843a66f',
'0d264bff',
'03a7eeab',
'6a3abefb',
'4d0f37c9',
'cdf368cf',
'1b470305',
'd50b1b51',
'16f50786',
'390a5556',
'91cda347',
'51d0d5d7',
'f1fb9ad6',
'9789b3a0',
'7dc8c3dc',
'27d451df',
'5f5eb210',
'a0e8daee',
'f27c74a3',
'ff147ee0',
'5df94f08',
'5681ce47',
'1368f3f8',
'20f78072',
'3a709c87',
'713ba063',
'a181c826',
'75471a5c',
'3962481d',
'0f7abd48',
'3962481d',
'0f7abd48',
'3962481d',
'39a94c9c',
'a439b852',
'5a1c4fec',
'39a94c9c',
'5a1c4fec',
'39a94c9c',
'3b600818',
'a6ef5eaf',
'f7f5639d',
'5a7acf31',
'f7f5639d',
'5a7acf31',
'c34bb0a6',
'2d16f812',
'd7379edb',
'be6b36fd',
'004a23ce',
'ad913ea4',
'855f4d86',
'b67a9795',
'65a54469',
'855f4d86',
'7a5ab9ac',
'cca75439',
'65a54469',
'91cd69db',
'e1e6abb6',
'd49ed8d2',
'b33483fb',
'69c0ca4b',
'e97ccc7d',
'1a6295fb',
'231482e8',
'e9725478',
'307ffcc1',
'e8ea55c3',
'307ffcc1',
'e8ea55c3',
'5ee4ab3a',
'15e84736',
'7c3e0626',
'c6677d94',
'73d8c366',
'4fe631ca',
'73d8c366',
'd005800f',
'550080e1',
'd005800f',
'550080e1',
'5ad0be38',
'5323ed4b',
'1a8ecc50',
'173e9a63',
'c400c7a4',
'94b646f3',
'9f6d2c50',
'894e7e77',
'1fb49390',
'be26ea0b',
'02e72e9e',
'32ce173a',
'85ccf65c',
'a05cdd5f',
'51e0a24a',
'891806da',
'6621d7df',
'cffe8950'
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(14,9478,4657,'e792b3ce');	// to source check; tile number and CRC32b hash
//
$functionPrepareTileImg = <<<'EOFU1'
function prepareTileImg($img){
// Заменяет в картинке цвет на прозрачный, требует sudo apt install php-gd 
// На этой карте цвет суши - 255,238,119 или 252,238,116 а населённых пунктов 255,222,98
// Если заменить его на прозрачный, можно наложить
//эту карту на непрозрачные карты суши
$img = setColorsTransparent($img,array(
	array(255,238,119),
	array(252,238,116),
	array(252,222,100),
	array(238,222,98),
	array(255,222,98),
	array(236,223,112),
	array(212,202,100)
));
return array('img'=>$img,'mime_type'=>'image/png');
} // end function prepareTileImg
EOFU1;
//
$functionGetURL = <<<'EOFU'
function getURL($z,$x,$y) {
global $ext;
$url="https://tiles.c-map.com/wmts/maxnp_int1_hrb/webmercator/$z/$x/$y.$ext";

$userAgents = array();
$userAgents[] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36';
$userAgents[] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0';
$userAgents[] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36';
$userAgents[] = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36';
$userAgents[] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36';
$userAgents[] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_3) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0.3 Safari/604.5.6';
$userAgents[] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36';
$userAgents[] = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0';
$userAgents[] = 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:59.0) Gecko/20100101 Firefox/59.0';
$userAgents[] = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.13; rv:59.0) Gecko/20100101 Firefox/59.0';
$userAgent = $userAgents[array_rand($userAgents)];

// header Referer обязательно, иначе банит CloudFront
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\nReferer: https://www.c-map.com/\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		//'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
// set it if you hawe Tor as proxy, and want change exit node every $tilesPerNode try. https://stackoverflow.com/questions/1969958/how-to-change-the-tor-exit-node-programmatically-to-get-a-new-ip
// tor MUST have in torrc: ControlPort 9051 without authentication: CookieAuthentication 0 and #HashedControlPassword
// Alternative: set own port, config tor password by tor --hash-password my_password and stay password in `echo authenticate '\"\"'`
$getTorNewNode = "(echo authenticate '\"\"'; echo signal newnym; echo quit) | nc localhost 9051"; 	
$tilesPerNode = 10; 	// change ip after попытка смены ip предпринимается каждые столько тайлов
$map = 'C-MAP_raster';	// нужно только для смены выходной ноды
if($getTorNewNode AND @$opts['http']['proxy']) { 	// можно менять выходную ноду Tor.
	$dirName = sys_get_temp_dir()."/tileproxyCacheInfo"; 	// права собственно на /tmp в системе могут быть замысловатыми
	if(file_exists($dirName) === FALSE) { 	// не будем сбрасывать кеш -- пусть кешируется
		mkdir($dirName, 0777,true); 	// 
		chmod($dirName,0777); 	// права будут только на каталог OpenTopoMapCacheInfo. Если он вложенный, то на предыдущие, созданные по true в mkdir, прав не будет. Тогда надо использовать umask.
	}
	$tilesCntFile = "$dirName/tilesCnt_$map";
	$tilesCnt = @file_get_contents($tilesCntFile);
	if ($tilesCnt > $tilesPerNode) { 	// если уже пора
		echo"getting new Tor exit node\n";
		exec($getTorNewNode);	// сменим выходную ноду Tor
		$tilesCnt = 1;
	}
	else $tilesCnt++;
	file_put_contents($tilesCntFile,$tilesCnt);
	@chmod($tilesCntFile,0666); 	// всем всё, чтобы работало от любого юзера. Но изменить права существующего файла, созданного другим юзером не удастся.
}

return array($url,$opts);
}
EOFU;

?>
