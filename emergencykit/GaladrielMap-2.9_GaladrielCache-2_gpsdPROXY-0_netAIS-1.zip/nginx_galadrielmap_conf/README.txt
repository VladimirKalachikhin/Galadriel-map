PLEASE! If you may use Apache - use it!

Place nginx_galadrielmap_conf directory to /etc/nginx/ and edit nginx.conf by add 
 include nginx_galadrielmap_conf/GaladrielMap/*.conf;
string to end of default "server" section:

	server{ 
		listen 80 default_server; 
		....
		
		include nginx_galadrielmap_conf/GaladrielMap/*.conf;
	} 

and
 include nginx_galadrielmap_conf/netAIShiddenService/*.conf;
string to end of "http" section, but before
 include /etc/nginx/conf.d/*.conf;
string:

http {

	....
	
	include nginx_galadrielmap_conf/netAIShiddenService/*.conf;
    include /etc/nginx/conf.d/*.conf;
}

restart nginx

Change /etc/php7-fpm.d/www.conf to:  

;user = nobody
user = root

Change /etc/init.d/php7-fpm to:

#PROG="/usr/bin/php-fpm"
PROG="/usr/bin/php-fpm -R"

As result nginx will be run from root. This is necessary for the GaladrielMap to work correctly

 
Используйте Apache, если это возможно! Не надо вот этого...

Поместите этот каталог рядом с каталогом /etc/nginx/conf.d и добавьте в nginx.conf строки:
 include nginx_galadrielmap_conf/*.conf;
в конец главного блока server{}:

	server{ 
		listen 80 default_server; 
		....
		
		include nginx_galadrielmap_conf/GaladrielMap/*.conf;
	} 

и в конце блока http{}, перед строкой
 include /etc/nginx/conf.d/*.conf; 
:

http {

	....
	
	include nginx_galadrielmap_conf/netAIShiddenService/*.conf;
    include /etc/nginx/conf.d/*.conf;
}

перезапустите nginx

Измените файл /etc/php7-fpm.d/www.conf следующим образом:  

;user = nobody
user = root

Измените файл /etc/init.d/php7-fpm следующим образом:

#PROG="/usr/bin/php-fpm"
PROG="/usr/bin/php-fpm -R"

В результате nginx  будет запускаться от root. Это нужно для нормальной работы GaladrielMap.

