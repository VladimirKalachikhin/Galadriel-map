<?php
/**/
$a = array('a'=>1,'b'=>2);
print_r($a);
foo();
print_r($a);

function foo(){
global $a;
unset($a['a']);
echo "In foo:"; print_r($a); echo "\n";
unset($a['c']);
};
?>
