<?php
/**/
require('fGeodesy.php');
require('fWaypoints.php');

$instrumentsData = array();
$way = array();	// собственно, путь, которым следуем, делается из gpx rte или wpt. array('lat'=>,'lon'=>)

$wayFileName = '../www/map/route/2024-12-12T14:35:34.642Z.gpx';
//$wayFileName = '../www/map/route/testTest.gpx';
//$wayFileName = '../www/map/route/FIN-CastleHistoricalSite.gpx';
//$wayFileName = '../www/map/track/2025-07-12_010614.gpx';

$pos = array('lat'=>60.0731,'lon'=>26.617);

$way = wayFileLoad($wayFileName);
if(!$way) return;
print_r($way); echo "\n";

toIndexWPT(@$instrumentsData['WPT']['index']);
print_r($instrumentsData); echo "\n";

toIndexWPT(1);
print_r($instrumentsData); echo "\n";

echo "Ближайшая точка №".(getNearestWPTi($pos))."\n";

?>
