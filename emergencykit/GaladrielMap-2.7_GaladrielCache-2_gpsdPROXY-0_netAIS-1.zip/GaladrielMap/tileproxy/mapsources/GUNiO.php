<?php
$humanName = array('ru'=>'Морские карты ГУНиО','en'=>'Russian navy maps');
$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 1;	// почему там появляются пустые тайлы?
$ext = 'png'; 	// tile image type/extension
$minZoom = 4;
$maxZoom = 16;
?>
