<?php
/*  Единая электронная картографическая основа (ФППД ЦГКИПД)
https://portal.fppd.cgkipd.ru/map
Федеральное государственное бюджетное учреждение 
«Федеральный научно-технический центр геодезии, картографии и инфраструктуры пространственных данных» 
(ФГБУ «Центр геодезии, картографии и ИПД»)
Но вообще -- явно чтоб враг не догадался. Карты очень древние.
https://ngw.fppd.cgkipd.ru/tile/56/13/4950/2576.png
*/
$humanName = array('ru'=>'Единая картографическая основа (ФППД ЦГКИПД)','en'=>'Russian goverment topo map (CGKIPD)');
$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим. 86400 - сутки
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 3;
$maxZoom = 14;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(14,9898,5151,'a5110337');	// to source check; tile number and CRC32b hash

$functionGetURL = <<<'EOFU'
function getURL($z,$x,$y) {
$url='https://ngw.fppd.cgkipd.ru/tile/56/';
$url .= "$z/$x/$y".".png";
return $url;
}
EOFU;
?>
