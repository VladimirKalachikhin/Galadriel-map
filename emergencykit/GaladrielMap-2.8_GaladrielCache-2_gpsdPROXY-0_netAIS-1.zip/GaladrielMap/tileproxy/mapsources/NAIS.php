<?php
/* https://opencache.statkart.no/gatekeeper/gk/gk.open_gmaps?layers=sjokartraster&zoom=14&x=8771&y=4112
*/
$humanName = array('ru'=>'Морская карта Норвегии','en'=>'NAIS Norvegian marine mao');
//$ttl = 60*60*24*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
$ttl = 60*60*24*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
//$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать. OpenTopoMap банит скачивальщиков, поэтому короткое.
$ext = 'png'; 	// tile image type/extension
$minZoom = 2;
$maxZoom = 18;
// crc32 хеши тайлов, которые не надо сохранять: логотипы, тайлы с дурацкими надписями. '1556c7bd' чистый голубой квадрат 'c7b10d34' чистый голубой квадрат - не мусор! Иначе такие тайлы будут скачиваться снова и снова, а их много.
$trash = array(
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
//$trueTile=array(15,19796,10302,'ec555724');	// to source check; tile number and CRC32b hash
$functionGetURL = <<<'EOFU'
function getURL($z,$x,$y) {
/* */
$url = 'https://opencache.statkart.no/gatekeeper/gk/gk.open_gmaps?layers=sjokartraster';

$userAgents = array();
$userAgent = $userAgents[array_rand($userAgents)];

//$RequestHead='Referer: http://openstreet.com';
$RequestHead='';

$url .= "&zoom=$z&x=$x&y=$y";
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
//print_r($opts);

return array($url,$opts);
}
EOFU;
?>
