<?php
/* Options, paths and services
*/
// Параметры Options
//	Длина вектора скорости, собственного и целей AIS. Минут движения.
// Velocity vector length, own and AIS targets. Minutes of movement.
$velocityVectorLengthInMn = 10;	
// Пути paths
// путь в файловой системе к демону, собирающему информацию от gpsd. Демон имеет собственные настройки и зависимости!
// The Data collection daemon. Daemon has its own config file!
$gpsdPROXYpath = 'gpsdPROXY';	// file system path
// путь в файловой системе к программе кеширования тайлов GaladrielCache
$tileCachePath = '/GaladrielMap/tileproxy'; 	// path to GaladrielCache tile cache/proxy app location, if present, in filesystem. Comment this if no GaladrielCache. 
// путь в файловой системе к папке с записью пути (треку), от расположения GaladrielMap или абсолютный
$trackDir = 'track'; 	// track files directory, if present, in filesystem
// путь в файловой системе к папке с проложенными маршрутами и навигационными точками. Или абсолютный.
$routeDir = 'route'; 	// route & POI files directory, if present, in filesystem

// Службы Services
// 	Источник карты Map source
// url источника карты: в интернет или GaladrielCache
$tileCacheURI = "/tileproxy/tiles.php?z={z}&x={x}&y={y}&r={map}"; 	// uri of the map service, for example Galadriel tile cache/proxy service. In case GaladrielCache {map} is a map name in GaladrielCache app.
//$tileCacheURI = "http://mt2.google.com/vt/lyrs=s,m&hl=ru&x={x}&y={y}&z={z}"; 	//   uri of the map service - if no use GaladrielCache. Comment the $tileCachePath on this case.
//$tileCacheURI = 'http://a.tile.opentopomap.org/{z}/{x}/{y}.png'; 	//  uri of the map service - if no use GaladrielCache. Comment the $tileCachePath on this case.

// если время последнего определения положения отличается от текущего на столько секунд -- положение показывается как устаревшее (серый курсор)
$PosFreshBefore = 5; 	// seconds. The position is considered correct no longer than this time. If the position older - cursor is grey.

// 	Запись пути Logging
//		установите gpsd-utils, в состав которых входит gpxlogger  install gpsd-utils for gpxlogger
//		если эта переменная не установлена -- считается, что запись пути осуществляется чем-то другим
// 		при потере позиции на столько секунд будет создан новый путь
$loggerNoFixTimeout = 30; 	// sec A new track is created if there's no fix written for an interval
// 		новые координаты записываются каждые столько секунд
$loggerMinMovie = 5; 	// m Motions shorter than this will not be logged 
//		файл, куда записывается путь, имеет такое имя, что более поздние файлы находятся в начале списка (TRUE), или в конце (FALSE). Зависит от программы записи пути.
$currTrackFirst = FALSE; 	// In list of a tracks current track is a first (TRUE), or a last (FALSE). Depending on a your tracking app.
//		Через сколько дней начинать новый файл.
$newTrackEveryDays = 1;	// After how many days to start a new file.
//		запуск gpxlogger. &logfile заменяется на имя файла лога, &host -- именем хоста, на котором занущена программа
//		если эта переменная не установлена -- считается, что запись пути осуществляется чем-то другим
//		_Обязательно_ указывать полные пути, если вы хотите, чтобы запись пути возобновилась после
//		случайного выключения сервера. Узнать полный путь к команде можно с помощью заклинания which.
//		It is mandatory to specify full paths if you want the path recording to resume after
//		accidentally shutting down the server. You can find out the full path to the command 
//		using a spell "which"		
$gpxlogger = "/usr/local/bin/gpxlogger -e shm -r -i $loggerNoFixTimeout -m $loggerMinMovie -f &logfile"; 	// will listen to the local gpsd using shared memory, reconnect, interval, minmove. &logfile replaced by log filename
//$gpxlogger = "/usr/bin/gpxlogger -e sockets -r -i $loggerNoFixTimeout -m $loggerMinMovie -f &logfile"; 	// OpenWRT
//$gpxlogger = "gpxlogger -e shm -r --garmin -i $loggerNoFixTimeout -m $loggerMinMovie -f &logfile"; 	// sins 3.24.1 - logging depth as Garmin extension. will listen to the local gpsd using shared memory, reconnect, interval, minmove. &logfile replaced by log filename
//$gpxlogger = "gpxlogger -e shm -r -i $loggerNoFixTimeout -m $loggerMinMovie -f &logfile &host:2947"; 	// 
//$gpxlogger = "gpxlogger -e sockets -r -i $loggerNoFixTimeout -m $loggerMinMovie -f &logfile"; 	// 
//$gpxlogger = "gpxlogger -e dbus -r -i $loggerNoFixTimeout -m $loggerMinMovie -f &logfile"; 	// 
//$gpxlogger = "gpxlogger -r -i $loggerNoFixTimeout -m $loggerMinMovie -f &logfile"; 	// Default dbus

// Показ глубины вдоль gpx. Display depth along the gpx.
// display	boolean	Показывать ли глубину вдоль линии пути из файлов gpx, если она там есть.
//					Показ глубины примерно утраивает затраты памяти клиента на показ файла gpx.
//					Whether to show the depth along the track line from the gpx files, if it is there.
//					Showing the depth approximately triples the client's memory consumption for showing the gpx file.
// minvalue	float	Минимально - допустимая глубина. Рекомендуется установить >= осадке судна.
//					Minimum permissible depth. It is recommended to set >= draught of the vessel.
// maxvalue	float	Максимально - интересная глубина. Глубина свыше будет обозначаться одним цветом.
//					Maximum is an interesting depth. Depths over will be indicated by one colour.
// minColor	array or string	Цвет для minvalue. Массив r,g,b или строка с html обозначением цвета.
//							Color for minvalue. Array of r,g,b or html color string.
// maxColor	array or string	Цвет для maxvalue.
//							Color for maxvalue.
// underMinColor	string	Цвет для глубины, меньшей, чем minvalue. Только! строка с html обозначением цвета.
//							Color for a depth less than minvalue. Html color string only.
// upperMaxColor	string	Цвет для глубины, большей чем maxvalue. Только! строка с html обозначением цвета.
//							Colour for depth, more than maxvalue. Html color string only.
$depthInData = '{"display":true,
"minvalue": 5,
"maxvalue": 10,
"minColor": [255,0,0],
"maxColor": [0,255,0],
"underMinColor": "rgb(155,0,0)",
"upperMaxColor": "rgb(200,250,240)"
}';

// Системные параметры System
// строка запуска консольного интерпретатора php
//$phpCLIexec = '/usr/bin/php-cli'; 	// php-cli executed name on your OS
//$phpCLIexec = '/usr/bin/php'; 	// php-cli executed name on your OS
$phpCLIexec = 'php'; 	// php-cli executed name on your OS

//  поскольку params.php загружается отнюдь не только в index, все параметры должны быть здесь
// Параметры тайлового кеша Settings of a tile cache/proxy app
if( $tileCachePath) require_once("$tileCachePath/params.php");
require_once($gpsdPROXYpath.'/params.php'); 	// 
?>
