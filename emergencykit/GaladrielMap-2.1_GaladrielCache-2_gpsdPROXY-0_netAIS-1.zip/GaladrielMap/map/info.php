<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
   <LINK href="common.css" rel="stylesheet" type="text/css">
   <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   <META http-equiv="Content-Script-Type" content="text/javascript">
   <title></title>
</head>
<body>
<?php
echo "Wrappers present:<pre>"; print_r(stream_get_wrappers()); echo "</pre>\n";
phpinfo();
?>
</body>
</html>
