<?php
/* https://www.skippo.se/plan
*/
$humanName = array('ru'=>'Скандинавия, морская карта, векторная','en'=>'Scandinavian nautical vector chart');
//$ttl = 0; 	// тайлы не протухают никогда
$ttl = 86400*365; // 1 year cache timeout in seconds время, через которое тайл считается протухшим
$ext = 'mvt'; 	// tile image extension
$ContentType = 'application/x-protobuf'; 	// tile image type
//$content_encoding = 'gzip';

// Вы _должны_ отредактировать файл стиля skippo.json, как минимум, приведя указанные там
// html пути в соответствие с путями на своём сервере.
// MBTiles, страной волею своих создателей, не является переносимым форматом. Доступ к тайлам,
// значкам и шрифтам указывается там в файлах стиля в виде абсолютных url.
// Эти url следует поменять на фактические.
// You MUST edit the skippo.json style file, at a minimum, by matching the HTML paths
// specified there with the paths on your server.
// MBTiles, due to the strange will of its creators, is not a portable format. Access to tiles,
// icons, and fonts is specified there in style files as absolute URLs.
// These URLs should be changed to the actual ones.
$vectorTileStyleURL = "$tileCacheServerPath/$mapSourcesDir/skippo/skippo.json";

$minZoom = 0;
$maxZoom = 16; 	// иногда есть? тайлы более крупных масштабов, но обчно - только 13 (15?), а более крупные лежат прямо в тайле масштаба 13
$on403 = 'skip'; 	// если тайла нет, то оно говорит 204 No Content, для чего skip
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(13,4739,2328,'1fbe8ac5');	// to source check; tile number and CRC32b hash

//
$getURL = function ($z,$x,$y,$getURLoptions=array()) {
/* https://onlinemaps.skippo.cloud/s57_20250829/13/4508/2409.mvt */
$userAgent = randomUserAgent();
//$RequestHead='Referer: https://www.skippo.se/';
$RequestHead='';

$url = "https://onlinemaps.skippo.cloud/s57_20250829/$z/$x/$y.mvt";

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		//'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);

// set it if you have Tor as proxy, and want change exit node every $tilesPerNode try. https://stackoverflow.com/questions/1969958/how-to-change-the-tor-exit-node-programmatically-to-get-a-new-ip
// tor MUST have in torrc: ControlPort 9051 without authentication: CookieAuthentication 0 and #HashedControlPassword
// Alternative: set own port, config tor password by tor --hash-password my_password and stay password in `echo authenticate '\"\"'`
changeTORnode('skippo');

return array($url,$opts);
}; // end function getURL
//
?>
