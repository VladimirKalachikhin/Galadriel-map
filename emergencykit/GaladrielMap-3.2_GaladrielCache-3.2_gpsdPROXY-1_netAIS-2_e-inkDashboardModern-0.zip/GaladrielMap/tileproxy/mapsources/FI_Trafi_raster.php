<?php
/* 
https://julkinen.traficom.fi/rasteripalvelu/wmts?request=getcapabilities
https://julkinen.traficom.fi/rasteripalvelu/wmts/rest/Traficom:Merikarttasarjat%20public/default/WGS84_Pseudo-Mercator/WGS84_Pseudo-Mercator:14/4658/9478?format=image/png

https://julkinen.traficom.fi/oskari/
https://julkinen.traficom.fi/oskari/action?action_route=GetLayerTile&id=39&layer=Traficom%3AMerikarttasarjat%20public&style=&tilematrixset=ETRS89_TM35-FIN&Service=WMTS&Request=GetTile&Version=1.0.0&Format=image%2Fpng&TileMatrix=ETRS89_TM35-FIN%3A12&TileCol=2180&TileRow=3157

*/
$humanName = array('ru'=>'Финляндия, бумажная морская карта','en'=>'Finland paper marine map','fi'=>'Suomen paperinen merikartta');
$mapDescription = array('ru'=>'Скан морской бумажной карты, довольно низкого качества, один масштаб.
<a href="https://julkinen.traficom.fi/oskari/">oskari</a>
This dataset produced by the Finnish Transport and Communications Agency 
is licensed under a Creative Commons Attribution 4.0 International License - http://creativecommons.org/licenses/by/4.0/ 
"Source: Finnish Transport and Communications Agency. Not for navigational use. Does not meet the requirements for appropriate nautical charts."

Однако, нагло не пускают русских, и через tor и через общеизвестные VPN и proxy. 
Поэтому нужно искать не общеизвестный proxy.
','en'=>'<a href="https://julkinen.traficom.fi/oskari/">oskari</a>
This dataset produced by the Finnish Transport and Communications Agency 
is licensed under a Creative Commons Attribution 4.0 International License - http://creativecommons.org/licenses/by/4.0/ 
"Source: Finnish Transport and Communications Agency. Not for navigational use. Does not meet the requirements for appropriate nautical charts."
');
//$ttl = 60*60*24*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
$ttl = 60*60*24*30*1; //
//$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать. OpenTopoMap банит скачивальщиков, поэтому короткое.
$ext = 'png'; 	// tile image type/extension
$minZoom = 6;
$maxZoom = 15;
$bounds = array('leftTop'=>array('lat'=>65.85,'lng'=>19.0),'rightBottom'=>array('lat'=>59.67,'lng'=>30.38));
// crc32 хеши тайлов, которые не надо сохранять: логотипы, тайлы с дурацкими надписями.
$trash = array(
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,18956,9316,'c5f6164c');	// to source check; tile number and CRC32b hash

$getURL = function ($z,$x,$y,$getURLoptions=array()) {
/* */
$url = 'https://julkinen.traficom.fi/rasteripalvelu/wmts/rest/Traficom:Merikarttasarjat%20public/default/WGS84_Pseudo-Mercator/WGS84_Pseudo-Mercator:';

$userAgent = randomUserAgent();
//$RequestHead='Referer: ';
$RequestHead='';

$url .= "$z/$y/$x?format=image/png";

$proxyesList = array(
"tcp://150.230.104.3:16728",
"tcp://209.97.176.93:8888",
"tcp://35.234.17.221:8080",
"tcp://52.188.28.218:3128",
"tcp://5.9.218.168:3128",
"tcp://94.176.3.43:7443",
"tcp://136.49.42.129:8888",
"tcp://14.225.71.183:25565",
"tcp://27.147.245.189:7735",
"tcp://205.209.118.30:3138",
"tcp://49.229.100.235:8080"
);
$proxy = $proxyesList[array_rand($proxyesList)];
$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>$proxy,
		//'timeout' => 30,
		'request_fulluri'=>true,	// адрес в запросе будет полный! Иначе - относительный.
		//'protocol_version'=>1.1
	)
);
//print_r($opts);

return array($url,$opts);
};
?>
