<?php
/* Источник схем покрытия для всех карт
Coverage source for the all maps
*/
//$ttl = 60*15*1; //cache timeout in seconds время, через которое тайл считается протухшим
$ttl = 60; //cache timeout in seconds время, через которое тайл считается протухшим
$ext = 'png'; 	// tile image type/extension
$ContentType = 'image/png'; 	// if content type differ then file extension
$minZoom = 0;
$maxZoom = 24;
$freshOnly = TRUE; 	// не показывать протухшие тайлы

$mapTiles = "$tileCacheServerPath/tilesCOVER.php?z={z}&x={x}&y={y}&r={map}&options={options}";

?>
