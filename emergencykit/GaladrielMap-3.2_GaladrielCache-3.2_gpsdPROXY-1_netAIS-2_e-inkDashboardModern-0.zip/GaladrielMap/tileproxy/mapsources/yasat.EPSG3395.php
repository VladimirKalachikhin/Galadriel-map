<?php
$humanName = array('ru'=>'Космоснимки Яндекс','en'=>'Yandex satellite photos');
$ttl = 60*60*24*30*6*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
// $ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать. OpenTopoMap банит скачивальщиков, поэтому короткое.
$ext = 'jpg'; 	// tile image type/extension
$ContentType = 'image/jpeg'; 	// if content type differ then file extension
//$EPSG=3395;
$EPSG="EPSG:3395";
$minZoom = 8;
$maxZoom = 19;

$getURLoptions['r'] = pathinfo(__FILE__, PATHINFO_FILENAME);	// $getURLoptions будет передан в $getURL

$getURL = function ($z,$x,$y,$getURLoptions=array()) {
/* Алгоритм получения ссылки на тайл заимствован из SAS.Planet
http://192.168.10.10/tileproxy/tiles.php?z=12&x=2374&y=1161&r=yandex_sat
Карта в EPSG=3395 !!!! Меркатор на эллипсоиде

https://core-sat.maps.yandex.net/tiles?l=sat&v=3.1045.0&x=4947&y=2582&z=13&scale=1&lang=ru_RU
sat0[1-4].maps.yandex.net
*/
$userAgent = randomUserAgent();
//$baseHeaders = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8\r\nAccept-Encoding: gzip, deflate, br, zstd\r\nAccept-Language: en-US,en;q=0.5\r\nConnection: keep-alive\r\n";
//$cookie = "Cookie: _yasc=p7m1kPE3VC6R+EcoIeyLDBYgf6xzgJIWTg14xJ9YTFEOlYyuxrpYzz/FfQR3wg==\r\n";
//$header1 = "Sec-Fetch-Dest:	empty\r\nSec-Fetch-Mode: cors\r\nSec-Fetch-Site: same-site\r\nSec-Fetch-User: ?1\r\nSec-GPC: 1\r\nSec-Ch-Ua: \"Chromium\";v=\"128\", \"Not;A=Brand\";v=\"24\", \"Brave\";v=\"128\"\r\nSec-Ch-Ua-Mobile: ?0\r\nSec-Ch-Ua-Platform: \"Windows\"\r\n";
//$header2 = "Host: core-sat.maps.yandex.net\r\n";
//$header3 = "Upgrade-Insecure-Requests: 1\r\n";
//$referer = "Referer: https://yandex.com/\r\n";
$RequestHead=$baseHeaders.$referer.$header1.$header2.$header3.$cookie;

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 20,
		//'request_fulluri'=>TRUE,	// Должно быть false!!!!
	),
	'socket' => array(
		'bindto' => '0:0', // Force IPv4
	)
);

//$DefURLBase = 'https://core-sat.maps.yandex.net/tiles?l=sat&lang=ru_RU&';
$DefURLBase = 'https://sat0'.rand(1,4).'.maps.yandex.net/tiles?l=sat&lang=ru_RU&';
$DefURLBase .= "z=$z&x=$x&y=$y";
changeTORnode($getURLoptions['r']);
return array($DefURLBase,$opts);
}; // end function getURL
?>
