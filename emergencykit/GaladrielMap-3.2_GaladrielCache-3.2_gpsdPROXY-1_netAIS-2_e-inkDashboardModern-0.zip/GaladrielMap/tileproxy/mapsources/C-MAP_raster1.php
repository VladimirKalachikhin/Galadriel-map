<?php
/* 
https://appchart.c-map.com/core/map
Рельеф дна тонкими редкими линиями, глубина тоном грубо, в основном цифрами
https://tiles.c-map.com/wmts/cmt_int1/webmercator/17/75824/37265.png
Рельеф дна тонкими частыми линиями, глубина тоном, цифры
https://tiles.c-map.com/wmts/cmt_int1_hrb/webmercator/17/75824/37265.png

Рельеф дна толстыми редкими линиями, глубина тоном грубо, в основном цифрами, другие цвета
https://tiles.c-map.com/wmts/maxnp_int1/webmercator/17/75824/37265.png
Рельеф дна толстыми частыми линиями, глубина тоном
https://tiles.c-map.com/wmts/maxnp_int1_hrb/webmercator/17/75824/37265.png

Рельеф дна толстыми редкими линиями, глубина в футах тоном грубо, в основном цифрами, другие цвета
https://tiles.c-map.com/wmts/maxnp_noaa/webmercator/17/75824/37265.png
Рельеф дна толстыми частыми линиями, глубина в футах тоном, берег иначе
https://tiles.c-map.com/wmts/maxnp_noaa_hrb/webmercator/17/75824/37265.png

Рельеф дна тонкими редкими линиями, глубина в футах тоном грубо, в основном цифрами, другие обозначения
https://tiles.c-map.com/wmts/cmt_noaa/webmercator/17/75824/37265.png
Рельеф дна тонкими частыми линиями, глубина в футах тоном
https://tiles.c-map.com/wmts/cmt_noaa_hrb/webmercator/17/75824/37265.png

С рельефом, глубина в футах, красным тоном:
https://tiles.c-map.com/wmts/cmt_noaa_hrb_shaded_relief/webmercator/17/75824/37265.jpeg

Приведённая здесь конфигурация предполагает, что на этой же машине имеется узел tor
У tor должен быть включен управляющий сокет.

По умолчанию всё это отключено. Для включения нужно раскомментировать параметр 'proxy' и 'timeout' 
в массиве $opts
*/
$humanName = array('ru'=>'Морская карта C-MAP, вариант maxnp_hrb','en'=>'C-MAP nautical chart var. maxnp_hrb');
$mapDescription = array('ru'=>'Рельеф дна толстыми частыми линиями, глубина тоном

Нет России, высоты ЛЭП и мостов есть.
Изобаты выглядят подробней, чем в Navionics Sonar
Вроде бы, не банит, поэтому TOR не нужен.
Но по дороге банит Cloudflare, если нет заголовков.
Cloudflare жестоко банит и браузер, так что оно не работает для русских.
','en'=>'
');
$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, год
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 4;
$maxZoom = 19;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
'b5cbf9c1',
'c1bf06e3',
'508cbed2',
'c1bf06e3',
'f2ebed17',
'dc988b94',
'd4485cec',
'7f04b330',
'082d0f19',
'060577bc',
'af4a527c',
'6c2b2e39',
'59d35f0a',
'c1e67243',
'4cc9b768',
'14f66baf',
'd3f3383b',
'43a7d23d',
'e3e44173',
'30efa4b5',
'64e272d0',
'5a4243fd',
'06e2e3d9',
'1ff7cb5e',
'5d30732c',
'd0e497c7',
'597f6d72',
'dc3a3302',
'053a5fd0',
'574786e3',
'bf1c1ae3',
'fa8cb267',
'a0ff450d',
'44f9ca5b',
'1795aa10',
'f7e556b9',
'cac3a620',
'404910bb',
'2bbec659',
'9bc7fcdc',
'ed3be00e',
'bae3119d',
'52bd90a6',
'124592d3',
'da6855ff',
'0957c278',
'1e908149',
'da58f2fe',
'adc67bdc',
'3def0370',
'3d5fa3c7',
'd88afe8d',
'7ca91177',
'0e2af770',
'85bee8ba',
'3c7a226d',
'910c73a8',
'54a1f2dd',
'2da05ab6',
'9bb140c6',
'c2e891e1',
'3ff4d36c',
'76a83aca',
'c14e2f98',
'449c3a0a',
'37129bfc',
'62384618',
'ece244c4',
'53635dce',
'df647e1c',
'9b20ac3c',
'9b702e7b',
'07efe0aa',
'cbc84f25',
'59c7a81c',
'7e755bd9',
'e871ba76',
'039e89ca',
'073aa510',
'97b934b8',
'f2836951',
'0456ddd0',
'727121ff',
'aee34f44',
'54eb4c5e',
'378a2c2e',
'e4abe4c7',
'5747f6d4',
'8408ea95',
'd28dace0',
'4d756336',
'ce784523',
'1903633d',
'd8feb630',
'24d07482',
'5edde46b',
'89afedd2',
'59d187d7',
'bfac003e',
'5cdfa8fc',
'81fcf0b4',
'32c7c519',
'7b1ee4f9',
'545fc58c',
'd0ae0e25',
'bf3b8caa',
'652ed0da',
'a3d78a7f',
'c5c17599',
'36c2669b',
'881e80e2',
'792e692c',
'a82c9775',
'd3a79250',
'6c5136b3',
'1382c075',
'cbb5133a',
'50365659',
'243539a5',
'4a3827fb',
'996a910b',
'7a613d1f',
'46f219ad',
'6c5136b3',
'1810d493',
'7bd80ce7',
'906c28f8',
'8333d6a1',
'32505766',
'0713358a',
'6e9ed0de',
'd51b7656',
'4f7ec762',
'46bb1d0f',
'c13f35f3',
'68fdb146',
'9931da81',
'36b5fd55',
'ec48f952',
'3843a66f',
'0d264bff',
'03a7eeab',
'6a3abefb',
'4d0f37c9',
'cdf368cf',
'1b470305',
'd50b1b51',
'16f50786',
'390a5556',
'91cda347',
'51d0d5d7',
'f1fb9ad6',
'9789b3a0',
'7dc8c3dc',
'27d451df',
'5f5eb210',
'a0e8daee',
'f27c74a3',
'ff147ee0',
'5df94f08',
'5681ce47',
'1368f3f8',
'20f78072',
'3a709c87',
'713ba063',
'a181c826',
'75471a5c',
'3962481d',
'0f7abd48',
'3962481d',
'0f7abd48',
'3962481d',
'39a94c9c',
'a439b852',
'5a1c4fec',
'39a94c9c',
'5a1c4fec',
'39a94c9c',
'3b600818',
'a6ef5eaf',
'f7f5639d',
'5a7acf31',
'f7f5639d',
'5a7acf31',
'c34bb0a6',
'2d16f812',
'd7379edb',
'be6b36fd',
'004a23ce',
'ad913ea4',
'855f4d86',
'b67a9795',
'65a54469',
'855f4d86',
'7a5ab9ac',
'cca75439',
'65a54469',
'91cd69db',
'e1e6abb6',
'd49ed8d2',
'b33483fb',
'69c0ca4b',
'e97ccc7d',
'1a6295fb',
'231482e8',
'e9725478',
'307ffcc1',
'e8ea55c3',
'307ffcc1',
'e8ea55c3',
'5ee4ab3a',
'15e84736',
'7c3e0626',
'c6677d94',
'73d8c366',
'4fe631ca',
'73d8c366',
'd005800f',
'550080e1',
'd005800f',
'550080e1',
'5ad0be38',
'5323ed4b',
'1a8ecc50',
'173e9a63',
'c400c7a4',
'94b646f3',
'9f6d2c50',
'894e7e77',
'1fb49390',
'be26ea0b',
'02e72e9e',
'32ce173a',
'85ccf65c',
'a05cdd5f',
'51e0a24a',
'891806da',
'6621d7df',
'cffe8950',
'935b3a75',
'21aecb86',
'fe524f15',
'398154f3',
'f7cef390',
'f7d0e7b9',
'3430dd9a',
'ba87ca1e',
'8700fb08',
'686ca7de',
'735c08ca',
'783d97a3',
'9ca783ff',
'19506b7d',
'773d93ff',
'a8e4a772',
'e8ba5f7a',
'3db694c0'
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(14,9478,4657,'1380efd0');	// to source check; tile number and CRC32b hash
//
$prepareTileImgBeforeReturn = function($img){
// Заменяет в картинке цвет на прозрачный, требует sudo apt install php-gd 
// На этой карте цвет суши - 255,238,119 или 252,238,116 а населённых пунктов 255,222,98
// Если заменить его на прозрачный, можно наложить
//эту карту на непрозрачные карты суши
$img = setColorsTransparent($img,array(
	array(255,238,119),
	array(252,238,116),
	array(252,222,100),
	array(238,222,98),
	array(255,222,98),
	array(236,223,112),
	array(212,202,100)
));
return array('img'=>$img,'mime_type'=>'image/png');
}; // end function $prepareTileImgBeforeReturn
//

$getURL = function($z,$x,$y,$getURLoptions=array()) {
$url="https://tiles.c-map.com/wmts/maxnp_int1_hrb/webmercator/$z/$x/$y.png";

$userAgent = randomUserAgent();

// Cloudflare
//$baseHeaders = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8\r\nAccept-Encoding: gzip, deflate, br, zstd\r\nAccept-Language: en-US,en;q=0.5\r\nConnection: keep-alive\r\n";
$baseHeaders = "Accept: */*\r\nAccept-Encoding: gzip, deflate, br, zstd\r\nAccept-Language: en-US,en;q=0.9\r\nPragma: no-cache\r\nCache-Control: no-cache\r\nPriority: u=1, i\r\n";
$cookie = "";
//$cookie = "Cookie: OptanonConsent=isGpcEnabled=1&datestamp=Fri+Feb+07+2025+16%3A43%3A00+GMT%2B0300+(%D0%9C%D0%BE%D1%81%D0%BA%D0%B2%D0%B0%2C+%D1%81%D1%82%D0%B0%D0%BD%D0%B4%D0%B0%D1%80%D1%82%D0%BD%D0%BE%D0%B5+%D0%B2%D1%80%D0%B5%D0%BC%D1%8F)&version=202408.1.0&browserGpcFlag=1&isIABGlobal=false&hosts=&consentId=489b5d6d-c570-4d3f-a2f2-e706d9370e1a&interactionCount=1&isAnonUser=1&landingPath=NotLandingPage&groups=C0001%3A1%2CC0003%3A1%2CC0002%3A1%2CC0004%3A1&intType=1&geolocation=%3B&AwaitingReconsent=false; OptanonAlertBoxClosed=2025-02-07T13:06:58.484Z\r\n";
//$header1 = "Sec-Fetch-Dest:	empty\r\nSec-Fetch-Mode: cors\r\nSec-Fetch-Site: same-site\r\nSec-Fetch-User: ?1\r\nSec-GPC: 1\r\nSec-Ch-Ua: \"Chromium\";v=\"128\", \"Not;A=Brand\";v=\"24\", \"Brave\";v=\"128\"\r\nSec-Ch-Ua-Mobile: ?0\r\nSec-Ch-Ua-Platform: \"Windows\"\r\n";
//$header1 = "Sec-Fetch-Dest: empty\r\nSec-Fetch-Mode: cors\r\nSec-Fetch-Site: same-site\r\nSec-Ch-Ua: \"Chromium\";v=\"142\", \"Google Chrome\";v=\"142\", \"Not_A Brand\";v=\"99\"\r\nSec-Ch-Ua-Mobile: ?0\r\nSec-Ch-Ua-Platform: \"Linux\"\r\n";
//$header2 = "Host: tiles.c-map.com\r\n";
//$header3 = "Upgrade-Insecure-Requests: 1\r\n";
$referer = "Referer: https://appchart.c-map.com/\r\nOrigin: https://appchart.c-map.com/\r\n";
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n".$baseHeaders.$referer.$header1.$header2.$header3.$cookie,
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		//'request_fulluri'=>TRUE,
		'protocol_version'=>1.1
	)
);
// set it if you have Tor as proxy, and want change exit node every $tilesPerNode try. https://stackoverflow.com/questions/1969958/how-to-change-the-tor-exit-node-programmatically-to-get-a-new-ip
// tor MUST have in torrc: ControlPort 9051 without authentication: CookieAuthentication 0 and #HashedControlPassword
// Alternative: set own port, config tor password by tor --hash-password my_password and stay password in `echo authenticate '\"\"'`
changeTORnode('C-MAP_raster1');
return array($url,$opts);
}; // end function getURL

?>
