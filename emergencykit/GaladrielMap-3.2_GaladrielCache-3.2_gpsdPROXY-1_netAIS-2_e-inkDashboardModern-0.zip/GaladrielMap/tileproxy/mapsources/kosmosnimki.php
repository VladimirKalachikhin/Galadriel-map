<?php
/* https://kosmosnimki.ru/api/index.html
*/
$humanName = array('ru'=>'Космоснимки kosmosnimki.ru','en'=>'Satellite photos from kosmosnimki.ru');
$ttl = 60*60*24*30*6; //cache timeout in seconds время, через которое тайл считается протухшим. 86400 - сутки
//$ttl = 0; 	// тайлы не протухают никогда
// Время, через которое протухает тайл нулевого размера, обозначающий нерешаемые проблемы скачивания.
$noTileReTry=60*60; 	// empty tile timeout, good if < $ttl sec. 
$ext = 'jpg'; 	// tile image type/extension
$ContentType = 'image/jpeg'; 	// if content type differ then file extension
$minZoom = 3;
$maxZoom = 19;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);

$getURL = function ($z,$x,$y) {
$url='https://maps.kosmosnimki.ru/TileSender.ashx?ModeKey=tile&ftc=osm';
$url .= "&z=$z&x=$x&y=$y";
$url .= '&srs=3857&sw=1&LayerName=4EE5E84381E94E369784464FD41EED5A';
$url .= '&key=N%2BAz7iqqkgEre1TcrZ09kjGG7KYIRZb8VI6E3K5EhXugkv3rRQMm2Zc74w7S1ILttDU%2FouiIm%2FWOsAqBINakRZ55FSl9VV%2FOoPlSFPCKcBs%3D';

$userAgent = randomUserAgent();
$RequestHead='Referer: https://kosmosnimki.ru/static/lib/ImageBitmapLoader-worker.js';
$RequestHead1='Host: maps.kosmosnimki.ru';
$RequestHead2='Origin: https://kosmosnimki.ru';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n$RequestHead\r\n$RequestHead1\r\n$RequestHead2\r\n",
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
return array($url,$opts);
};
?>
