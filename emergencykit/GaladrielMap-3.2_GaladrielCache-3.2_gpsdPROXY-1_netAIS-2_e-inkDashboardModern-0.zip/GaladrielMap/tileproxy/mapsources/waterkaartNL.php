<?php
// Все эти переменные глобальны!
// All of this variables is global!
$humanName = array('ru'=>'Голландия, батиметрия','en'=>'De Waterkaart van Nederland');
$mapDescription = array('ru'=>'<a href="https://waterkaart.net/">waterkaart.net</a>
Только батиметрия, всяких знаков нет. Батиметрия на всё Балтийское море, более-менее правдоподобно.
Однако, там есть суша - какой-то вариант OSM. Отрезать его не представляется возможным.
С другой стороны, там, видимо, есть только изобаты. Но векторные.
','en'=>'<a href="https://waterkaart.net/">waterkaart.net</a>
');
$ttl = 60*60*24*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
//$ttl = 60*60*24*30*12*3; //cache timeout in seconds время, через которое тайл считается протухшим, 3 года, потому что эти суки стали радикально упрощать карты бывших хохляцких территорий
//$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать. OpenTopoMap банит скачивальщиков, поэтому короткое.
$ext = 'png'; 	// tile image type/extension
$minZoom = 0;
$maxZoom = 17;
$data = array('noAutoScaled'=>false);	// не масштабировать графически за пределами максимального и минимального масштабов
// crc32 хеши тайлов, которые не надо сохранять: логотипы, тайлы с дурацкими надписями. '1556c7bd' чистый голубой квадрат 'c7b10d34' чистый голубой квадрат - не мусор! Иначе такие тайлы будут скачиваться снова и снова, а их много.
$trash = array(
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,19796,10302,'bb69e346');	// to source check; tile number and CRC32b hash

$getURLoptions['r'] = pathinfo(__FILE__, PATHINFO_FILENAME);	// $getURLoptions будет передан в $getURL


$getURL = function ($z,$x,$y,$options=array()) {
/*
*/
$url = 'https://waterkaart.live/tiles/tileserver_eu.php?xy=';

//$userAgent = randomUserAgent();
//$RequestHead = "https://waterkaart.net/\r\n";
//$RequestHead='';

$url .= $z."/".$x."/".$y.".png";
$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n$RequestHead",
		//'proxy'=>'tcp://127.0.0.1:8118',
		//'timeout' => 60,
		//'request_fulluri'=>TRUE
	)
);
// set it if you have Tor as proxy, and want change exit node every $tilesPerNode try. https://stackoverflow.com/questions/1969958/how-to-change-the-tor-exit-node-programmatically-to-get-a-new-ip
// tor MUST have in torrc: ControlPort 9051 without authentication: CookieAuthentication 0 and #HashedControlPassword
// Alternative: set own port, config tor password by tor --hash-password my_password and stay password in `echo authenticate '\"\"'`
changeTORnode($getURLoptions['r']);
return array($url,$opts);
};
?>
