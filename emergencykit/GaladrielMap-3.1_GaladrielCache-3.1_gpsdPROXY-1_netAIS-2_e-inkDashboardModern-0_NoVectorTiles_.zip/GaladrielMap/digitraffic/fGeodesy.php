<?php
/*
equirectangularDistance($from,$to)
*/

function equirectangularDistance($sfrom,$sto){
/* https://www.movable-type.co.uk/scripts/latlong.html
Расстояние между двумя точками, выраженными координатами.
Меркатор на сфере
from,to: [lon: xx, lat: xx], degrees
return distanse in meters
*/
//echo "From: "; print_r($sfrom); echo "\n";
//echo "To: "; print_r($sto); echo "\n";
$from['lat'] = $sfrom['lat'] ?: $sfrom['latitude'];	// тернарное выражение
$from['lon'] = ($sfrom['lon'] ?: $sfrom['lng']) ?: $sfrom['longitude'];	// скобки обязательны из-за, ...., PHP8
$to['lat'] = $sto['lat'] ?: $sto['latitude'];
$to['lon'] = ($sto['lon'] ?: $sto['lng']) ?: $sto['longitude'];
//echo "From: "; print_r($from); echo "\n";
//echo "To: "; print_r($to); echo "\n";
if(is_null($from['lat']) or is_null($from['lon']) or is_null($to['lat']) or is_null($to['lon'])) {
	return false;
};

$fi1 = deg2rad($from['lat']);
$fi2 = deg2rad($to['lat']);
$dLambda = deg2rad($to['lon']-$from['lon']);
$R = 6371000;	// метров
$x = $dLambda * cos(($fi1+$fi2)/2);
$y = ($fi2-$fi1);
$d = sqrt($x*$x + $y*$y) * $R;	// метров
return $d;
} // end function equirectangularDistance


?>
