<?php
/* 
https://gdi.bsh.de/mapapps/resources/apps/navigation/index.html?lang=en

Тона глубины
https://gdi.bsh.de/mapservice_gs/NAUTHIS_SkinOfTheEarth/ows?SERVICE=WMS&REQUEST=GetMap&FORMAT=image/png&TRANSPARENT=TRUE&STYLES=,,,,&VERSION=1.3.0&LAYERS=NAUTHIS_SkinOfTheEarth:Approach_Floating_Dock,NAUTHIS_SkinOfTheEarth:Approach_Hulkes_and_Pontoons,NAUTHIS_SkinOfTheEarth:Approach_Land_area,NAUTHIS_SkinOfTheEarth:Approach_Depth_area,NAUTHIS_SkinOfTheEarth:Approach_Dredged_area&WIDTH=1113&HEIGHT=742&CRS=EPSG:4326&BBOX=53.91230742059447,9.668447706034453,55.53965588362411,12.109470400578903
Топографические знаки
https://gdi.bsh.de/mapservice_gs/NAUTHIS_Topography/ows?SERVICE=WMS&REQUEST=GetMap&FORMAT=image/png&TRANSPARENT=TRUE&STYLES=,,,&VERSION=1.3.0&LAYERS=NAUTHIS_Topography:Approach_Landmarks_Silo_Tank_Area,NAUTHIS_Topography:Approach_Landmarks_Silo_Tank,NAUTHIS_Topography:Approach_Landmarks_Landmarks_Point,NAUTHIS_Topography:Approach_Natural_Features_Coastline_and_Shorelineconstuction&WIDTH=1113&HEIGHT=742&CRS=EPSG:4326&BBOX=53.91230742059447,9.668447706034453,55.53965588362411,12.109470400578903
Изобаты
https://gdi.bsh.de/mapservice_gs/NAUTHIS_Hydrography/ows?SERVICE=WMS&REQUEST=GetMap&FORMAT=image/png&TRANSPARENT=TRUE&STYLES=&VERSION=1.3.0&LAYERS=NAUTHIS_Hydrography:Approach_Depths_Depth_Contours&WIDTH=1113&HEIGHT=742&CRS=EPSG:4326&BBOX=53.91230742059447,9.668447706034453,55.53965588362411,12.109470400578903
Навигационные знаки
https://gdi.bsh.de/mapservice_gs/NAUTHIS_AidsAndServices/ows?SERVICE=WMS&REQUEST=GetMap&FORMAT=image/png&TRANSPARENT=TRUE&STYLES=,,,,,,,,,,,,,,,,,,&VERSION=1.3.0&LAYERS=NAUTHIS_AidsAndServices:Berthing_Lateral_Buoys,NAUTHIS_AidsAndServices:Berthing_All_Other_Beacons,NAUTHIS_AidsAndServices:Berthing_Cardinal_Beacons,NAUTHIS_AidsAndServices:Berthing_Lateral_Beacons,NAUTHIS_AidsAndServices:Harbour_Lateral_Buoys,NAUTHIS_AidsAndServices:Harbour_All_Other_Beacons,NAUTHIS_AidsAndServices:Harbour_Cardinal_Beacons,NAUTHIS_AidsAndServices:Harbour_Lateral_Beacons,NAUTHIS_AidsAndServices:Approach_Lateral_Buoys,NAUTHIS_AidsAndServices:Approach_All_Other_Beacons,NAUTHIS_AidsAndServices:Approach_Cardinal_Beacons,NAUTHIS_AidsAndServices:Approach_Lateral_Beacons,NAUTHIS_AidsAndServices:Coastal_Lateral_Buoys,NAUTHIS_AidsAndServices:Coastal_All_Other_Beacons,NAUTHIS_AidsAndServices:Coastal_Cardinal_Beacons,NAUTHIS_AidsAndServices:Coastal_Lateral_Beacons,NAUTHIS_AidsAndServices:General_Cardinal_Buoys,NAUTHIS_AidsAndServices:General_Lateral_Buoys,NAUTHIS_AidsAndServices:General_All_Other_Beacons&WIDTH=1113&HEIGHT=742&CRS=EPSG:4326&BBOX=53.91230742059447,9.668447706034453,55.53965588362411,12.109470400578903
*/
$humanName = array('ru'=>'Германия, морской слой','en'=>'Deutschland ENC layer');
//$ttl = 60*60*24*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
$ttl = 60*60*24*30*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
//$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать.
$ext = 'png'; 	// tile image type/extension
$minZoom = 3;
$maxZoom = 18;
$bounds = array('leftTop'=>array('lat'=>55.2979,'lng'=>5.6552),'rightBottom'=>array('lat'=>53.0272,'lng'=>14.2925));
// crc32 хеши тайлов, которые не надо сохранять: логотипы, тайлы с дурацкими надписями.
$trash = array(
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,17374,10523,'44b0651f',0);	// to source check; tile number and CRC32b hash

$data = array(
);
$mapname = basename(__FILE__, ".php");
$mapTiles = array(
	"$tileCacheServerPath/tiles.php?z={z}&x={x}&y={y}&r=$mapname&options={\"layer\":0}",
	//"$tileCacheServerPath/tiles.php?z={z}&x={x}&y={y}&r=$mapname&options={\"layer\":0,\"prepareTileImg\":true}",
	"$tileCacheServerPath/tiles.php?z={z}&x={x}&y={y}&r=$mapname&options={\"layer\":1}",
	"$tileCacheServerPath/tiles.php?z={z}&x={x}&y={y}&r=$mapname&options={\"layer\":2}",
	"$tileCacheServerPath/tiles.php?z={z}&x={x}&y={y}&r=$mapname&options={\"layer\":3}",
);
$getURLoptions=array();	


$prepareTileImgBeforeReturn = function ($img){
/* 
*/
if(!$img) return array('img'=>$img);
$img = setColorsTransparent($img,array(
	array(255,255,190),
));
return array('img'=>$img);
}; // end function prepareTileImg


$getURL = function ($z,$x,$y,$options=array()) {
/* 
*/
//echo "[getURL] options: "; print_r($options); echo "\n";
if(!isset($options['layer'])) $options['layer'] = 0;	// любой запрос без номера слоя будет запросом к умолчальному слою

$url = 'https://gdi.bsh.de/mapservice_gs';
$layersName = array(
	'/NAUTHIS_SkinOfTheEarth',
	'/NAUTHIS_Hydrography',
	'/NAUTHIS_Topography',
	'/NAUTHIS_AidsAndServices',
);
$url .= $layersName[$options['layer']];
$url .= '/ows?SERVICE=WMS&REQUEST=GetMap&FORMAT=image/png&TRANSPARENT=TRUE&STYLES=&VERSION=1.3.0';
$layersParm = array(
	//'&LAYERS=NAUTHIS_SkinOfTheEarth:Approach_Floating_Dock,NAUTHIS_SkinOfTheEarth:Approach_Hulkes_and_Pontoons,NAUTHIS_SkinOfTheEarth:Approach_Land_area,NAUTHIS_SkinOfTheEarth:Approach_Depth_area,NAUTHIS_SkinOfTheEarth:Approach_Dredged_area',
	'&LAYERS=NAUTHIS_SkinOfTheEarth:Approach_Floating_Dock,NAUTHIS_SkinOfTheEarth:Approach_Hulkes_and_Pontoons,NAUTHIS_SkinOfTheEarth:Approach_Depth_area,NAUTHIS_SkinOfTheEarth:Approach_Dredged_area',
	'&LAYERS=NAUTHIS_Hydrography:Approach_Depths_Depth_Contours',
	'&LAYERS=NAUTHIS_Topography:Approach_Landmarks_Silo_Tank_Area,NAUTHIS_Topography:Approach_Landmarks_Silo_Tank,NAUTHIS_Topography:Approach_Landmarks_Landmarks_Point,NAUTHIS_Topography:Approach_Natural_Features_Coastline_and_Shorelineconstuction',
	'&LAYERS=NAUTHIS_AidsAndServices:Berthing_Lateral_Buoys,NAUTHIS_AidsAndServices:Berthing_All_Other_Beacons,NAUTHIS_AidsAndServices:Berthing_Cardinal_Beacons,NAUTHIS_AidsAndServices:Berthing_Lateral_Beacons,NAUTHIS_AidsAndServices:Harbour_Lateral_Buoys,NAUTHIS_AidsAndServices:Harbour_All_Other_Beacons,NAUTHIS_AidsAndServices:Harbour_Cardinal_Beacons,NAUTHIS_AidsAndServices:Harbour_Lateral_Beacons,NAUTHIS_AidsAndServices:Approach_Lateral_Buoys,NAUTHIS_AidsAndServices:Approach_All_Other_Beacons,NAUTHIS_AidsAndServices:Approach_Cardinal_Beacons,NAUTHIS_AidsAndServices:Approach_Lateral_Beacons,NAUTHIS_AidsAndServices:Coastal_Lateral_Buoys,NAUTHIS_AidsAndServices:Coastal_All_Other_Beacons,NAUTHIS_AidsAndServices:Coastal_Cardinal_Beacons,NAUTHIS_AidsAndServices:Coastal_Lateral_Beacons,NAUTHIS_AidsAndServices:General_Cardinal_Buoys,NAUTHIS_AidsAndServices:General_Lateral_Buoys,NAUTHIS_AidsAndServices:General_All_Other_Beacons'
);
$url .= $layersParm[$options['layer']];
$url .= '&CRS=EPSG:3857';

//$userAgent = randomUserAgent();
//$RequestHead='Referer: ';
$RequestHead='';

/*/ Один тайл
$leftTop = tileNum2ord($z,$x,$y);	// fcommon.php
$rightBottom = tileNum2ord($z,$x+1,$y+1);
$url .= '&WIDTH=256&HEIGHT=256';
/*/
// 5х3 от середины
$leftTop = tileNum2ord($z,$x-2,$y-1);	// 5х3 fcommon.php
$rightBottom = tileNum2ord($z,$x+3,$y+2);
$url .= '&WIDTH=1280&HEIGHT=768';
//
$url .= "&BBOX={$leftTop['x']},{$rightBottom['y']},{$rightBottom['x']},{$leftTop['y']}";

$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>$proxy,
		//'timeout' => 30,
		'request_fulluri'=>true,
		//'protocol_version'=>1.1
	)
);
//print_r($opts);

return array($url,$opts);
};	// end function getURL


$putTile = function ($mapName,$imgArray,$trueTile=array(),$options=array()){
/* Custom storage to file procedure.
We get a large picture, and we have to cut it into standard tiles before saving it.
Let's use the functions from fTilesStorage.php
*/
if(!isset($options['layer'])) $options['layer'] = 0;	// любой запрос без номера слоя будет запросом к умолчальному слою
list($z,$x,$y,$ext,$originalImg) = requestedTileInfo($imgArray);	// просто первый элемент $imgArray
//echo "Для сохранения получен файл размером ".(strlen($originalImg))." байт\n";
if($originalImg){	// received file may be a null if unsuccessful
	// Split image to tiles
	$imgs = splitToTiles($originalImg,$z,$x-2,$y-1,$ext);	// 5х3 от середины
	//$imgs = splitToTiles($originalImg,$z,$x,$y,$ext);	// один тайл
	// After split, the requested tile may not be the first in the array.
	$imgs = requestedTileFirst($z,$x,$y,$ext,$imgs);	// Stay the requested tile first in array
}
else {
	$imgs = $imgArray;
};
$res = putTileToFile($mapName,$imgs,$trueTile,$options);
return $res;
}; // end function putTile


$getTile = function ($r,$z,$x,$y,$options=array()){
// Не будем показывать всякие знаки на мелких масштабах, только тон и изобары
if(($z<12) and ($options['layer']>1)) return array('img'=>null);
return getTileFromFile($r,$z,$x,$y,$options);
}; // end function getTile
?>
