<?php
/* https://freenauticalchart.net/ 
https://freenauticalchart.net/download/
*/
$humanName = array('ru'=>'Германия, морская бумажная карта','en'=>'Deutschland nautical paper chart');
$ttl = 60*60*24*30*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 7;
$maxZoom = 19;
$bounds = array('leftTop'=>array('lat'=>55.9277,'lng'=>3.3316),'rightBottom'=>array('lat'=>53.0272,'lng'=>14.4058));
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,17374,10523,'0a1e0c2a');	// to source check; tile number and CRC32b hash

$getURL = function ($z,$x,$y) {
/**/
//$userAgent = randomUserAgent();
//$RequestHead='';

$url = 'https://freenauticalchart.net/qmap-de';
$url .= "/".$z."/".$x."/".$y.".png";
$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		//'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
return array($url,$opts);
};
?>
