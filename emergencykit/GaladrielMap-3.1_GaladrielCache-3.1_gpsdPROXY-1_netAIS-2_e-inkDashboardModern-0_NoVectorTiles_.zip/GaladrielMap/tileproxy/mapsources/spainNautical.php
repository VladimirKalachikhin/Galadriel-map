<?php
/* https://ideihm.covam.es/visualizador/inicio
https://ideihm.covam.es/encwms?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&FORMAT=image%2Fpng&TRANSPARENT=true&LAYERS=ENC&STYLES=&CRS=EPSG%3A3857&WIDTH=1112&HEIGHT=676&BBOX=-627458.0321633162%2C4296814.27656205%2C-615697.3806789538%2C4303963.737356501&_=undefined
*/
$humanName = array('ru'=>'Морская карта Испании','en'=>'Spain. Marine map');
//$ttl = 60*60*24*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
$ttl = 60*60*24*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
//$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать. OpenTopoMap банит скачивальщиков, поэтому короткое.
$ext = 'png'; 	// tile image type/extension
$minZoom = 4;
$maxZoom = 16;
$bounds = array('leftTop'=>array('lat'=>47.0,'lng'=>-21.0),'rightBottom'=>array('lat'=>19.3,'lng'=>6.3));
// crc32 хеши тайлов, которые не надо сохранять: логотипы, тайлы с дурацкими надписями. '1556c7bd' чистый голубой квадрат 'c7b10d34' чистый голубой квадрат - не мусор! Иначе такие тайлы будут скачиваться снова и снова, а их много.
$trash = array(
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(14,7936,6433,'2031b74a');	// to source check; tile number and CRC32b hash. Oslo

$getURL = function ($z,$x,$y) {
/* */
$url = 'https://ideihm.covam.es/encwms?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap&FORMAT=image%2Fpng&TRANSPARENT=true&LAYERS=ENC&STYLES=&CRS=EPSG%3A3857';

$userAgent = randomUserAgent();
$RequestHead='Referer: https://ideihm.covam.es/visualizador/inicio';
//$RequestHead='';

//$leftTop = tileNum2ord($z,$x,$y);	// fcommon.php
//$rightBottom = tileNum2ord($z,$x+1,$y+1);
//$url .= '&WIDTH=256&HEIGHT=256';
// 5х3 от середины
$leftTop = tileNum2ord($z,$x-2,$y-1);	// 5х3 fcommon.php
$rightBottom = tileNum2ord($z,$x+3,$y+2);
$url .= '&WIDTH=1280&HEIGHT=768';
$url .= "&BBOX={$leftTop['x']}%2C{$rightBottom['y']}%2C{$rightBottom['x']}%2C{$leftTop['y']}";
$url .= '&_=undefined';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE,
		'protocol_version'=>1.1
	)
);
//print_r($opts);
// set it if you have Tor as proxy, and want change exit node every $tilesPerNode try. https://stackoverflow.com/questions/1969958/how-to-change-the-tor-exit-node-programmatically-to-get-a-new-ip
// tor MUST have in torrc: ControlPort 9051 without authentication: CookieAuthentication 0 and #HashedControlPassword
// Alternative: set own port, config tor password by tor --hash-password my_password and stay password in `echo authenticate '\"\"'`
changeTORnode($getURLoptions['spainNautical']);

return array($url,$opts);
};
//

$putTile = function ($mapName,$imgArray,$trueTile=array(),$options=array()){
/* Custom storage to file procedure.
We get a large picture, and we have to cut it into standard tiles before saving it.
Let's use the functions from fTilesStorage.php
*/
list($z,$x,$y,$ext,$originalImg) = requestedTileInfo($imgArray);	// просто первый элемент $imgArray
if($originalImg){	// received file may be a null if unsuccessful
	// Split image to tiles
	$imgs = splitToTiles($originalImg,$z,$x-2,$y-1,$ext);	// 5х3 от середины
	//$imgs = splitToTiles($originalImg,$z,$x,$y,$ext);
	// After split, the requested tile may not be the first in the array.
	$imgs = requestedTileFirst($z,$x,$y,$ext,$imgs);	// Stay the requested tile first in array
}
else {
	$imgs = $imgArray;
};
$res = putTileToFile($mapName,$imgs,$trueTile,$options);
return $res;
}; // end function putTile
?>
