<?php
$gpsdProxyHost = '0.0.0.0';
$gpsdProxyPort = 3839;
$masterSock = createSocketServer($gpsdProxyHost,$gpsdProxyPort,20); 	// Соединение для приёма клиентов, входное соединение
$sockets = array(); 	// список функционирующих сокетов
$messages = array(); 	// 
$socksRead = array(); $socksWrite = array(); $socksError = array(); 	// массивы для изменивших состояние сокетов (с учётом, что они в socket_select() по ссылке, и NULL прямо указать нельзя)
$greeting = '{"class":"VERSION","release":"gpsdPROXY_0","rev":"beta","proto_major":3,"proto_minor":0}';
echo "gpsdPROXY ready to connection on $gpsdProxyHost:$gpsdProxyPort\n";
$SocketTimeout = null;
do {
	$socksRead = $sockets; 	// мы собираемся читать все сокеты
	$socksRead[] = $masterSock; 	// 
	$socksWrite = array(); 	// очистим массив 
	foreach($messages as $n => $data){ 	// пишем только в сокеты, полученные от masterSock путём socket_accept
		if($data['output'])	$socksWrite[] = $sockets[$n]; 	// если есть, что писать -- добавим этот сокет в те, в которые будем писать
	}
	//print_r($socksRead);
	$socksError = $sockets; 	// 
	$socksError[] = $masterSock; 	// 

	$num_changed_sockets = socket_select($socksRead, $socksWrite, $socksError, null); 	// должно ждать

	//echo "\n Пишем в сокеты ".count($socksWrite)."\n"; //////////////////
	// Здесь пишется в сокеты то, что попало в $messages на предыдущем обороте. Тогда соответствующие сокеты проверены на готовность, и готовые попали в $socksWrite. 
	// в ['output'] всегда текст или массив из текста [0] и параметров передачи (для websocket)
	foreach($socksWrite as $socket){
		$n = array_search($socket,$sockets);	// 
		foreach($messages[$n]['output'] as &$msg) { 	// все накопленные сообщения. & для экономии памяти, но что-то не экономится...
			//echo "to $n:\n|$msg|\n";
			$msgParams = null;
			if(is_array($msg)) list($msg,$msgParams) = $msg;	// второй элемент -- тип фрейма
			switch($messages[$n]['protocol']){
			case 'WS':
				$msg = wsEncode($msg,$msgParams);	
				break;
			case 'WS handshake':
				$messages[$n]['protocol'] = 'WS';
			}
			
			$msgLen = strlen($msg);
			$res = socket_write($socket, $msg, $msgLen);
			if($res === FALSE) { 	// клиент умер
				echo "\n\nFailed to write data to socket by: " . socket_strerror(socket_last_error($sock)) . "\n";
				//chkSocks($socket);
				continue 3;	// к следующему сокету
			}
			elseif($res <> $msgLen){	// клиент не принял всё. У него проблемы?
				echo "\n\nNot all data was writed to socket by: " . socket_strerror(socket_last_error($sock)) . "\n";
				//chkSocks($socket);
				continue 3;	// к следующему сокету
			}
			//$lastClientExchange = time();
		}
		$messages[$n]['output'] = array();
		unset($msg);
	}

	//echo "\n Читаем из сокетов ".count($socksRead)."\n"; ///////////////////////
	foreach($socksRead as $socket){
		if($socket == $masterSock) { 	// новое подключение
			$sock = socket_accept($socket); 	// новый сокет для подключившегося клиента
			if(!$sock or (get_resource_type($sock) != 'Socket')) {
				echo "Failed to accept incoming by: " . socket_strerror(socket_last_error($socket)) . "\n";
				//chkSocks($socket); 	// recreate masterSock
				continue;
			}
			$sockets[] = $sock; 	// добавим новое входное подключение к имеющимся соединениям
			$sockKey = array_search($sock,$sockets);	// Resource id не может быть ключём массива, поэтому используем порядковый номер. Что стрёмно.
			echo "New client connected: $sock with key $sockKey!                                                      \n";
		    continue; 	// 
		}
		// Читаем сокет
		$sockKey = array_search($socket,$sockets); 	// 
		socket_clear_error($socket);
		if($messages[$sockKey]['protocol']=='WS'){ 	// с этим сокетом уже общаемся по протоколу websocket
			$buf = socket_read($socket, 65536,  PHP_BINARY_READ); 	// читаем до 1MB
		}
		else {
			$buf = socket_read($socket, 2048, PHP_NORMAL_READ); 	// читаем построчно
			// строки могут разделяться как \n, так и \r\n, но при PHP_NORMAL_READ reading stops at \n or \r, соотвественно, сперва строка заканчивается на \r, а после следующего чтения - на \r\n, и только тогда можно заменить
			if($buf[-1]=="\n") $buf = trim($buf)."\n";
			else $buf = trim($buf);
		}
		if($buf) $messages[$sockKey]['zerocnt'] = 0;
		else $messages[$sockKey]['zerocnt']++;
		if($messages[$sockKey]['zerocnt']>3){
			echo "\n\nTo many empty strings from socket $sockKey $socket \n"; 	// бывает, клиент умер, а сокет -- нет. Тогда из него читается пусто.
			//echo "Close client socket #$n type ".gettype($socket)." by error or by life                    \n";
			//chkSocks($socket);
		    //continue;	// к следующему сокету
		    echo "socksRead:"; print_r($socksRead);
		    echo "sockets:"; print_r($sockets);
	    	$n = array_search($socket,$sockets);	// 
			unset($sockets[$n]);
		    socket_close($socket); 	// он может быть уже закрыт
		    //exit;
		    continue;
		}
		
		//echo "\nПРИНЯТО ОТ КЛИЕНТА $sockKey ".strlen($buf)." байт\n";
		//print_r($messages[$sockKey]);
		if($messages[$sockKey]['greeting']===TRUE){ 	// с этим сокетом уже беседуем, значит -- пришли данные	
			switch($messages[$sockKey]['protocol']){
			case 'WS':	// ответ за запрос через websocket, здесь нет конца передачи, посылается сколько-то фреймов.
				echo "\nПРИНЯТО  из вебсокета ОТ КЛИЕНТА $sockKey $socket ".strlen($buf)." байт\n";
				//print_r(wsDecode($buf));
				// бывают склеенные и неполные фреймы
				// там может быть: 1) неполный фрейм; 2) сколько-то полных фреймов, и, возможно, неполный
				// но нет полного сообщения; 3) завершение сообщения, плюс что-то ещё; 4) полное сообщение,
				// плюс, возможно, что-то ещё
				$n = 0;
				do{	// выделим из полученного полные фреймы
					$n++;
					if($messages[$sockKey]['FIN']=='partFrame') {
						echo "предыдущий фрейм был неполный, к имеющимся ".strlen($messages[$sockKey]['partFrame'])." байт добавлено полученные ".strlen($buf)." байт, получилось ".(strlen($messages[$sockKey]['partFrame'])+strlen($buf))." байт $n \n";
						$buf = $messages[$sockKey]['partFrame'].$buf;	
					}
					
					$res = wsDecode($buf);
					if($res == FALSE){
						echo "Bufer decode fails, will close websocket\n";
						//chkSocks($socket);	// закроет сокет
						continue 3;	// к следующему сокету						
					}
					else list($decodedData,$type,$FIN,$tail) = $res;

					$messages[$sockKey]['FIN'] = $FIN;
					if($type) {	// это первый фрейм
						$messages[$sockKey]['frameType'] = $type;
						echo "Первый фрейм принят $n\n";
					}
					switch($FIN){
					case 'messageComplete':	// СООБЩЕНИЕ ПРИНЯТО: в буфере последний фрейм сообщения -- полностью, он имеет тип $messages[$sockKey]['frameType'] и декодирован в $decodedData. Возможно, есть ещё полные или неполные фреймы, они находятся в $tail и не декодированы
						$buf = $tail;	// возможно, там ещё есть полные фреймы

						echo "Сообщение принято $n \n";
						if($type) echo "в одном фрейме\n";
						if($buf) {	// есть уже следующее сообщение
							echo "однако, в буфере ".strlen($buf)." байт \n";
						}

						switch($messages[$sockKey]['frameType']){
						case 'text':	// требуемое
							$messages[$sockKey]['inBuf'] .= $decodedData;	// 
							echo "Принято текстовое сообщение длиной ".strlen($messages[$sockKey]['inBuf'])." байт\n";
							//echo "decoded data={$messages[$sockKey]['inBuf']};\n";
							$messages[$sockKey]['inBufS'][] = $messages[$sockKey]['inBuf'];	// всегда для websockets будем складывать сообщения в массив
							$messages[$sockKey]['inBuf'] = '';
							$messages[$sockKey]['partFrame'] = '';
							break;
						case 'close':
							//chkSocks($socket);	// закроет сокет
							continue 5;	// к следующему сокету
						case 'binary':
						case 'ping':
						case 'pong':
						default:
							echo "A frame of type '$type' was dropped $n                              \n";
							if($decodedData === null){
								echo "Frame decode fails, will close websocket\n";
								//chkSocks($socket);	// закроет сокет
								continue 5;	// к следующему сокету
							}
						}
						//echo "type={$messages[$sockKey]['frameType']}; FIN=$FIN;n=$n; tail:|$tail|\n";
						break;
					case 'partFrame':	// в буфере -- неполный фрейм, он не декодирован ($decodedData==null) и возвращён в $tail
						echo "Принят неполный фрейм типа $type, размером ".strlen($tail)." байт $n\n";
						$messages[$sockKey]['partFrame'] = $tail;	// я присоединяю перед декодированием
						continue 4;	// к следующему сокету
					default:	// непоследний фрейм сообщения полностью, и, возможно, что-то ещё
						echo "Собираем сообщение типа {$messages[$sockKey]['frameType']}, декодировано ".strlen($decodedData)." байт $n\n";
						$messages[$sockKey]['inBuf'] .= $decodedData;	// собираем сообщение
						$buf = $tail;	// для декодирования на следующем обороте ближайшего do
					}
				}while($buf);	// выбрали полные фреймы, в $tail -- неполный
				if(!$tail) $messages[$sockKey]['inBuf'] = '';

				$buf = $messages[$sockKey]['inBufS'];
				//echo "Принято от websocket'а:"; print_r($buf);
				if(!$buf) continue 2;	// к следующему сокету
				break;	// case protocol WS
			} // end switch protocol
		}
		else{ 	// с этим сокетом ещё не беседовали, значит, пришёл заголовок или команда gpsd или ничего, если сокет просто открыли
			// разберёмся с заголовком
			if(!isset($messages[$sockKey]['inBuf'])) $messages[$sockKey]['inBuf'] = '';
			$messages[$sockKey]['inBuf'] .= "$buf";	// собираем заголовок
			//echo "Собрано:|{$messages[$sockKey]['inBuf']}|";
			if(substr($messages[$sockKey]['inBuf'],-2)=="\n\n"){	// конец заголовков (и вообще сообщения) -- пустая строка
				//echo "Заголовок: |{$messages[$sockKey]['inBuf']}|\n";
				$messages[$sockKey]['inBuf'] = explode("\n",$messages[$sockKey]['inBuf']);
				foreach($messages[$sockKey]['inBuf'] as $msg){	// поищем в заголовке
					$msg = explode(':',$msg,2);
					array_walk($msg,function(&$str,$key){$str=trim($str);});
					if($msg[0]=='Sec-WebSocket-Key'){
						$SecWebSocketAccept = base64_encode(pack('H*',sha1($msg[1].'258EAFA5-E914-47DA-95CA-C5AB0DC85B11')));	// https://datatracker.ietf.org/doc/html/rfc6455#section-1.2 https://habr.com/ru/post/209864/
					}
					elseif($msg[0]=='Upgrade' and $msg[1]=='websocket') $messages[$sockKey]['protocol'] = 'WS handshake';	// это запрос на общение по websocket
				}
				// определился протокол
				switch($messages[$sockKey]['protocol']){
				case 'WS handshake':	// ответ за запрос через websocket, в минимальной форме, иначе Chrom не понимает
					$SecWebSocketAccept = 
						"HTTP/1.1 101 Switching Protocols\r\n"
						."Upgrade: websocket\r\n"
						."Connection: Upgrade\r\n"
						."Sec-WebSocket-Accept: ".$SecWebSocketAccept."\r\n"
						."\r\n";			
					//echo "SecWebSocketAccept=$SecWebSocketAccept;\n";
					//echo "header sockKey=$sockKey;\n";
					$messages[$sockKey]['output'] = array($SecWebSocketAccept,$greeting);	// 
					$messages[$sockKey]['inBufS'] = array();	// для websocket будет ещё и буфер сообщений
					break;
				default:	// ответ вообще в сокет, как это для протокола gpsd
					$messages[$sockKey]['output'][] = $greeting."\r\n\r\n";	// приветствие gpsd
				}
				//echo "sockKey=$sockKey;\n";
				$messages[$sockKey]['greeting']=TRUE;
				$messages[$sockKey]['inBuf'] = '';					
			}
			//else continue;	// продолжаем собирать заголовок
			continue;	// к следующему сокету
		}
		
		// выделим команду и параметры
/*
		if(is_array($buf)){
			foreach($buf as $message){
				//echo "$message\n";
			}
		}
		//else echo "buf=|$buf|\n";
*/
		echo "Записываем в файл \n";
		file_put_contents('input.text',$buf);

//							else $messages[$sockKey]['inBuf'] .= rtrim($decodedData,';').';';	// придётся разделять сообщения ;,полагая, что это команда gpsd
//					if(strlen($buf)==1) $buf = '';	// ;


		
	}
} while (true);





function wsDecode($data){
/* Возвращает:
$decodedData данные или null если фрейм принят не полностью и нечего декодировать, или 
false -- что-то пошло не так, непонятно, что делать
$type тип данных или null, если данные в нескольких фреймах, и это не первый фрейм
$FIN признак последнего фрейма (TRUE) или FALSE, если фрейм не последний
$tail один или несколько склееных фреймов, оставшихся после выделения первого
*/
$decodedData = null; $tail = null; $FIN = null;

// estimate frame type:
$firstByteBinary = sprintf('%08b', ord($data[0])); 	// преобразование первого байта в битовую строку
$secondByteBinary = sprintf('%08b', ord($data[1])); 	// преобразование второго байта в битовую строку
$opcode = bindec(substr($firstByteBinary, 4, 4));	// последние четыре бита первого байта -- в десятичное число из текста
$payloadLength = ord($data[1]) & 127;	// берём как число последние семь бит второго байта

$isMasked = $secondByteBinary[0] == '1';	// первый бит второго байта -- из текстового представления.
if($firstByteBinary[0] == '1') $FIN = 'messageComplete';


switch ($opcode) {
case 1:	// text frame:
	$type = 'text';
	break;
case 2:
	$type = 'binary';
	break;
case 8:	// connection close frame
	$type = 'close';
	break;
case 9:	// ping frame
	$type = 'ping';
	break;
case 10:	// pong frame
	$type = 'pong';
	break;
default:
	$type = null;
}

if ($payloadLength === 126) {
	if (strlen($data) < 4) return false;
	$mask = substr($data, 4, 4);
	$payloadOffset = 8;
	$dataLength = bindec(sprintf('%08b', ord($data[2])) . sprintf('%08b', ord($data[3]))) + $payloadOffset;
} 
elseif ($payloadLength === 127) {
	if (strlen($data) < 10) return false;
	$mask = substr($data, 10, 4);
	$payloadOffset = 14;
	$tmp = '';
	for ($i = 0; $i < 8; $i++) {
		$tmp .= sprintf('%08b', ord($data[$i + 2]));
	}
	$dataLength = bindec($tmp) + $payloadOffset;
	unset($tmp);
} 
else {
	$mask = substr($data, 2, 4);
	$payloadOffset = 6;
	$dataLength = $payloadLength + $payloadOffset;
}

/**
 * We have to check for large frames here. socket_recv cuts at 1024 (65536 65550?) bytes
 * so if websocket-frame is > 1024 bytes we have to wait until whole
 * data is transferd.
 */
//echo "strlen(data)=".strlen($data)."; dataLength=$dataLength;\n";
if (strlen($data) < $dataLength) {
	echo "\nwsDecode: recievd ".strlen($data)." byte, but frame length $dataLength byte.\n";
	$FIN = 'partFrame';
	$tail = $data;
}
else {
	$tail = substr($data,$dataLength);

	if($isMasked) {
		echo "wsDecode: unmasking \n";
		$unmaskedPayload = ''; 
		for ($i = $payloadOffset; $i < $dataLength; $i++) {
			$j = $i - $payloadOffset;
			if (isset($data[$i])) {
				$unmaskedPayload .= $data[$i] ^ $mask[$j % 4];
			}
		}
		$decodedData = $unmaskedPayload;
	} 
	else {
		$payloadOffset = $payloadOffset - 4;
		$decodedData = substr($data, $payloadOffset);
	}
}

return array($decodedData,$type,$FIN,$tail);
} // end function wsDecode

function wsEncode($payload, $type = 'text', $masked = false){
/* https://habr.com/ru/post/209864/ 
Кодирует $payload как один фрейм
*/
if(!$type) $type = 'text';
$frameHead = array();
$payloadLength = strlen($payload);

switch ($type) {
case 'text':    // first byte indicates FIN, Text-Frame (10000001):
    $frameHead[0] = 129;
    break;
case 'close':    // first byte indicates FIN, Close Frame(10001000):
    $frameHead[0] = 136;
    break;
case 'ping':    // first byte indicates FIN, Ping frame (10001001):
    $frameHead[0] = 137;
    break;
case 'pong':    // first byte indicates FIN, Pong frame (10001010):
    $frameHead[0] = 138;
    break;
}

// set mask and payload length (using 1, 3 or 9 bytes)
if ($payloadLength > 65535) {
    $payloadLengthBin = str_split(sprintf('%064b', $payloadLength), 8);
    $frameHead[1] = ($masked === true) ? 255 : 127;
    for ($i = 0; $i < 8; $i++) {
        $frameHead[$i + 2] = bindec($payloadLengthBin[$i]);
    }
    // most significant bit MUST be 0
    if ($frameHead[2] > 127) {
        return array('type' => '', 'payload' => '', 'error' => 'frame too large (1004)');
    }
} 
elseif ($payloadLength > 125) {
    $payloadLengthBin = str_split(sprintf('%016b', $payloadLength), 8);
    $frameHead[1] = ($masked === true) ? 254 : 126;
    $frameHead[2] = bindec($payloadLengthBin[0]);
    $frameHead[3] = bindec($payloadLengthBin[1]);
} 
else {
    $frameHead[1] = ($masked === true) ? $payloadLength + 128 : $payloadLength;
}

// convert frame-head to string:
foreach (array_keys($frameHead) as $i) {
    $frameHead[$i] = chr($frameHead[$i]);
}
if ($masked === true) {
    // generate a random mask:
    $mask = array();
    for ($i = 0; $i < 4; $i++) {
        $mask[$i] = chr(rand(0, 255));
    }

    $frameHead = array_merge($frameHead, $mask);
}
$frame = implode('', $frameHead);

// append payload to frame:
for ($i = 0; $i < $payloadLength; $i++) {
    $frame .= ($masked === true) ? $payload[$i] ^ $mask[$i % 4] : $payload[$i];
}

return $frame;
} // end function wsEncode







function createSocketServer($host,$port,$connections=2){
/* создаёт сокет, соединенный с $host,$port на своей машине, для приёма входящих соединений 
в Ubuntu $connections = 0 означает максимально возможное количество соединений, а в Raspbian (Debian?) действительно 0
*/
$sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if(!$sock) {
	echo "Failed to create server socket by reason: " . socket_strerror(socket_last_error()) . "\n";
	//return FALSE;
	exit('1');
}
for($i=0;$i<100;$i++) {
	$res = @socket_bind($sock, $host, $port);
	if(!$res) {
		echo "Failed to binding to $host:$port by: " . socket_strerror(socket_last_error($sock)) . ", waiting $i\r";
		sleep(1);
	}
	else break;
}
if(!$res) {
	echo "Failed to binding to $host:$port by: " . socket_strerror(socket_last_error($sock)) . "\n";
	//return FALSE;
	exit('1');
}
$res = socket_listen($sock,$connections); 	// 
if(!$res) {
	echo "Failed listennig by: " . socket_strerror(socket_last_error($sock)) . "\n";
	//return FALSE;
	exit('1');
}
//socket_set_nonblock($sock); 	// подразумевается, что изменений в сокете всегда ждём в socket_select
return $sock;
} // end function createSocketServer


function createSocketClient($host,$port){
/* создаёт сокет, соединенный с $host,$port на другом компьютере */
$sock = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
if(!$sock) {
	echo "Failed to create client socket by reason: " . socket_strerror(socket_last_error()) . "\n";
	return FALSE;
	//exit('1');
}
if(! @socket_connect($sock,$host,$port)){ 	// подключаемся к серверу
	echo "Failed to connect to remote server $host:$port by reason: " . socket_strerror(socket_last_error()) . "\n";
	return FALSE;
	//exit('1');
}
echo "Connected to $host:$port\n";
//$res = socket_write($socket, "\n");
return $sock;
} // end function createSocketClient




?>
