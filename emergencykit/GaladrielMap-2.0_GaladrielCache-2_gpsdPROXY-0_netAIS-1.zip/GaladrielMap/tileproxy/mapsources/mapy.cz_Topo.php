<?php
$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, один год
//$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, пол-года
// $ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$ContentType = 'image/png'; 	// if content type differ then file extension
$minZoom = 0;
$maxZoom = 19;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
//'3df36e26' 	// чистый голубой квадрат
);
$functionGetURL = <<<'EOFU'
function getURL($z,$x,$y) {
$url = 'https://mapserver.mapy.cz/turist-en/';
$url .= "$z-$x-$y";
return $url;
}
EOFU;
?>
