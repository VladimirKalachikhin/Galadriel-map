<?php
/*
*/
require('BSH_common');
$getURLparams = array(
'map'=>'NAUTHIS_AidsAndServices',
'layers'=>'11,13,14,15,20,34,35,36,41,53,55,56,57,74,76,77,78,83,97,98,99,116,118,119,120',
'bgcolor'=>'0xFFFFFF' 
);

?>
