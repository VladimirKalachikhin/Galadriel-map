По-русски ниже.
It does not work on Windows!
This contains complete and configured GaladrielMap and GaladrielCache wit local AIS & netAIS support.
BUT EXCEPTION!: You must update /GaladrielMap/netAIS/params.php to you actual .onion address from TOR 'hostname' file, for example:
# cat /var/lib/tor/hidden_service_netAIS/hostname
in Ubuntu, see torrc config file. Without this, you will not be able to open you private netAIS group. But be able to connect to others.

Place GaladrielMap directory from zip to root filesystem:
unzip GaladrielMap-2.0_GaladrielCache-2_gpsdPROXY-0_netAIS-1.zip "GaladrielMap/*" -d /
Set owner, if you want:
chown -hR :www-data /GaladrielMap
Set write rights to tiles directory if it is necessary:
$ chmod 775 /GaladrielMap/tileproxy/tiles
Also set write rights to directories:
$ chmod 775 /GaladrielMap/tileproxy/loaderJobs
$ chmod 775 /GaladrielMap/netAIS/data
$ chmod 775 /GaladrielMap/netAIS/server

And update web server configuration:
Apache configuration contains in apache2_galadrielmap.conf Manual inside.
Nginx configuration contains in nginx_galadrielmap_conf Manual also inside.
TOR configuration is torrc. Update paths inside!

Apache more, more simply to configuration, and has excellent performance. Use it!
Apache configuration:
Copy GaladrielMap config to Apache sites configs dir:
sudo unzip GaladrielMap-1.4_GaladrielCache-2.3_gpsdAISd-1.0_netAIS-0.0.zip "apache2_galadrielmap.conf" -d /etc/apache2/sites-available/
Create symlink to enable:
sudo ln -s /etc/apache2/sites-available/apache2_galadrielmap.conf /etc/apache2/sites-enabled/apache2_galadrielmap.conf
Restart apache:
sudo service apache2 restart

Now set up vehicle info in /GaladrielMap/netAIS/boatInfo.ini




Архив содержит полный набор файлов GaladrielMap и GaladrielCache с поддержкой AIS и netAIS, сконфигурированных и готовых к использованию.
За исключением! Нужно указать фактически получившийся после конфигурации скрытого сервиса tor .onion адрес в /GaladrielMap/netAIS/params.php
Адрес находится в файле hostname, расположенном по пути, указанном в файле конфигурации tor torrc. В Ubuntu это 
# cat /var/lib/tor/hidden_service_netAIS/hostname
при использовании приложенного файла torrc.
Если не указать ваш .onion адрес в /GaladrielMap/netAIS/params.php, то нельзя будет организовать собственную группу netAIS. Но подключиться к другим -- можно.

Предполагается, что каталог GaladrielMap расположен в корне файловой системы:
unzip GaladrielMap-2.0_GaladrielCache-2_gpsdPROXY-0_netAIS-1.zip "GaladrielMap/*" -d /
Установите владельца, если нужно (нужно в полноценных системах):
chown -hR :www-data /GaladrielMap
Не забудьте дать права на запись в каталог, куда будут складываться тайлы:
$ chmod 777 /GaladrielMap/tileproxy/tiles
, а также на каталоги
$ chmod 777 /GaladrielMap/map/track
$ chmod -R 775 /GaladrielMap/tileproxy/loaderJobs
$ chmod -R 775 /GaladrielMap/netAIS/data
$ chmod 775 /GaladrielMap/netAIS/server

apache2_galadrielmap.conf - конфигурация для сервера Apache. Внутри файла есть инструкция.
Каталог nginx_galadrielmap_conf - конфигурация для сервера Nginx. Инструкция тоже есть.
Конфигурация tor -- torrc. Возможно, потребуется поменять пути в соответствии с установкой tor.

Разумеется, сервер не может быть под управлением Windows. 
Если есть возможность выбора веб-сервера - всегда используйте Apache. Настройка Nginx требует лишних знаний и с первого раза не получится. И оно того не стоит.
Настройка Apache:
Скопируйте конфиг от GaladrielMap в каталог для конфигов Apache:
sudo unzip GaladrielMap-1.4_GaladrielCache-2.3_gpsdAISd-1.0_netAIS-0.0.zip "apache2_galadrielmap.conf" -d /etc/apache2/sites-available/
Сделайте символьную ссылку для подключения конфига:
sudo ln -s /etc/apache2/sites-available/apache2_galadrielmap.conf /etc/apache2/sites-enabled/apache2_galadrielmap.conf
Перезапустите Apache:
sudo service apache2 restart

Наконец, укажите параметры судна для netAIS: in /GaladrielMap/netAIS/boatInfo.ini


