<?php
/* This is the simplest web daemon to broadcast NMEA sentences from the given file.
Designed for debugging applications that use gpsd.
The file set in $nmeaFileName and must content correct sentences, one per line.
Required options:
-i log file name
-b bind to proto://address:port
Run:
$ php naiveNMEAdaemon.php -isample1.log -btcp://127.0.0.1:2222
gpsd run to connect this:
$ gpsd -N -n tcp://192.168.10.10:2222
*/
$options = getopt("i::t::b::");
if(!($nmeaFileName = filter_var(@$options['i'],FILTER_SANITIZE_URL))) $nmeaFileName = 'sample1.log'; 	// NMEA sentences file name;
if(!($delay = filter_var(@$options['t'],FILTER_SANITIZE_NUMBER_INT))) $delay = 200000; 	// Min interval between sends sentences, in microseconds. 200000 are semi-realtime for sample1.log
//$delay = 1000000; 	// 
if(!($bindAddres=filter_var(@$options['b'],FILTER_VALIDATE_DOMAIN))) $bindAddres = "tcp://127.0.0.1:2222"; 	// Daemon's access address;
if($nmeaFileName=='sample1.log') {
	echo "Usage:\n  php naiveNMEAdaemon.php [-isample1.log] [-t200000] [-btcp://127.0.0.1:2222]\n";
	echo "-i nmea log file, default sample1.log\n";
	echo "-t delay between the log file string sent, microsecunds (1/1 000 000 sec.), default 200000\n";
	echo "-b bind address:port, default tcp://127.0.0.1:2222\n";
	echo "now run naiveNMEAdaemon.php -i$nmeaFileName -t$delay -b$bindAddres\n";
}

$run = 0; 		// 
//$run = 60; 		// Overall time of work, in seconds. If 0 - infinity.
//$filtering = TRUE;	// возвращать ли всё, или только отфильтрованные предложения
$updSat = TRUE;		// заменять в GGA нулевое количество видимых спутников на какое-то, если есть координаты -- исправление кривизны gpsd, который не любит нулевого количества спутников
$updTime = TRUE;	// исправлять время везде, где оно есть, на сейчас

//$saweSentences = TRUE; 	// записывать ли предложения NMEA в отдельный файл. Например, результат фильтрации



$strLen = 0;
$r = array(" | "," / "," - "," \ ");
$i = 0;
$startAllTime = time();
$statCollection = array();
date_default_timezone_set('UTC');	// чтобы менять время в посылках

$socket = stream_socket_server($bindAddres, $errno, $errstr);
if (!$socket) {
  return "$errstr ($errno)\n";
} 
echo "Wait for first connection on $bindAddres\n";
$conn = stream_socket_accept($socket);
echo "Connected! Go to loop\n";
echo "Будем посылать";
if($filtering) echo " только выбранные";
echo " предложения NMEA";
if($run) echo " $run секунд";
if($updSat) echo " исправляя количество видимых спутников на сколько-то";
if($updSat and $updTime) echo " и";
if($updTime) echo " исправляя время создания сообщения на сейчас";
echo ".\n";

$nStr = 0; 	// number of sending string
if($saweSentences) $sentencesfh = fopen('sentences.nmea', 'w');
while ($conn) { 	// 
	$handle = fopen($nmeaFileName, "r");
	if (FALSE === $handle) {
		exit("Failed to open file $nmeaFileName\n");
	}
	echo "\nBegin $nmeaFileName with delay {$delay}ms per string\n";
	echo "\n";
	$nStr = 0; 	// number of sending string
	$statSend = 0;
	$time = ''; $date = '';
	while (!feof($handle)) {
		if(($run AND ((time()-$startAllTime)>$run))) {
			fclose($handle);
			echo "Timeout, go away                            \n";
			echo "Send $nStr str                         \n";
			statShow();
			break 2;
		}
		$startTime = microtime(TRUE);
		$nmeaData = trim(fgets($handle, 2048));	// без конца строки
		if($nmeaData==FALSE) break; 	// достигнут конец файла
		//echo "$nmeaData\n";
		
		$NMEAtype = substr($nmeaData,3,3);
		//echo "NMEAtype=$NMEAtype;                                        \n";
		// Скорость есть в VTG и RMC
		// Координаты в GGA и RMC
		// fix указан в GSA (активные спутники), но там нет даты???
		
		//  Приведение времени к сейчас. Эпоху СЛЕДУЕТ начинать по RMC, и устанавливать
		// время всего остального равного времени RMC. (Есть ли более приоритетные сообщения?)
		// При этом (для gpsd?) время GGA можно установить в пусто, но тогда информация из GGA
		// не воспринимается?
		// Если ставить время по GGA -- скорости не будет вообще, даже если она есть в RMC
		// Если у GGA и RMC будет разное время -- будет скорость по RMC, и, видимо, эпоха
		// тоже будет начинаться по RMC, в результате может оказаться, что перемещение по GGA
		// в эту эпоху будет равно 0, и gpsd выдаст TPV с нулевой скоростью. При этом о друних
		// скоростях gpsd не сообщает.
		if($updTime and $NMEAtype == 'RMC'){ 	
			$time = date('His.').str_pad(substr(round(substr(microtime(),0,10),2),2),2,'0');
			//$time = date('His.00');
			$date = date('dmy');
			//echo "time=$time; date=$date;                               \n";
		}		
		// будем преобразовывать все предложения, ибо мало ли.
		$nmeaData = substr($nmeaData,0,strrpos($nmeaData,'*'));	// отрежем контрольную сумму
		$nmea = str_getcsv($nmeaData);	
		//echo "Before ";print_r($nmea);
		
		switch($NMEAtype){
		
		case 'GGA':
			// gpsbabel создает NMEA с выражениями GGA, в которых число используемых спутников
			// всегда равно 0.
			// gpsd считает, что если координаты есть, а спутников нет -- это ошибка, но не игнорирует
			// такое сообщение, а сообщает, что координат нет (NO FIX, "mode":1)
			// Следующий код добавляет в сообщения GGA сколько-то спутников, если их 0 и есть координаты
			
			//echo "Before|$nmeaData|\n";
			if(!intval($nmea[7]) and $updSat and $nmea[2]!=NULL and $nmea[4]!=NULL) { 	// есть широта и долгота и нет спутников
				//echo "GGA: не указано количество спутников, исправляем          \n";
				$nmea[7] = '06'; 	// будет столько спутников
			}
			//echo "Исходный момент привязки: {$nmea[1]}                     \n";
			//echo "GGA: time: $time                     \n";
			if($updTime) $nmea[1] = $time; 	//  Приведение времени к сейчас
			//$nmea[1] = '';
			break;
		
		case 'GLL':
			// Приведение времени к сейчас 
			if($updTime) $nmea[1] = $time; 	//  Приведение времени к сейчас
			break;
		case 'GNS':
			// Приведение времени к сейчас 
			if($updTime) $nmea[1] = $time; 	//  Приведение времени к сейчас
			break;
		
		case 'RMC':
			// Приведение времени к сейчас 
			//echo "RMC: time=$time; date=$date;       \n";
			if($updTime){ 	//  Приведение времени к сейчас			
				$nmea[1] = $time; 	// 
				$nmea[9] = $date; 	// 
			}
			break;
		
		//case 'VTG':
		//	break;
		//case 'GSA':
		//	break;
		default:
			if($filtering) continue 2;	// будем посылать только указанное
		}
		
		//echo "After "; print_r($nmea);
		$nmeaData = implode(',',$nmea);
		//echo "$nmeaData\n";
		$nmeaData .= '*'.NMEAchecksumm($nmeaData);
		//echo "After |$nmeaData|                                   \n";
		
		if($saweSentences) $res = fwrite($sentencesfh, $nmeaData."\n");	// сохраним в файл

		statCollect($nmeaData);
		//$res = fwrite($conn, $nmeaData . "\r\n");
		$res = fwrite($conn, $nmeaData."\n");
		if($res===FALSE) {
			echo "Error write to socket. Break connection\n";
			fclose($conn);
			echo "Try to reopen\n";
			$conn = stream_socket_accept($socket);
			if(!$conn) {
				echo "Reopen false\n";
				break;
			}
		}
		/*
		// Периодически будем показывать, какие сентенции были
		if(($nStr-$statSend)>9) {
			statShow();
			$statSend = $nStr;
		}
		*/
		$endTime = microtime(TRUE);
		$nStr++;
		echo($r[$i]);	// вращающаяся палка
		echo " " . ($endTime-$startTime) . " string $nStr         \r";
		$i++;
		if($i>=count($r)) $i = 0;
		usleep($delay);
	};
	fclose($handle);
	// reset connection?
	//if(!$conn)	$conn = stream_socket_accept($socket);
	//fclose($conn);
	//$conn = stream_socket_accept($socket);
	if($nStr) {
		echo "Send $nStr str                         \n";
		statShow();
	}
}
fclose($conn);
fclose($socket);
if($saweSentences) fclose($sentencesfh);

function statCollect($nmeaData) {
/**/
global $statCollection;
$nmeaData = substr(trim(str_getcsv($nmeaData)[0]),-3);
//if($nmeaData) @$statCollection["$nmeaData"]++;
$statCollection["$nmeaData"]++;
/*
if(strpos($nmeaData,'ALM')!==FALSE) $statCollection['ALM']++;
elseif(strpos($nmeaData,'AIVDM')!==FALSE) $statCollection['AIVDM']++;
elseif(strpos($nmeaData,'AIVDO')!==FALSE) $statCollection['AIVDO']++;
elseif(strpos($nmeaData,'DBK')!==FALSE) $statCollection['DBK']++;
elseif(strpos($nmeaData,'DBS')!==FALSE) $statCollection['DBS']++;
elseif(strpos($nmeaData,'DBT')!==FALSE) $statCollection['DBT']++;
elseif(strpos($nmeaData,'DPT')!==FALSE) $statCollection['DPT']++;
elseif(strpos($nmeaData,'GGA')!==FALSE) $statCollection['GGA']++;
elseif(strpos($nmeaData,'GLL')!==FALSE) $statCollection['GLL']++;
elseif(strpos($nmeaData,'GNS')!==FALSE) $statCollection['GNS']++;
elseif(strpos($nmeaData,'GSV')!==FALSE) $statCollection['GSV']++;
elseif(strpos($nmeaData,'HDG')!==FALSE) $statCollection['HDG']++;
elseif(strpos($nmeaData,'HDM')!==FALSE) $statCollection['HDM']++;
elseif(strpos($nmeaData,'HDT')!==FALSE) $statCollection['HDT']++;
elseif(strpos($nmeaData,'MTW')!==FALSE) $statCollection['MTW']++;
elseif(strpos($nmeaData,'MWV')!==FALSE) $statCollection['MWV']++;
elseif(strpos($nmeaData,'RMA')!==FALSE) $statCollection['RMA']++;
elseif(strpos($nmeaData,'RMB')!==FALSE) $statCollection['RMB']++;
elseif(strpos($nmeaData,'RMC')!==FALSE) $statCollection['RMC']++;
elseif(strpos($nmeaData,'VHW')!==FALSE) $statCollection['VHW']++;
elseif(strpos($nmeaData,'VWR')!==FALSE) $statCollection['VWR']++;
elseif(strpos($nmeaData,'ZDA')!==FALSE) $statCollection['ZDA']++;
elseif(strpos($nmeaData,'PGRMZ')!==FALSE) $statCollection['PGRMZ']++;
elseif($nmeaData) $statCollection['other']++;
*/
} 	// end function statCollect

function statShow() {
/**/
global $statCollection;
ksort($statCollection);
echo "Отосланы сообщения:                                   \n";
foreach($statCollection as $code => $count){
	echo "$code: $count\n";
}
echo "\n";
$statCollection = array();
} // end statShow

function NMEAchecksumm($nmea){
/**/
if(!(is_string($nmea) and $nmea[0]=='$')) return FALSE; 	// only not AIS NMEA string
$checksum = 0;
for($i = 1; $i < strlen($nmea); $i++){
	if($nmea[$i]=='*') break;
	$checksum ^= ord($nmea[$i]);
}
$checksum = str_pad(strtoupper(dechex($checksum)),2,'0',STR_PAD_LEFT);
return $checksum;
} // end function NMEAchecksumm

?>
