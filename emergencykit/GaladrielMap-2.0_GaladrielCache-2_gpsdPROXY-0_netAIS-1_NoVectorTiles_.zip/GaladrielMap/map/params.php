<?php
/* Options, paths and services
*/
// Пути paths
// путь в файловой системе к демону, собирающему информацию от gpsd. Демон имеет собственные настройки и зависимости!
// The Data collection daemon. Daemon has its own config file!
$gpsdPROXYpath = 'gpsdPROXY';	// file system path
// путь в файловой системе к программе кеширования тайлов GaladrielCache
$tileCachePath = '/GaladrielMap/tileproxy'; 	// path to GaladrielCache tile cache/proxy app location, if present, in filesystem. Comment this if no GaladrielCache. 
// путь в файловой системе к папке с записью пути (треку), от расположения GaladrielMap или абсолютный
$trackDir = 'track'; 	// track files directory, if present, in filesystem
// путь в файловой системе к папке с проложенными маршрутами и навигационными точками. Или абсолютный.
$routeDir = 'route'; 	// route & POI files directory, if present, in filesystem

// Службы Services
// 	Источник карты Map source
// url источника карты: в интернет или GaladrielCache
$tileCacheURI = "/tileproxy/tiles.php?z={z}&x={x}&y={y}&r={map}"; 	// uri of the map service, for example Galadriel tile cache/proxy service. In case GaladrielCache {map} is a map name in GaladrielCache app.
//$tileCacheURI = "http://mt2.google.com/vt/lyrs=s,m&hl=ru&x={x}&y={y}&z={z}"; 	//   uri of the map service - if no use GaladrielCache. Comment the $tileCachePath on this case.
//$tileCacheURI = 'http://a.tile.opentopomap.org/{z}/{x}/{y}.png'; 	//  uri of the map service - if no use GaladrielCache. Comment the $tileCachePath on this case.

// если время последнего определения положения отличается от текущего на столько секунд -- положение показывается как устаревшее (серый курсор)
$PosFreshBefore = 5; 	// seconds. The position is considered correct no longer than this time. If the position older - cursor is grey.

// 	Запись пути Logging
//		установите gpsd-utils, в состав которых входит gpxlogger  install gpsd-utils for gpxlogger
//		если эта переменная не установлена -- считается, что запись пути осуществляется чем-то другим
// 		при потере позиции на столько секунд будет создан новый путь
$loggerNoFixTimeout = 30; 	// sec A new track is created if there's no fix written for an interval
// 		новые координаты записываются каждые столько секунд
$loggerMinMovie = 5; 	// m Motions shorter than this will not be logged 
//		файл, куда записывается путь, имеет такое имя, что более поздние файлы находятся в начале списка (TRUE), или в конце (FALSE). Зависит от программы записи пути.
$currTrackFirst = FALSE; 	// In list of a tracks current track is a first (TRUE), or a last (FALSE). Depending on a your tracking app.
//		запуск gpxlogger. &logfile заменяется на имя файла лога, &host -- именем хоста, на котором занущена программа
$gpxlogger = "gpxlogger -e shm -r -i $loggerNoFixTimeout -m $loggerMinMovie -f &logfile"; 	// will listen to the local gpsd using shared memory, reconnect, interval, minmove. &logfile replaced by log filename, default host:port of gpsd
//$gpxlogger = "gpxlogger -e shm -r -i $loggerNoFixTimeout -m $loggerMinMovie -f &logfile &host:2947"; 	// will listen to the local gpsd using shared memory, reconnect, interval, minmove. &logfile replaced by log filename, &host replaced by host name 
//$gpxlogger = "gpxlogger -r -i $loggerNoFixTimeout -m $loggerMinMovie -f &logfile"; 	// will listen to the local gpsd, reconnect, interval, minmove. &logfile replaced by log filename,  &host replaced by host name 

// Системные параметры System
// строка запуска консольного интерпретатора php
//$phpCLIexec = '/usr/bin/php-cli'; 	// php-cli executed name on your OS
//$phpCLIexec = '/usr/bin/php'; 	// php-cli executed name on your OS
$phpCLIexec = 'php'; 	// php-cli executed name on your OS

//  поскольку params.php загружается отнюдь не только в index, все параметры должны быть здесь
// Параметры тайлового кеша Settings of a tile cache/proxy app
if( $tileCachePath) require_once("$tileCachePath/params.php");
require_once($gpsdPROXYpath.'/params.php'); 	// 
?>
