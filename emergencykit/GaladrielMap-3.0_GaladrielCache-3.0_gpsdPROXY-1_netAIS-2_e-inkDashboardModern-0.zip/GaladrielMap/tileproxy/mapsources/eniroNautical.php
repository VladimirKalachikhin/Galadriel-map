<?php
$humanName = array('ru'=>'Морская карта Eniro','en'=>'Eniro nautical chart');
$ttl = 86400*30*12; //cache timeout in seconds время, через которое тайл считается протухшим. 86400 - сутки
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 4;
$maxZoom = 18;
$bounds = array('leftTop'=>array('lat'=>81.09,'lng'=>-8.4402),'rightBottom'=>array('lat'=>53.5,'lng'=>34));
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,18859,9463,'bf82a2b2');	// to source check; tile number and CRC32b hash


$prepareTileImgBeforeReturn = function ($img){
// Заменяет в картинке цвет на прозрачный, требует sudo apt install php-gd 
// На этой карте цвет суши - 255,255,204 252,254,204 а населённых пунктов 228,228,177 228,230,180
// Если заменить его на прозрачный, можно наложить эту карту на непрозрачные карты суши
$img = setColorsTransparent($img,array(array(255,255,204),array(254,254,204),array(252,254,204),array(228,228,177),array(228,230,180)));
return array('img'=>$img,'mime_type'=>'image/png');
}; // end function prepareTileImgBeforeReturn

//
$getURL = function ($z,$x,$y) {
/* 
Algorithm getted from https://github.com/osmandapp/Osmand/issues/5818 and other
 http://192.168.10.10/tileproxy/tiles.php?z=12&x=2374&y=1161&r=eniroNautical
*/
//$url='https://map.eniro.com/geowebcache/service/tms1.0.0/map/';
$server = array();
$server[] = '';
$server[] = '01';
$server[] = '02';
$server[] = '03';
$server[] = '04';
$url='https://map'.$server[array_rand($server)].'.eniro.com/geowebcache/service/tms1.0.0/nautical/';
$y = ((1 << $z) - 1 - $y);
$url .= "$z/$x/$y".".png";
/*
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"Referer: http://www.eniro.fi/kartta/\r\nUser-Agent:Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)\r\n"
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE,
		//'protocol_version'=>1.1
	)
);
return array($url,$opts);
*/
return $url;
};
?>
