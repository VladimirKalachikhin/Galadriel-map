<?php
$humanName = array('ru'=>'Морская карта Navioncs','en'=>'Navionics nautical chart');
//$ttl = 86400*30*12*5; //cache timeout in seconds время, через которое тайл считается протухшим, 5 год
$ttl = 0; //cache timeout in seconds время, через которое тайл считается протухшим
$noTileReTry = $ttl;
$minZoom = 4;
$maxZoom = 19;
$ext = 'png'; 	// tile image type/extension
$on403 = 'skip'; 	// что делать, если Forbidden: skip, wait - default
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
	'7a64e130',
	'b2451042', 	// пустой серый тайл с логотипом
	'97aa1cbf', 	// кривая надпись про недоступность
	'3629b525', 	// нормальная надпись про недоступность
	'a5b8d956',
	'05aca0a6',
	'cd71a936',
	'1a1edf4b',
	'669a5f14',
	'5248581f',
	'b561bba3',
	'10165527',
	'122dc483',
	'9af9f806',
	'99b57ebb',
	'd87aee55' 	// запрет Navionics в Дании
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,18956,9316,'e5fc6d57');	// to source check; tile number and CRC32b hash

// поскольку этот файл require там, где это всё есть:
$getURLparams['on403'] = $on403;
$getURLparams['tileCacheDir'] = $tileCacheDir;
$getURLparams['mapSourcesName'] = $mapSourcesName;

$functionGetURL = <<<'EOFU'
require_once('fNavionics.php'); 	// дополнительные функции, необходимые для получения тайла

function getURL($zoom,$x,$y,$getURLparms) {
/* 
 http://192.168.10.10/tileproxy/tiles.php?z=12&x=2374&y=1161&r=navionics

https://tile4.navionics.com/tile/8/138/80?LAYERS=config_2_6_0&TRANSPARENT=FALSE&theme=0&navtoken=eyJrZXkiOiJOYXZpb25pY3Nfd2ViYXBpXzA0MDQxIiwia2V5RG9tYWluIjoibWFwcy5nYXJtaW4uY29tIiwicmVmZXJlciI6Im1hcHMuZ2FybWluLmNvbSIsInJhbmRvbSI6MTcyMzQ2NDUxNzExMH0
*/
global $globalProxy;

$tileCacheDir=$getURLparms['tileCacheDir'];
$r=$getURLparms['mapSourcesName'];
$on403=$getURLparms['on403']; 	// 
$tokenFileName = "$tileCacheDir/$r/navtoken";

$DefURLBase='https://tile'.(rand(1,5)).'.navionics.com/tile/';
$userAgents = [
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:107.0) Gecko/20100101 Firefox/107.0",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.1 Safari/605.1.15",
"Mozilla/5.0 (X11; Linux x86_64; rv:107.0) Gecko/20100101 Firefox/107.0",
"Mozilla/5.0 (X11; Linux x86_64; rv:108.0) Gecko/20100101 Firefox/108.0",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:107.0) Gecko/20100101 Firefox/107.0",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.54",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:108.0) Gecko/20100101 Firefox/108.0",
"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:108.0) Gecko/20100101 Firefox/108.0",
"Mozilla/5.0 (Windows NT 10.0; rv:108.0) Gecko/20100101 Firefox/108.0",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.46",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.2 Safari/605.1.15",
"Mozilla/5.0 (X11; Linux x86_64; rv:102.0) Gecko/20100101 Firefox/102.0",
"Mozilla/5.0 (Windows NT 10.0; rv:107.0) Gecko/20100101 Firefox/107.0",
"Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:107.0) Gecko/20100101 Firefox/107.0",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/99.0.4844.51 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 Edg/107.0.1418.62",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36 OPR/93.0.0.0",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:102.0) Gecko/20100101 Firefox/102.0",
"Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6.1 Safari/605.1.15",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:106.0) Gecko/20100101 Firefox/106.0",
"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
"Mozilla/5.0 (X11; Linux x86_64; rv:106.0) Gecko/20100101 Firefox/106.0",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15",
"Mozilla/5.0 (X11; Linux x86_64; rv:103.0) Gecko/20100101 Firefox/103.0",
"Mozilla/5.0 (Windows NT 10.0; rv:102.0) Gecko/20100101 Firefox/102.0",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 Edg/108.0.1462.42",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36",
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36",
"Mozilla/5.0 (X11; Linux x86_64; rv:107.0) Gecko/20100101 Edge/107.0.1418.62",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36 OPR/94.0.0.0",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0",
"Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:102.0) Gecko/20100101 Firefox/102.0",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/15.6 Safari/605.1.15",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36 OPR/92.0.0.0",
"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:105.0) Gecko/20100101 Firefox/105.0"
];
$userAgent = $userAgents[array_rand($userAgents)];
$RequestHead='Referer: https://maps.garmin.com/';
$tokenTimeOut = 12*60*60; // сек. - время, через которое токен считается протухшим, и надо запрашивать снова
//******************************************************************************
// LAYERS parameter: config_a_b_c
//    a = 1 for depth in meters, 2 for depth in feet, 3 for fathoms
//    b = 10.00: for 10.00 m safety depth (beginning of blue coloring) (unit equal to that set by a)
//    c = 0 for pristine Navionics charts, 1 for Sonar Charts
//
// TRANSPARENT parameter: 
//    FALSE for non-layer
//    TRUE for layer
//
// UGC parameter: 
//    FALSE for pristine Navionics charts
//    TRUE for additinal user-generated content icons
//******************************************************************************
//$cReqParams = 'LAYERS=config_1_10.00_0&TRANSPARENT=FALSE&UGC=FALSE';
$cReqParams = 'LAYERS=config_1_10.00_0&TRANSPARENT=FALSE&UGC=TRUE&theme=0';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'protocol_version'=>'1.1',
		//'proxy'=>'tcp://127.0.0.1:8118',	
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
list($VNavToken,$VTimeStamp) = $_SESSION['NavionicsToken'];
if(!$VNavToken) { 	// нет сессии - протухла или клиент cli, или клиент не умеет печеньки
	list($VNavToken,$VTimeStamp) = unserialize(@file_get_contents($tokenFileName));
}
//echo "Before: VNavToken=$VNavToken;\nVTimeStamp=$VTimeStamp;<br>\n";
//error_log( "Before: VNavToken=$VNavToken;\nVTimeStamp=$VTimeStamp;<br>\n");
//echo "Должен протухнуть в " . time() . "-$tokenTimeOut<br>\n" ;
if((time()-$tokenTimeOut) > $VTimeStamp) { 	//  токена нет ($VTimeStamp==0) или токен протух
	$saveGlobalProxy = $globalProxy;
	if($opts['http']['proxy']) $globalProxy = $opts['http']['proxy'];	// это такой способ передать в GetNavToken proxy отсюда.
	$VNavToken = GetNavToken(); 	// ../fNavionics.php получим новый токен и время его получения
	$globalProxy = $saveGlobalProxy;
	$_SESSION['NavionicsToken'] = $VNavToken; 	// сохраним токен
	$umask = umask(0); 	// сменим на 0777 и запомним текущую
	file_put_contents($tokenFileName, serialize($VNavToken)); 	// запишем файл с токеном
	@chmod($tokenFileName,0666); 	// чтобы при запуске от другого юзера была возаможность 
	umask($umask); 	// 	Вернём. Зачем? Но umask глобальна вообще для всех юзеров веб-сервера
	list($VNavToken,$VTimeStamp) = $VNavToken;
}
if($VNavToken) {
	$ResultURL = $DefURLBase . "$zoom/$x/$y" . "?$cReqParams" . "&navtoken=$VNavToken";
}
else {
	$on403='wait'; 	//  нет токена. Запрос тайла окончится 403, на что мы скажем wait
	$ResultURL = '';
}
//echo "ResultURL=$ResultURL; <br>\n";
//error_log("ResultURL=$ResultURL;");
return array($ResultURL,$opts);
}
EOFU;
?>
