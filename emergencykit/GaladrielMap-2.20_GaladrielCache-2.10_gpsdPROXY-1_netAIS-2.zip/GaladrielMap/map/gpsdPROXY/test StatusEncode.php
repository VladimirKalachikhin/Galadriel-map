<?php
require('fCommon.php');

echo navigationStatusEncode("Under way using engine");
?>
