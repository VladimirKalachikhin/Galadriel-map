По-русски - ниже.
PLEASE! If you may use Apache - use it!

Recipe for normal distributions and early OpenWRT.
For OpenWRT greater then 21.0 see below

Place nginx_galadrielmap_conf directory to /etc/nginx/ and edit nginx.conf by add 
 include nginx_galadrielmap_conf/GaladrielMap/*.conf;
string to end of default "server" section:

	server{ 
		listen 80 default_server; 
		....
		
		include nginx_galadrielmap_conf/GaladrielMap/*.conf;
	} 

and
 include nginx_galadrielmap_conf/netAIShiddenService/*.conf;
string to end of "http" section, but before
 include /etc/nginx/conf.d/*.conf;
string:

http {

	....
	
	include nginx_galadrielmap_conf/netAIShiddenService/*.conf;
    include /etc/nginx/conf.d/*.conf;
}

restart nginx

If ypu use OpenWRT at last before of the 21.02.7, change /etc/php7-fpm.d/www.conf to:  

;user = nobody
user = root

Change /etc/init.d/php7-fpm to:

#PROG="/usr/bin/php-fpm"
PROG="/usr/bin/php-fpm -R"

restart php7-fpm

As result php will be run from root. This is necessary for the GaladrielMap to work correctly.
If you use OpenWRT 21.02.7 or greater, it is not necessary.

The GaladrielMap is available at http://you_OpenWRT.lan/map/


For OpenWRT greater then 21.0
This versions use https:// transport instead http:// for web interface. The GaladrielMap use http:// but modern browsers don't allow http:// calls from https:// pages. Therefore, the GaladrielMap will not work as /map/
Besides, OpenWRT greater then 21.0 use uci to generate a config, therefore it is useless to modify the configuration file, except for the set 
	option uci_enable 'false'
in /etc/config/nginx But in this case, you will have to configure the LuCI web interface manually.
You can configure the GaladrielMap to work on another port, but it is more convenient to make the LuCI web interface work on http://
For this:
place nginx_galadrielmap_conf directory to /etc/nginx/ as stated above
replace the original /etc/config/nginx by config/nginx from this dir
symlink /etc/nginx/nginx_galadrielmap_conf/netAIShiddenService/netAIShiddenService.conf to /etc/nginx/conf.d/:
# ln -s /etc/nginx/nginx_galadrielmap_conf/netAIShiddenService/netAIShiddenService.conf /etc/nginx/conf.d/

restart nginx
The GaladrielMap is available at http://you_OpenWRT.lan/map/



 
Используйте Apache, если это возможно! Не надо вот этого...

Рецепт для нормальных дистрибутивов и ранних версий OpenWRT.
Для OpenWRT от 21.0 и старше - см.ниже.

Поместите этот каталог рядом с каталогом /etc/nginx/conf.d и добавьте в nginx.conf строки:
 include nginx_galadrielmap_conf/*.conf;
в конец главного блока server{}:

	server{ 
		listen 80 default_server; 
		....
		
		include nginx_galadrielmap_conf/GaladrielMap/*.conf;
	} 

и в конце блока http{}, перед строкой
 include /etc/nginx/conf.d/*.conf; 
:

http {

	....
	
	include nginx_galadrielmap_conf/netAIShiddenService/*.conf;
    include /etc/nginx/conf.d/*.conf;
}

перезапустите nginx

Для работы под (ранними версиями) OpenWRT измените файл /etc/php7-fpm.d/www.conf следующим образом:  

;user = nobody
user = root

Измените файл /etc/init.d/php7-fpm следующим образом:

#PROG="/usr/bin/php-fpm"
PROG="/usr/bin/php-fpm -R"

В результате php  будет запускаться от root. Это нужно для нормальной работы GaladrielMap.
В версиях OpenWRT по крайней мере с 21.02.7 есть юзер nobody, и указанные изменения производить не надо.

перезапустите php7-fpm

GaladrielMap будет доступна как http://you_OpenWRT.lan/map/


Для OpenWRT от 21.0 и старше:
Эти версии используют протокол https:// для web-интерфейса, а GaladrielMap работает по http:// Современные браузеры запрещают обращаться к ресурсам по http:// со страниц, открытых по https://, поэтому GaladrielMap не будет работать как /map/
Кроме того, в OpenWRT старше 21.0 используется uci для генерации конфига nginx, поэтому менять конфиг бесполезно - он будет переписан при каждом запуске nginx.
Этого можно избежать, указав
	option uci_enable 'false'
в /etc/config/nginx, но в этом случае придётся вручную сконфигурировать web-интерфейс LuCI.
Можно сконфигурировать GaladrielMap для работы на другом порту, но удобней заставить LuCI работать по http://
Для этого:
поместите каталог nginx_galadrielmap_conf в /etc/nginx/ как указано выше
замените исходный файл /etc/config/nginx файлом config/nginx из этого каталога
сделайте символьную ссылку от /etc/nginx/nginx_galadrielmap_conf/netAIShiddenService/netAIShiddenService.conf в /etc/nginx/conf.d/:
# ln -s /etc/nginx/nginx_galadrielmap_conf/netAIShiddenService/netAIShiddenService.conf /etc/nginx/conf.d/

перезапустите nginx
GaladrielMap будет доступна как http://you_OpenWRT.lan/map/

