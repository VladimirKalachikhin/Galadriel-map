PLEASE! If you may use Apache - use it!

Place nginx_galadrielmap_conf directory to /etc/nginx/ and edit nginx.conf by add 
 include nginx_galadrielmap_conf/GaladrielMap/*.conf;
string to end of default "server" section:

	server{ 
		listen 80 default_server; 
		....
		
		include nginx_galadrielmap_conf/GaladrielMap/*.conf;
	} 

and
 include nginx_galadrielmap_conf/netAIShiddenService/*.conf;
string to end of "http" section, but before
 include /etc/nginx/conf.d/*.conf;
string:

http {

	....
	
	include nginx_galadrielmap_conf/netAIShiddenService/*.conf;
    include /etc/nginx/conf.d/*.conf;
}

restart nginx
 
Используйте Apache, если это возможно! Не надо вот этого...

Поместите этот каталог рядом с каталогом /etc/nginx/conf.d и добавьте в nginx.conf строки:
 include nginx_galadrielmap_conf/*.conf;
в конец главного блока server{}:

	server{ 
		listen 80 default_server; 
		....
		
		include nginx_galadrielmap_conf/GaladrielMap/*.conf;
	} 

и в конце блока http{}, перед строкой
 include /etc/nginx/conf.d/*.conf; 
:

http {

	....
	
	include nginx_galadrielmap_conf/netAIShiddenService/*.conf;
    include /etc/nginx/conf.d/*.conf;
}

перезапустите nginx
