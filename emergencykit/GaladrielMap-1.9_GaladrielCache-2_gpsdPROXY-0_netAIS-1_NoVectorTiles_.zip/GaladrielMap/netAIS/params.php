<?php
$noVehicleTimeout = 600; 	// seconds, time of continuous absence of the vessel in AIS, when reached - is deleted from the data. "when a ship is moored or at anchor, the position message is only broadcast every 180 seconds;"

// Пути и параметры Paths
// client
// каталог для файлов данных AIS. Туда добавляются цели от netAIS, свой файл для каждой группы, и данные сервера
// если имя каталога указано без пути, он будет размещён в /tmp, что рекомендовано для "упрощённых" операционных систем типа OpenWRT
// если указан полный путь -- каталог буде размещён где указано. Это рекомендовано для "полнофункциональных" операционных систем для избежания проблем с доступом к файлам в /tmp других процессов
// directory for AIS data
// if without path this is placed in /tmp. It is recommended on "portable" os - such as OpenWRT.
// with the path - placed by path. Recommended on "full futured" os, such as Ubuntu, to avoid files access troubles from other processes.
//$netAISJSONfilesDir = 'data/'; 	// 
$netAISJSONfilesDir = '/GaladrielMap/netAIS/data/'; 	//

//$selfStatusTimeOut = 60*60*24; 	// in sec, one day. If no change this time - exit
$selfStatusTimeOut = 0; 	// 
// оставьте этот путь без изменений leave it unchanged
$selfStatusFileName = 'server/selfStatus'; 	//  array, 0 - Navigational status, 1 - Navigational status Text. место, где хранится состояние клиента

// tor hidden service address
// config you http server correctly to run tor hidden service!
//$onion = 'axwiptv2ewxmcv23.onion'; 	// Server onion address. If not - no server run. This is a content of /var/lib/tor/hidden_service_netAIS/hostname file
$onion = ''; 	// Server onion address. If not - no server run. This is a content of /var/lib/tor/hidden_service_netAIS/hostname file
$torHost = 'localhost';
$torPort = 9050; 	// from torrc, default 9050

// AIS flow daemon
//$netAISdHost='localhost'; 	// comment to disable. netAIS feed by "gpsd://" or NMEA protocol. Use this for apps other than GaladrielMap, such as OpenCPN.
//$netAISdHost='192.168.10.100';
$netAISdPort=3800;

// gpsd
$netAISgpsdHost = 'localhost';
$netAISgpsdPort = 2947;

// Signal K
//$netAISsignalKhost = array(['localhost',3000]);

// system
$phpCLIexec = 'php'; 	// php-cli executed name on your OS
?>
