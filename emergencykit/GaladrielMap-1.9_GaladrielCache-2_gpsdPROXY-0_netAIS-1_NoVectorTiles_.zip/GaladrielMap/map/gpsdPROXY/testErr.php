<?php

include('file');

$old_error_handler = set_error_handler(function ($severity, $message, $file, $line) {
	echo "\nError\n";
	//echo "$severity, $message, $file, $line";
});

include('file');

restore_error_handler();
?>
