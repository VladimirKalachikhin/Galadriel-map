<?php
/* Скан морской бумажной карты, довольно низкого качества, один масштаб.
https://julkinen.traficom.fi/oskari/

This dataset produced by the Finnish Transport and Communications Agency 
is licensed under a Creative Commons Attribution 4.0 International License - http://creativecommons.org/licenses/by/4.0/ 
"Source: Finnish Transport and Communications Agency. Not for navigational use. Does not meet the requirements for appropriate nautical charts."

Однако, нагло не пускают русских, и через tor и через общеизвестные VPN и proxy. 
Поэтому нужно искать не общеизвестный proxy.

https://julkinen.traficom.fi/rasteripalvelu/wmts?request=getcapabilities
https://julkinen.traficom.fi/rasteripalvelu/wmts/rest/Traficom:Merikarttasarjat%20public/default/WGS84_Pseudo-Mercator/WGS84_Pseudo-Mercator:14/4658/9478?format=image/png

https://julkinen.traficom.fi/oskari/
https://julkinen.traficom.fi/oskari/action?action_route=GetLayerTile&id=39&layer=Traficom%3AMerikarttasarjat%20public&style=&tilematrixset=ETRS89_TM35-FIN&Service=WMTS&Request=GetTile&Version=1.0.0&Format=image%2Fpng&TileMatrix=ETRS89_TM35-FIN%3A12&TileCol=2180&TileRow=3157

*/
$humanName = array('ru'=>'Финляндия, бумажная морская карта','en'=>'Finland paper marine map','fi'=>'Suomen paperinen merikartta');
//$ttl = 60*60*24*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
$ttl = 60*60*24*30*1; //
//$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать. OpenTopoMap банит скачивальщиков, поэтому короткое.
$ext = 'png'; 	// tile image type/extension
$minZoom = 6;
$maxZoom = 15;
$bounds = array('leftTop'=>array('lat'=>65.85,'lng'=>19.0),'rightBottom'=>array('lat'=>59.67,'lng'=>30.38));
// crc32 хеши тайлов, которые не надо сохранять: логотипы, тайлы с дурацкими надписями.
$trash = array(
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,18956,9316,'c5f6164c');	// to source check; tile number and CRC32b hash

$getURL = function ($z,$x,$y,$getURLparams) {
/* */
$url = 'https://julkinen.traficom.fi/rasteripalvelu/wmts/rest/Traficom:Merikarttasarjat%20public/default/WGS84_Pseudo-Mercator/WGS84_Pseudo-Mercator:';

$userAgent = randomUserAgent();
//$RequestHead='Referer: ';
$RequestHead='';

$url .= "$z/$y/$x?format=image/png";

$proxyesList = array(
'tcp://58.147.186.214:3125',
'tcp://47.243.92.199:3128',
'tcp://36.66.242.118:8080',
'tcp://4.149.153.123:3128',
'tcp://49.229.100.235:8080',
'tcp://177.234.194.30:999',
'tcp://103.227.187.1:6080',
'tcp://47.91.104.88:3128',
'tcp://8.213.151.128:3128'
);
$proxy = $proxyesList[array_rand($proxyesList)];
$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>$proxy,
		//'timeout' => 30,
		'request_fulluri'=>true,	// адрес в запросе будет полный! Иначе - относительный.
		//'protocol_version'=>1.1
	)
);
//print_r($opts);

return array($url,$opts);
};
?>
