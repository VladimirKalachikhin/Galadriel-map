<?php
/* Вполне дурацкая карта: нет рельефа, нет ЛЭП, нет много чего ещё, левые цвета. Зато быстро.
 */
$humanName = array('ru'=>'карта-схема OpenStreetMap','en'=>'OpenStreetMap');
//$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим. 86400 - сутки
$ttl = 60*60*24*30*12*3; //cache timeout in seconds время, через которое тайл считается протухшим, 3 года, потому что эти суки стали радикально упрощать карты бывших хохляцких территорий
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 3;
$maxZoom = 18;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(14,9898,5151,'edc0ae4f');	// to source check; tile number and CRC32b hash

$getURL = function ($z,$x,$y) {
$srv = ['a','b','c'];
$url='https://tile-'.$srv[array_rand($srv)].'.openstreetmap.fr/hot/';
$url .= "$z/$x/$y".".png";

$userAgent = randomUserAgent();
//$RequestHead='Referer: ';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
return array($url,$opts);
};
?>
