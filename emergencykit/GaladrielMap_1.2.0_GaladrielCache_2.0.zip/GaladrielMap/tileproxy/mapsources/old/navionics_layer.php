<?php
$ttl = 86400*30*12*3; //cache timeout in seconds время, через которое тайл считается протухшим, 3 год
//$ttl = 0; //cache timeout in seconds время, через которое тайл считается протухшим, никогда
$ext = 'png'; 	// tile image type/extension
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
	'b2451042', 	// пустой серый тайл с логотипом
	'97aa1cbf', 	// кривая надпись про недоступность
	'3629b525',		// нормальная надпись про недоступность
	'1c2bea2b',		// другая нормальная надпись про недоступность
	'bbe4324b',		// другая кривая надпись про недоступность
	'd7c8e677',
	'd79fc9ac',
	'e152e6d7',
	'a2054605',
	'84e1d0fd',
	'9e888860',
	'cda5dd37',
	'b187eebe',
	'192e10ea',
	'096a8efa',
	'0d3c286f',
	'367e4613',
	'42ed66ac',
	'85392d61',
	'592f75e8',
	'5607efe7',
	'277b9ee1',
	'5bee5657',
	'50b52340',
	'692b3e4e',
	'0728ad40',
	'79fb55ba',
	'8b8b309b',
	'fbb9396a',
	'ac7eb08c',
	'6e6b4e0d',
	'd9f2998f',
	'0fbd6fa5',
	'5e1f7018',
	'9e89506d',
	'a01ccc39',
	'417c93ed',
	'0940c426' 		// пустой тайл
);
$minZoom = 11;
$maxZoom = 19;
$functionGetURL = <<<'EOFU'
function getURL($zoom,$xtile,$ytile) {
/* Алгоритм получения ссылки на тайл заимствован из SAS.Planet
 http://192.168.10.10/tileproxy/tiles.php?z=12&x=2374&y=1161&r=navionics_layer
*/

$DefURLBase='http://webviewer-api.navionics.com/getmap?PARAMS=';
$RequestHead='Referer: http://www.navionics.com/sites/navionics.plurimedia.it/files/coverage/webapp.html?2985400';
$r_major = 6378388.00; 	// большая полуось эллипсоида
$r_minor = 6356912.00; 	// малая полуось эллипсоида
//******************************************************************************
$ord = tileNum2mercOrd($zoom,$xtile,$ytile+1,$r_major,$r_minor); 	// потому что возвращаются линейные координаты верхнего левого угла тайла, а нам нужен нижний левый
$LMetr = $ord['x'];
$BMetr = $ord['y']; 	// линейные координаты левого нижнего угла тайла
$ord = tileNum2mercOrd($zoom,$xtile+1,$ytile,$r_major,$r_minor); 	// потому что возвращаются линейные координаты верхнего левого угла тайла, а нам нужен верхний правый
$RMetr = $ord['x'];
$TMetr = $ord['y']; 	// линейные координаты правого верхнего угла тайла
$VBox = (string)round($LMetr,10).','.(string)round($BMetr,10).','.(string)round($RMetr,10).','.(string)round($TMetr,10);
//echo "VBox=$VBox; <br>\n";
//******************************************************************************
// LAYERS parameter: config_a_b_c
//    a = 1 for depth in meters, 2 for depth in feet, 3 for fathoms
//    b = 10.00: for 10.00 m safety depth (beginning of blue coloring) (unit equal to that set by a)
//    c = 0 for pristine Navionics charts, 1 for Sonar Charts
//
// TRANSPARENT parameter: 
//    FALSE for non-layer
//    TRUE for layer
//
// UGC parameter: 
//    FALSE for pristine Navionics charts
//    TRUE for additinal user-generated content icons
//******************************************************************************
$VEncoded = 
    'LAYERS=osm_ram' . '&' . 
    'TRANSPARENT=TRUE' . '&' . 
    'SERVICE=WMS' . '&' .
    'VERSION=1.1.1' . '&' .
    'REQUEST=GetMap' . '&' .
    'STYLES=' . '&' .
    'FORMAT=image%2Fpng' . '&' .
    'SRS=EPSG%3A3395' . '&' .
    'WIDTH=256' . '&' .
    'HEIGHT=256' . '&' .
    'BBOX=' . $VBox;

//echo "VEncoded=$VEncoded; <br>\n";
// crypt
for($i=0;$i<strlen($VEncoded);$i++){
	//echo "VEncoded[$i]=$VEncoded[$i]; <br>\n";
	$VEncoded1 .= chr( ord($VEncoded[$i]) ^ 42);
}  
$VEncoded = $VEncoded1;
$VEncoded = base64_encode($VEncoded); 	// Base64 encode
$VEncoded = str_replace('+','%2b',$VEncoded); 	//replase "+" with "%2b" charset
//echo "VEncoded=$VEncoded; <br>\n";
$zoom++; 	// потому что в Navionics zoom с 1?
$ResultURL = $DefURLBase . $VEncoded . '&NAVKEY=NAVIONICS11WEBAPI111&TEST=' . $VBox . '&ZOOM=' . $zoom . '&v=1&SRC=http://www.navionics.com';
//echo "ResultURL=$ResultURL; <br>\n";
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent:Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)\r\n" . "$RequestHead\r\n"
	)
);
return array($ResultURL,$opts);
}
EOFU;
?>
