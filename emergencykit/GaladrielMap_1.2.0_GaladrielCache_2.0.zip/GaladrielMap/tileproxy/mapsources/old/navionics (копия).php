<?php
$ttl = 86400*30; //cache timeout in seconds время, через которое тайл считается протухшим
$ext = 'png'; 	// tile image type/extension
function getURL($z,$x,$y) {
/* Алгоритм получения ссылки на тайл заимствован из SAS.Planet
*/
//******************************************************************************
// LAYERS parameter: config_a_b_c
//    a = 1 for depth in meters, 2 for depth in feet, 3 for fathoms
//    b = 10.00: for 10.00 m safety depth (beginning of blue coloring) (unit equal to that set by a)
//    c = 0 for pristine Navionics charts, 1 for Sonar Charts
//
// TRANSPARENT parameter: 
//    FALSE for non-layer
//    TRUE for layer
//
// UGC parameter: 
//    FALSE for pristine Navionics charts
//    TRUE for additinal user-generated content icons
//******************************************************************************

$cReqParams = 'LAYERS=config_1_10.00_0&TRANSPARENT=FALSE&UGC=TRUE';

$DefURLBase='http://backend.navionics.io/tile';
$RequestHead="Referer: http://webapiv2.navionics.com/examples/4000_gNavionicsOverlayExample.html";
//******************************************************************************
// получение токена
global $tileCacheDir;
$fileNavToken = "$tileCacheDir/navionics/NavToken";
$cTTL = 24*60*60; // 24 hour  
if (!is_file($fileNavToken) || filemtime($fileNavToken) < time()-$cTTL/2) { 	// если нет файла или токен протух
	// получим токен
	$opts = array(
		'http'=>array(
			'method'=>"GET",
			'header'=>"Origin: http://webapiv2.navionics.com\r\n" . "Referer: http://webapp.navionics.com/\r\n"
		)
	);
	$context = stream_context_create($opts);
	// Open the file using the HTTP headers set above
	$VNavToken = file_get_contents('http://backend.navionics.io/tile/get_key/Navionics_internalpurpose_00001/webapp.navionics.com?_='.time(), false, $context);
	if ($VNavToken) {
		@mkdir(dirname($fileNavToken), 0755, true);
		$fp = fopen($fileNavToken, "w");
		fwrite($fp, $VNavToken);
		fclose($fp);
	}
}
else {
	$VNavToken = file_get_contents($fileNavToken); 	// возьмём токен
}
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent:Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)\r\n" . "Referer: http://webapiv2.navionics.com/examples/4000_gNavionicsOverlayExample.html\r\n" . "Accept-Language: en-US;q=0.5,en;q=0.3"
	)
);
$url = "$DefURLBase/$z/$x/$y?$cReqParams&navtoken=$VNavToken";
return array($url,$opts);
}
// не должно быть пустой строки после 
?>
