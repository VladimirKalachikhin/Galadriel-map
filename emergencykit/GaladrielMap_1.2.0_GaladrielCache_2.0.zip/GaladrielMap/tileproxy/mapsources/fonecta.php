<?php
//$ttl = 86400*30*12*3; //cache timeout in seconds время, через которое тайл считается протухшим, три год
$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 4;
$maxZoom = 18;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
/*
$functionGetURL = <<<'EOFU'
function getURL($z,$x,$y) {
// Алгоритм получения ссылки на тайл получен автором путем реверсинжиниринга. С клинингом, да
// http://192.168.10.10/tileproxy/tiles.php?z=12&x=2374&y=1161&r=fonecta
//
$url='http://kartta.fonecta.fi/oym?f=m&ft=png_nauti_256&key=FO1349G5NGDTJ52H913SFRK63928';
if(($z<=18) AND ($z>=5)) {
	$x = $x - ((1 << $z)/2);
	$y = ((1 << $z)/2)-1-$y;
	$z = 18-$z;
}
$url .= "&x=$x&y=$y&z=$z";
$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"Referer: https://www.fonecta.fi/kartat?lon=25.58129239320995&lat=61.09582494617275&z=8&l=NAU\r\nUser-Agent:Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 5.1; .NET CLR 2.0.50727)\r\n"
		'header'=>"Referer: https://www.fonecta.fi/kartat?lon=25.58129239320995&lat=61.09582494617275&z=8&l=NAU\r\n"
	)
);
return array($url,$opts);
}
EOFU;
*/
?>
