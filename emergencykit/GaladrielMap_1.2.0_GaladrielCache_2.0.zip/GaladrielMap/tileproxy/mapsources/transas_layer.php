<?php
/* Старые морские карты Transas
Содержат воды России, в том числе и внутренние, с хорошей детализаций.
Нет высот мостов и ЛЭП, нет размеров маяков и ориентиров.
Базовые сведения: https://wms.transas.com/ , но токен там тухлый
token захардкоден в файле http://www.isailor.us/folios/js/window-init.js?v=2
curl --silent http://www.isailor.us/folios/js/window-init.js?v=2 | grep token=
*/
$ttl = 86400*30*12*5; //cache timeout in seconds время, через которое тайл считается протухшим, 5 год
//$ttl = 0; //cache timeout in seconds время, через которое тайл считается протухшим
$ext = 'png'; 	// tile image type/extension
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
$minZoom = 6;
$maxZoom = 17;

$functionGetURL = <<<'EOFU'
function getURL($zoom,$x,$y) {
/*
http://wms.transas.com/TMS/1.0.0/tx97-transp/11/1185/578.png?token=114c0d17-9ca1-4edf-9b9b-6e1aff73fbf0
*/
global $ext, $minZoom, $maxZoom;

$DefURLBase='http://wms.transas.com/TMS/1.0.0/tx97-transp/';
$RequestHead='Referer	http://www.isailor.us/folios/index.htm';
//$RequestHead='Upgrade-Insecure-Requests	1';
//$token = '9e53bcb2-01d0-46cb-8aff-512e681185a4'; 	// banned
$token = '114c0d17-9ca1-4edf-9b9b-6e1aff73fbf0';

if(($zoom<=$maxZoom) AND ($zoom>=$minZoom)) {
	$y = ((1 << $zoom)-1)-$y; 	// 2^zoom - 1 = число тайлов по y (или x) данного zoom
}

$ResultURL = $DefURLBase . "$zoom/$x/$y.$ext"."?token=$token";

//echo "ResultURL=$ResultURL; <br>\n";
//error_log("ResultURL=$ResultURL;");
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=> "$RequestHead\r\n",
		'proxy'=>'tcp://127.0.0.1:8123',
		'request_fulluri'=>TRUE
	)
);
return array($ResultURL,$opts);
}
EOFU;
?>
