<?php
$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$minZoom = 8;
$maxZoom = 12;
?>
