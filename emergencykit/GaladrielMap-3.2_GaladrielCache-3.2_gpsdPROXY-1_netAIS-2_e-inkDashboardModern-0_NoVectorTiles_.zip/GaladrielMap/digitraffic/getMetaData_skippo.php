<?php ob_start();
// ссылка на источник сведений о целях AIS
$urlAISvessels = 'https://boat-data-service.skippo.io/data/2412/';	// AIS targets metadata url

require_once("params.php");
require_once("fconnect.php");
require "fSkippo.php";

//$mmsiS = array('983542156','538008208','273262130','230081740');	// массив mmsi
//$mmsiS = array('273437230','273397150','511101899','230081740');	// массив mmsi
//$mmsiS = array('jihnW0Ln6uPskHwQ7A5zSRty8m32');	// массив mmsi
//$mmsiS = array('ViCJ6qtvk1XlLn8UNNt6vHvnaa13');	// массив mmsi
//$mmsiS = array('667002027');	// массив mmsi

$metaDataS = array(); 	// собираемые метаданные
$mmsiS = '';	// массив mmsi
do{
	$mmsiS .= trim(fgets(STDIN));
}while(!feof(STDIN));
$mmsiS = unserialize($mmsiS);
//echo "noMetaData=";print_r($mmsiS);
if(!$mmsiS) return;

$ch = curl_init();
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Cache-Control: no-cache',
'Connection: keep-alive',
//'User-Agent: '.randomUserAgent(),	// fCommon.php
//'Referer: https://www.skippo.se/',
'Authorization:	Basic '.$AISdataSources['skippo']['token']	// Как долго проживёт токен?
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, round($getDataTimeout));
curl_setopt($ch, CURLOPT_TIMEOUT, $getDataTimeout*10);
//curl_setopt($ch, CURLOPT_NOPROXY,'');
if($proxyURL and $AISdataSources['skippo']['proxy']) curl_setopt($ch,CURLOPT_PROXY,$proxyURL);
$toGET = count($mmsiS); $badCount = 0;  $errStr = '';
foreach($mmsiS as $mmsi){
	curl_setopt($ch, CURLOPT_URL,"$urlAISvessels/$mmsi");
	$metadata = curl_exec($ch);
	$info = curl_getinfo($ch);
	//print_r($info);
	if(curl_errno($ch) or (($info['http_code'] != '200')  and ($info['http_code'] != '404'))){
		//echo "Failed to get metadata for mmsi $mmsi".curl_error($ch)."\n";
		$errStr = 'Err # '.curl_errno($ch).' Err:'.curl_error($ch).'; http_code='.$info['http_code'];
		$badCount++;
		if($proxyURL and $AISdataSources['skippo']['proxy']) $proxyProc('getAISdata',5);
		continue;
	};
	if(!$metadata) continue;	// Данных может и не быть, если спросили mmsi, которого нет у skippo
	$metadata = json_decode($metadata,true);
	$metadata['mmsi'] = $metadata['boatId'];
	unset($metadata['boatId']);
	if(isset($metadata['active']) and !$metadata['active']) continue;	// На лайбе skippo выключена программа, а если оно не лайба skippo, то параметра может не быть
	// Сделаем массив плоским
	unset($metadata['user']);	// Удалим сведения о юзере из данных лайбы skippo
	if(isset($metadata['location'])){
		$metadata = array_merge($metadata,$metadata['location']);
		unset($metadata['location']);
	};
	if(isset($metadata['aisData'])){
		$metadata = array_merge($metadata,$metadata['aisData']);
		unset($metadata['aisData']);
	};
	if(isset($metadata['lastUpdated'])){
		$metadata['timestampExternal'] = intval($metadata['lastUpdated']/1000);
		unset($metadata['lastUpdated']);
	};
	if(isset($metadata['timestamp'])){
		$metadata['timestamp'] = intval($metadata['timestamp']/1000);
	};
	if(isset($metadata['navStatus'])){
		$metadata['navStat'] = $metadata['navStatus'];
		unset($metadata['navStatus']);
	};
	if($metadata['aisAnchored'] and !$metadata['navStat']){
		$metadata['navStat'] = 1;
	};
	if(isset($metadata['type'])){
		$metadata['shipType'] = shipType($metadata['type']);
		unset($metadata['type']);
	};
	$metaDataS[] = $metadata;
};
curl_close($ch);
ob_end_clean();
//echo json_encode($metaDataS);
//print_r($metaDataS);
if($toGET == $badCount) {
	echo "getMetaData: Failed to get metadata from digitraffic for all mmsi, last error: $errStr\n";
	exit(1);
}
else echo serialize($metaDataS);
exit(0);
?>
