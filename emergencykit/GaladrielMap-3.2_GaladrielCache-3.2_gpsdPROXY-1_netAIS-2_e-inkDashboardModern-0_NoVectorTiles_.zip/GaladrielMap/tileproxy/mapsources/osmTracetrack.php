<?php
/* Карта OSM с рельефом.
Впрочем, рельеф там довольно фантазийный.
ЛЭП нет, водозаборов нет, зданий в "запрещённых" зонах нет, хотя на карте OSM это всё есть.
Цвета OSM.

И тайлы там 512x512

https://www.openstreetmap.org/#map=16/55.3813/37.5265&layers=P
*/
$humanName = array('ru'=>'Топокарта OpenStreetMap','en'=>'OpenStreetMap Topo');
$ttl = 86400*365; // 1 year cache timeout in seconds время, через которое тайл считается протухшим
// $ttl = 0; 	// тайлы не протухают никогда
$ext = 'webp'; 	// tile image type/extension
$minZoom = 0;
$maxZoom = 19;
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,19796,10302,'a94ddbdd');	// to source check; tile number and CRC32b hash

$getURLoptions['r'] = pathinfo(__FILE__, PATHINFO_FILENAME);	// 'navionics'. $getURLoptions будет передан в $getURL


$getURL = function ($z,$x,$y,$getURLoptions=array()) {
$userAgent = randomUserAgent();
// Referer требуется именно с www.openstreetmap.org
$RequestHead = 'Referer: https://www.openstreetmap.org/';

$url = 'https://tile.tracestrack.com/topo__';
$url .= "/$z/$x/$y.webp";
// ключ со страницы https://www.openstreetmap.org/#map=16/55.3813/37.5265&layers=P, кто его знает, как долго он будет жить
// https://tile.tracestrack.com/topo__/18/158401/82432.webp?key=383118983d4a867dd2d367451720d724
$url .= '?key=383118983d4a867dd2d367451720d724';	
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 120,
		'request_fulluri'=>TRUE
	)
);
changeTORnode($getURLoptions['r']);
return array($url,$opts);
};
?>
