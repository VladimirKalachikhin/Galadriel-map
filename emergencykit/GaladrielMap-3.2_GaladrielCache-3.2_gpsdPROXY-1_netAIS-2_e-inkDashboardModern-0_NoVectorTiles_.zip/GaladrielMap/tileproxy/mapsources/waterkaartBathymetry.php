<?php
/* Масштаб -1 ?
*/
$humanName = array('ru'=>'Балтика, векторная батиметрия','en'=>'De Waterkaart van Nederland vector batymetry');
$mapDescription = array('ru'=>'<a href="https://waterkaart.net/">waterkaart.net</a>
Только батиметрия, всяких знаков нет. Батиметрия на всё Балтийское море, хотя довольно фантазийно. По крайней мере, соответствия с другими картами на масштабах крупнее 12 не обнаружено.
','en'=>'<a href="https://waterkaart.net/">waterkaart.net</a>
');
//$ttl = 0; 	// тайлы не протухают никогда
$ttl = 86400*365; // 1 year cache timeout in seconds время, через которое тайл считается протухшим
$ext = 'pbf'; 	// tile image extension
$ContentType = 'application/x-protobuf'; 	// tile image type
$content_encoding = 'gzip';	// здесь действительно gzip

// Вы _должны_ отредактировать файл стиля style.json, как минимум, приведя указанные там
// html пути в соответствие с путями на своём сервере.
// MBTiles, страной волею своих создателей, не является переносимым форматом. Доступ к тайлам,
// значкам и шрифтам указывается там в файлах стиля в виде абсолютных url.
// Эти url следует поменять на фактические.
// You MUST edit the style.json style file, at a minimum, by matching the HTML paths
// specified there with the paths on your server.
// MBTiles, due to the strange will of its creators, is not a portable format. Access to tiles,
// icons, and fonts is specified there in style files as absolute URLs.
// These URLs should be changed to the actual ones.
$vectorTileStyleURL = "$tileCacheServerPath/$mapSourcesDir/waterkaart/style.json";

$minZoom = 6;
$maxZoom = 17; 	//
$data['noAutoScaled'] = true;
//$bounds = array('leftTop'=>array('lat'=>30.266184,'lng'=>-13.211746),'rightBottom'=>array('lat'=>65.904457,'lng'=>36.213856));	// 
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,19796,10302,'bb69e346');	// to source check; tile number and CRC32b hash

$getURLoptions['r'] = pathinfo(__FILE__, PATHINFO_FILENAME);	// $getURLoptions будет передан в $getURL

//
$getURL = function ($z,$x,$y,$getURLoptions=array()) {
/*  */
$url = 'https://waterkaart.net:81/data/dieptelijnen/';
$url .= $z."/".$x."/".$y.".pbf";

//$userAgent = randomUserAgent();
//$RequestHead = "Referer: https://waterkaart.net/\r\n";
//$RequestHead='';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n$RequestHead",
		//'proxy'=>'tcp://127.0.0.1:8118',
		//'timeout' => 60,
		//'request_fulluri'=>TRUE
	)
);
// set it if you have Tor as proxy, and want change exit node every $tilesPerNode try. https://stackoverflow.com/questions/1969958/how-to-change-the-tor-exit-node-programmatically-to-get-a-new-ip
// tor MUST have in torrc: ControlPort 9051 without authentication: CookieAuthentication 0 and #HashedControlPassword
// Alternative: set own port, config tor password by tor --hash-password my_password and stay password in `echo authenticate '\"\"'`
changeTORnode($getURLoptions['r']);
return array($url,$opts);
}; // end function getURL
//
?>
