<?php
/* Видимо это какой-то скан бумажной карты.
Глубины начинаются с 15 масштаба, глубина в футах

https://gis.charttools.noaa.gov/arcgis/rest/services/MarineChart_Services/NOAACharts/MapServer/WMTS
почему-то z (которая {TileMatrix}) - должна быть на 2 меньше, чем положено, и /{TileRow}/{TileCol} - это y/x
т.е. {TileMatrix}/{TileRow}/{TileCol} - это z-2/y/x
Рабочая ссылка:
https://gis.charttools.noaa.gov/arcgis/rest/services/MarineChart_Services/NOAACharts/MapServer/WMTS/tile/1.0.0/MarineChart_Services_NOAACharts/default/GoogleMapsCompatible/12/6161/4822.png
https://gis.charttools.noaa.gov/arcgis/rest/services/MarineChart_Services/NOAACharts/MapServer/WMTS/tile/1.0.0/MarineChart_Services_NOAACharts/default/default028mm/12/6161/4822.png

php tilefromsource.php -z 14 -x 6161 -y 4822 -r NOAA_USA_MarineChart --checkonly
*/
$humanName = array('ru'=>'Морская карта NOAA MarineChart, USA','en'=>'NOAA USA MarineChart');
$ttl = 86400*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, один год
//$ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$ContentType = 'image/png'; 	// if content type differ then file extension
$minZoom = 4;
$maxZoom = 22;
$bounds = array('leftTop'=>array('lat'=>74.1,'lng'=>131.0),'rightBottom'=>array('lat'=>-17.6,'lng'=>-64.94));
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(14,4822,6161,'70d6c8e4');	// to source check; tile number and CRC32b hash

$getURLoptions['r'] = pathinfo(__FILE__, PATHINFO_FILENAME);	// 'navionics'. $getURLoptions будет передан в $getURL


$getURL = function ($z,$x,$y,$getURLoptions=array()) {
/* 
*/
$userAgent = randomUserAgent();
$RequestHead='Referer: https://encdirect.noaa.gov/';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
$url = 'https://gis.charttools.noaa.gov/arcgis/rest/services/MarineChart_Services/NOAACharts/MapServer/WMTS/tile/1.0.0/MarineChart_Services_NOAACharts/default/GoogleMapsCompatible/';
$url .= ($z-2).'/'.$y.'/'.$x.'.png';
changeTORnode($getURLoptions['r']);
return array($url,$opts);
};
?>
