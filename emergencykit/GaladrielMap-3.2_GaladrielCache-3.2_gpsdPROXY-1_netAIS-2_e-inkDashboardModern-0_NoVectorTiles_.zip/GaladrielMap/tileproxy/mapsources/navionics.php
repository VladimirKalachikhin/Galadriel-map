<?php
/* 
activecaptain.garmin.com/
 */
$humanName = array('ru'=>'Морская карта Navioncs','en'=>'Navionics nautical chart');
//$ttl = 86400*30*12*5; //cache timeout in seconds время, через которое тайл считается протухшим, 2 год
//$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, 0.5 год
//$ttl = 10;
$ttl = 0; //cache timeout in seconds время, через которое тайл считается протухшим
$noTileReTry = 60*60*3;	// оно то отдаётся без tor, то нет
$minZoom = 4;
$maxZoom = 19;
$ext = 'png'; 	// tile image type/extension
$on403 = 'skip'; 	// что делать, если Forbidden: skip, wait - default
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
	'7a64e130',
	'b2451042', 	// пустой серый тайл с логотипом
	'97aa1cbf', 	// кривая надпись про недоступность
	'3629b525', 	// нормальная надпись про недоступность
	'a5b8d956',
	'05aca0a6',
	'cd71a936',
	'1a1edf4b',
	'669a5f14',
	'5248581f',
	'b561bba3',
	'10165527',
	'122dc483',
	'9af9f806',
	'99b57ebb',
	'd87aee55', 	// запрет Navionics в Дании
	'6bd1b567'
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,18956,9316,'d9f8be86');	// to source check; tile number and CRC32b hash

require_once("userapps/fNavionics.php");	// текущий каталог - tileproxy
$getURLoptions['r'] = pathinfo(__FILE__, PATHINFO_FILENAME);	// 'navionics'. $getURLoptions будет передан в $getURL


$getURL = function ($zoom,$x,$y,$getURLoptions=array()) {
/* 
 http://192.168.10.10/tileproxy/tiles.php?z=12&x=2374&y=1161&r=navionics
https://tile4.navionics.com/tile/8/138/80?LAYERS=config_2_6_0&TRANSPARENT=FALSE&theme=0&navtoken=eyJrZXkiOiJOYXZpb25pY3Nfd2ViYXBpXzA0MDQxIiwia2V5RG9tYWluIjoibWFwcy5nYXJtaW4uY29tIiwicmVmZXJlciI6Im1hcHMuZ2FybWluLmNvbSIsInJhbmRvbSI6MTcyMzQ2NDUxNzExMH0
*/
global $tileCacheDir,$on403;
//echo "[getURL] getURLoptions:"; print_r($getURLoptions); echo "\n";

$tokenFileName = "$tileCacheDir/{$getURLoptions['r']}/navtoken";

$DefURLBase='https://tile'.(rand(1,5)).'.navionics.com/tile/';
$userAgent = randomUserAgent();
//$RequestHead='Referer: https://activecaptain.garmin.com/';
$RequestHead = "Origin: https://activecaptain.garmin.com\r\n" . "Referer: https://activecaptain.garmin.com\r\n";
//$tokenTimeOut = 6*60*60; // сек. - время, через которое токен считается протухшим, и надо запрашивать снова
$tokenTimeOut = 30*60; // сек. - время, через которое токен считается протухшим, и надо запрашивать снова
//******************************************************************************
// LAYERS parameter: config_a_b_c
//    a = 1 for depth in meters, 2 for depth in feet, 3 for fathoms
//    b = 10.00: for 10.00 m safety depth (beginning of blue coloring) (unit equal to that set by a)
//    c = 0 for pristine Navionics charts, 1 for Sonar Charts
//
// TRANSPARENT parameter: 
//    FALSE for non-layer
//    TRUE for layer
//
// UGC parameter: 
//    FALSE for pristine Navionics charts
//    TRUE for additinal user-generated content icons
//******************************************************************************
//$cReqParams = 'LAYERS=config_1_10.00_0&TRANSPARENT=FALSE&UGC=FALSE';
//$cReqParams = 'LAYERS=config_1_10.00_0&TRANSPARENT=FALSE&UGC=TRUE&theme=0';
$cReqParams = 'LAYERS=config_1_10.00_0&TRANSPARENT=FALSE&UGC=TRUE&theme=0';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'protocol_version'=>'1.1',
		//'proxy'=>'tcp://127.0.0.1:8118',	
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
list($VNavToken,$VTimeStamp) = unserialize(@file_get_contents($tokenFileName));
//echo "Before: VNavToken=$VNavToken;\nVTimeStamp=$VTimeStamp;<br>\n";
//error_log( "Before: VNavToken=$VNavToken;\nVTimeStamp=$VTimeStamp;<br>\n");
//echo "Должен протухнуть через ".(($tokenTimeOut-(time()-$VTimeStamp))/(60*60))." часов\n" ;
if((time()-$tokenTimeOut) > $VTimeStamp) { 	//  токена нет ($VTimeStamp==0) или токен протух
	$VNavToken = GetNavToken($opts); 	// получим новый токен и время его получения
	$umask = umask(0); 	// сменим на 0777 и запомним текущую
	@mkdir(dirname($tokenFileName), 0777, true); 	// если кеш используется в другой системе, юзер будет другим и облом. Поэтому - всем всё. но реально используется umask, поэтому mkdir 777 не получится
	file_put_contents($tokenFileName, serialize($VNavToken)); 	// запишем файл с токеном
	@chmod($tokenFileName,0666); 	// чтобы при запуске от другого юзера была возаможность 
	umask($umask); 	// 	Вернём. Зачем? Но umask глобальна вообще для всех юзеров веб-сервера
	list($VNavToken,$VTimeStamp) = $VNavToken;
}
if($VNavToken) {
	$ResultURL = $DefURLBase . "$zoom/$x/$y" . "?$cReqParams" . "&navtoken=$VNavToken";
}
else {
	$on403='wait'; 	//  нет токена. Запрос тайла окончится 403, на что мы скажем wait
	$ResultURL = '';
}
//echo "ResultURL=$ResultURL; <br>\n";
//error_log("ResultURL=$ResultURL;");
changeTORnode($getURLoptions['r']);
return array($ResultURL,$opts);
}; // end function getURL

?>
