<?php
/*  Единая электронная картографическая основа (ФППД ЦГКИПД)
https://portal.fppd.cgkipd.ru/map
Федеральное государственное бюджетное учреждение 
«Федеральный научно-технический центр геодезии, картографии и инфраструктуры пространственных данных» 
(ФГБУ «Центр геодезии, картографии и ИПД»)
Но вообще -- явно чтоб враг не догадался. Карты очень древние.
https://ngw.fppd.cgkipd.ru/tile/56/13/4950/2576.png
*/
$humanName = array('ru'=>'Единая картографическая основа (ФППД ЦГКИПД)','en'=>'Russian goverment topo map (CGKIPD)');
$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим. 86400 - сутки
//$ttl = 0; 	// тайлы не протухают никогда
// Время, через которое протухает тайл нулевого размера, обозначающий нерешаемые проблемы скачивания.
$noTileReTry=86400*7; 	// empty tile timeout, good if < $ttl sec. 
$ext = 'png'; 	// tile image type/extension
$minZoom = 3;
$maxZoom = 13;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(13,4949,2575,'c389bea5');	// to source check; tile number and CRC32b hash

$prepareTileImgBeforeReturn = function ($img){
// Заменяет в картинке цвет на прозрачный, требует sudo apt install php-gd 
// На этой карте цвет моря - 160,205,255 Если заменить его на прозрачный, можно наложить
//эту карту на непрозрачные морские
//
$img = setColorsTransparent($img,array(array(160,205,255),array(164,206,252)));
return array('img'=>$img);
}; // end function prepareTileImg


$getURL = function ($z,$x,$y,$getURLoptions=array()) {
$url='https://ngw.fppd.cgkipd.ru/tile/56/';
$url .= "$z/$x/$y".".png";

$userAgent = randomUserAgent();
$RequestHead='Referer: https://rosreestr.ru';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);
return array($url,$opts);
};
?>
