<?php
/* 
https://cache.kartverket.no/v1/wmts/1.0.0/WMTSCapabilities.xml
https://cache.kartverket.no/v1/wmts?layer=topo&style=default&tilematrixset=webmercator&Service=WMTS&Request=GetCapabilities
там, кстати, есть описание TileMatrixSet: что куда сдвигать и откуда считать

https://cache.kartverket.no/v1/wmts/1.0.0/{Layer}/{Style}/{TileMatrixSet}/{TileMatrix}/{TileRow}/{TileCol}.png
Layer:
sjokartraster - морская
topo - Topo (farger) цветная, с глубинами на крупных масштабах
topograatone - Topo (gråtone) в тонах серого
toporaster - Topo (raster) бумажная карта, с глубинами на крупных масштабах

Style:
default

TileMatrixSet:
utm32n
utm33n
utm35n
webmercator

https://cache.kartverket.no/v1/wmts/1.0.0/sjokartraster/default/webmercator/15/9532/17360.png
https://cache.kartverket.no/v1/wmts/1.0.0/toporaster/default/webmercator/14/4496/8525.png
То же самое:
https://cache.kartverket.no/v1/wmts?layer=topo&style=default&tilematrixset=webmercator&Service=WMTS&Request=GetTile&Version=1.0.0&Format=image%2Fpng&TileMatrix=15&TileCol=17360&TileRow=9532

*/
$humanName = array('ru'=>'Норвегия, бумажная топокарта','en'=>'Norwegian paper topo map');
$mapDescription = array('ru'=>'<a href="https://app.karttaselain.fi/">app.karttaselain.fi</a>
','en'=>'<a href="https://app.karttaselain.fi/">app.karttaselain.fi</a>
');
//$ttl = 60*60*24*30*12*1; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
$ttl = 60*60*24*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, 1 год
//$ttl = 0; 	// тайлы не протухают никогда
$noTileReTry = 60*60; 	// no tile timeout, sec. Время, через которое переспрашивать тайлы, которые не удалось скачать. OpenTopoMap банит скачивальщиков, поэтому короткое.
$ext = 'png'; 	// tile image type/extension
$minZoom = 2;
$maxZoom = 18;
$bounds = array('leftTop'=>array('lat'=>71.497,'lng'=>3.6914),'rightBottom'=>array('lat'=>57.6101,'lng'=>31.9922));
// crc32 хеши тайлов, которые не надо сохранять: логотипы, тайлы с дурацкими надписями. '1556c7bd' чистый голубой квадрат 'c7b10d34' чистый голубой квадрат - не мусор! Иначе такие тайлы будут скачиваться снова и снова, а их много.
$trash = array(
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,17360,9532,'085d3523');	// to source check; tile number and CRC32b hash. Oslo

$getURL = function ($z,$x,$y,$getURLoptions=array()) {
/* */
global $ext;

$url = 'https://cache.kartverket.no/v1/wmts/1.0.0/toporaster/default/webmercator';

$userAgent = randomUserAgent();
$RequestHead='Referer: https://app.karttaselain.fi/';
//$RequestHead='';

$url .= "/$z/$y/$x.$ext";
$opts = array(
	'http'=>array(
		'method'=>"GET",
		'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		'timeout' => 60,
		'request_fulluri'=>TRUE,
		'protocol_version'=>1.1
	)
);
//print_r($opts);
// set it if you have Tor as proxy, and want change exit node every $tilesPerNode try. https://stackoverflow.com/questions/1969958/how-to-change-the-tor-exit-node-programmatically-to-get-a-new-ip
// tor MUST have in torrc: ControlPort 9051 without authentication: CookieAuthentication 0 and #HashedControlPassword
// Alternative: set own port, config tor password by tor --hash-password my_password and stay password in `echo authenticate '\"\"'`
//
changeTORnode($getURLoptions['karttaselain']);
//
return array($url,$opts);
};
?>
