<?php
/*
*/
$humanName = array('ru'=>'Топокарта CALTOPO','en'=>'CALTOPO map');
$mapDescription = array('ru'=>'<a href="https://caltopo.com/map.html">caltopo.com</a>
','en'=>'<a href="https://caltopo.com/map.html">caltopo.com</a>
');
$ttl = 86400*30*6; //cache timeout in seconds время, через которое тайл считается протухшим, один год
// $ttl = 0; 	// тайлы не протухают никогда
$ext = 'png'; 	// tile image type/extension
$ContentType = 'image/png'; 	// if content type differ then file extension
$minZoom = 0;
$maxZoom = 19;
$trash = array( 	// crc32 хеши тайлов, которые не надо сохранять: логотипы, пустые тайлы, тайлы с дурацкими надписями
);
// Для контроля источника: номер правильного тайла и его CRC32b хеш
$trueTile=array(15,19796,10302,'412515a5');	// to source check; tile number and CRC32b hash

$getURLoptions['r'] = pathinfo(__FILE__, PATHINFO_FILENAME);

$getURL = function ($z,$x,$y,$getURLoptions=array()) {
/* 
*/
global $ext;
$userAgent = randomUserAgent();
$RequestHead='Referer: https://caltopo.com/map.html';

$opts = array(
	'http'=>array(
		'method'=>"GET",
		//'header'=>"User-Agent: $userAgent\r\n" . "$RequestHead\r\n",
		//'proxy'=>'tcp://127.0.0.1:8118',
		//'timeout' => 60,
		'request_fulluri'=>TRUE
	)
);

$url = 'https://caltopo.com/tile/mb_topo';
$url .= "/$z/$x/$y.$ext";
$url .= '?ctdarkmode=false';
changeTORnode($getURLoptions['r']);
return array($url,$opts);
};
?>
