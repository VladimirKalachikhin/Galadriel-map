<?php
/*
*/
require('BSH_common');
$getURLparams = array(
'map'=>'NAUTHIS_SkinOfTheEarth',
'layers'=>'2,6,12,18,24,30',
'bgcolor'=>'0xFFFFFF' 
);

?>
